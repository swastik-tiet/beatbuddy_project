import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Play,
  Pause,
  Heart,
  ThumbsDown,
  Share2,
  Clock,
  MessageCircle,
  ArrowLeft,
  Music,
  Sparkles,
} from "lucide-react";
import { Link } from "react-router-dom";
import CommentSection from "../components/CommentSection";
import { getSongById } from "../data/mockData";
import { moodDetectionService } from "../services/moodDetectionService";
import axios from "axios";

const formatDuration = (seconds, fallback) => {
  if (typeof seconds !== "number" || Number.isNaN(seconds) || seconds <= 0) {
    return fallback || "0:00";
  }
  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${minutes}:${secs.toString().padStart(2, "0")}`;
};

const SongPage = () => {
  const { id } = useParams();
  const [song, setSong] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSong = async () => {
      setLoading(true);
      try {
        const songData = getSongById(id);
        if (songData) {
          setSong(songData);

          try {
            const remoteRes = await axios.get(
              `/api/songs/search/${encodeURIComponent(songData.title)}`,
              { params: { limit: 1 } }
            );

            const remoteSong = remoteRes?.data?.data?.songs?.[0];
            if (remoteSong) {
              const normalizedRemote = {
                ...songData,
                ...remoteSong,
                id: remoteSong._id || remoteSong.id || songData.id,
                duration: formatDuration(
                  remoteSong.duration,
                  songData.duration
                ),
                coverImage: remoteSong.coverImage || songData.coverImage,
                audioUrl: remoteSong.audioUrl || songData.audioUrl,
                comments:
                  Array.isArray(remoteSong.comments) &&
                  remoteSong.comments.length
                    ? remoteSong.comments
                    : songData.comments,
              };
              setSong(normalizedRemote);
            }
          } catch (error) {
            console.warn(
              "Falling back to mock song data, API search failed:",
              error?.response?.data || error.message
            );
          }
        }
      } catch (error) {
        console.error("Error fetching song:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSong();
  }, [id]);

  useEffect(() => {
    const handleGlobalPlay = (event) => {
      if (!song) return;
      const playedSong = event.detail?.song;
      if (!playedSong) return;
      const playedId = playedSong._id || playedSong.id;
      const currentId = song._id || song.id;
      if (!currentId) return;
      setIsPlaying(playedId === currentId);
    };

    const handleGlobalPause = () => {
      setIsPlaying(false);
    };

    window.addEventListener("play-song", handleGlobalPlay);
    window.addEventListener("pause-song", handleGlobalPause);

    return () => {
      window.removeEventListener("play-song", handleGlobalPlay);
      window.removeEventListener("pause-song", handleGlobalPause);
    };
  }, [song]);

  const handlePlayPause = async () => {
    if (!song) return;

    const songPayload = {
      ...song,
      id: song._id || song.id,
    };

    if (!isPlaying) {
      try {
        window.dispatchEvent(
          new CustomEvent("play-song", {
            detail: {
              song: songPayload,
              queue: [songPayload],
              queueIndex: 0,
              playlistName: song.album || song.title,
            },
          })
        );
      } catch (error) {
        console.error("Error dispatching play event:", error);
      }

      const idForApi = song._id || song.id;
      if (idForApi) {
        try {
          await axios.post(`/api/songs/${idForApi}/play`);
        } catch (error) {
          console.warn(
            "Play tracking failed:",
            error?.response?.data || error.message
          );
        }
      }

      setIsPlaying(true);
    } else {
      try {
        window.dispatchEvent(
          new CustomEvent("pause-song", {
            detail: { id: songPayload.id },
          })
        );
      } catch (error) {
        console.error("Error dispatching pause event:", error);
      }

      setIsPlaying(false);
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
  };

  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
  };

  const handleAddComment = async (comment, songId) => {
    // In a real app, this would be an API call
    console.log("Adding comment:", comment, "to song:", songId);

    // Simulate adding comment to the song
    if (song) {
      setSong((prevSong) => ({
        ...prevSong,
        comments: [...prevSong.comments, comment],
      }));
    }
  };

  const getMoodDistribution = () => {
    if (!song?.comments) return {};

    return song.comments.reduce((acc, comment) => {
      acc[comment.mood] = (acc[comment.mood] || 0) + 1;
      return acc;
    }, {});
  };

  const moodDistribution = getMoodDistribution();
  const topMoods = Object.entries(moodDistribution)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20,
      },
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16 flex items-center justify-center">
        <motion.div
          className="text-center"
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        >
          <Music className="h-16 w-16 text-spotify-green mx-auto mb-4" />
          <p className="text-spotify-text-secondary">Loading song...</p>
        </motion.div>
      </div>
    );
  }

  if (!song) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16 flex items-center justify-center">
        <div className="text-center">
          <Music className="h-16 w-16 text-spotify-text-secondary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-spotify-text mb-2">
            Song Not Found
          </h2>
          <p className="text-spotify-text-secondary mb-4">
            The song you're looking for doesn't exist.
          </p>
          <Link
            to="/"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-spotify-green to-spotify-blue text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Back Button */}
          <motion.div variants={itemVariants} className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center space-x-2 text-spotify-text-secondary hover:text-spotify-text transition-colors duration-300"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Home</span>
            </Link>
          </motion.div>

          {/* Song Header */}
          <motion.div
            className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12"
            variants={itemVariants}
          >
            {/* Cover Image */}
            <div className="lg:col-span-1">
              <motion.div
                className="relative aspect-square rounded-2xl overflow-hidden shadow-2xl"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <img
                  src={
                    song.coverImage ||
                    `https://picsum.photos/400/400?random=${song.id}`
                  }
                  alt={song.title}
                  className="w-full h-full object-cover"
                />

                {/* Play Button Overlay */}
                <motion.div
                  className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300"
                  whileHover={{ scale: 1.05 }}
                >
                  <motion.button
                    onClick={handlePlayPause}
                    className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white p-6 rounded-full shadow-2xl hover:shadow-spotify-green/30 transition-all duration-300"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {isPlaying ? (
                      <Pause className="h-8 w-8" />
                    ) : (
                      <Play className="h-8 w-8 ml-1" />
                    )}
                  </motion.button>
                </motion.div>
              </motion.div>
            </div>

            {/* Song Info */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <motion.h1
                  className="text-4xl md:text-5xl font-bold text-spotify-text mb-4"
                  variants={itemVariants}
                >
                  {song.title}
                </motion.h1>
                <motion.p
                  className="text-xl text-spotify-text-secondary mb-2"
                  variants={itemVariants}
                >
                  {song.artist}
                </motion.p>
                <motion.p
                  className="text-spotify-text-secondary"
                  variants={itemVariants}
                >
                  {song.album} • {song.releaseYear}
                </motion.p>
              </div>

              {/* Action Buttons */}
              <motion.div
                className="flex items-center space-x-4"
                variants={itemVariants}
              >
                <motion.button
                  onClick={handlePlayPause}
                  className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="h-5 w-5" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-5 w-5" />
                      <span>Play</span>
                    </>
                  )}
                </motion.button>

                <motion.button
                  onClick={handleLike}
                  className={`p-3 rounded-full transition-all duration-300 ${
                    isLiked
                      ? "text-red-500 bg-red-500/20 shadow-lg"
                      : "text-spotify-text-secondary hover:text-red-500 hover:bg-red-500/20"
                  }`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Heart
                    className={`h-6 w-6 ${
                      isLiked ? "fill-current animate-heartbeat" : ""
                    }`}
                  />
                </motion.button>

                <motion.button
                  onClick={handleDislike}
                  className={`p-3 rounded-full transition-all duration-300 ${
                    isDisliked
                      ? "text-blue-500 bg-blue-500/20 shadow-lg"
                      : "text-spotify-text-secondary hover:text-blue-500 hover:bg-blue-500/20"
                  }`}
                  whileHover={{ scale: 1.1, rotate: -5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <ThumbsDown
                    className={`h-6 w-6 ${isDisliked ? "fill-current" : ""}`}
                  />
                </motion.button>

                <motion.button
                  className="p-3 text-spotify-text-secondary hover:text-spotify-text rounded-full hover:bg-white/10 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Share2 className="h-6 w-6" />
                </motion.button>
              </motion.div>

              {/* Genres */}
              <motion.div variants={itemVariants}>
                <h3 className="text-lg font-semibold text-spotify-text mb-3">
                  Genres
                </h3>
                <div className="flex flex-wrap gap-2">
                  {song.genres.map((genre, index) => (
                    <motion.span
                      key={genre}
                      className="px-3 py-1 bg-spotify-dark-gray text-spotify-text-secondary rounded-full text-sm border border-white/10"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.05 }}
                    >
                      {genre}
                    </motion.span>
                  ))}
                </div>
              </motion.div>

              {/* Mood Distribution */}
              {topMoods.length > 0 && (
                <motion.div variants={itemVariants}>
                  <h3 className="text-lg font-semibold text-spotify-text mb-3 flex items-center">
                    <Sparkles className="h-5 w-5 mr-2 text-spotify-green" />
                    Community Mood Analysis
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {topMoods.map(([mood, count], index) => (
                      <motion.span
                        key={mood}
                        className={`px-4 py-2 rounded-full text-white font-medium shadow-lg ${moodDetectionService.getMoodColor(
                          mood
                        )}`}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                        whileHover={{ scale: 1.1 }}
                      >
                        {moodDetectionService.getMoodEmoji(mood)}{" "}
                        {moodDetectionService.getMoodDisplayName(mood)} ({count}{" "}
                        comments)
                      </motion.span>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Stats */}
              <motion.div
                className="flex items-center space-x-6 text-sm text-spotify-text-secondary"
                variants={itemVariants}
              >
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>{song.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-4 w-4" />
                  <span>{song.comments?.length || 0} comments</span>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Comments Section */}
          <motion.div variants={itemVariants}>
            <CommentSection
              comments={song.comments || []}
              onAddComment={handleAddComment}
              songId={song.id}
            />
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default SongPage;
