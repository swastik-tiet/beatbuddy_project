import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Heart, 
  Share2, 
  ArrowLeft,
  Music,
  Clock,
  Users,
  Sparkles,
  Shuffle,
  Repeat
} from 'lucide-react';
import SongCard from '../components/SongCard';
import { getPlaylistById } from '../data/mockData';
import { moodDetectionService } from '../services/moodDetectionService';

const PlaylistPage = () => {
  const { id } = useParams();
  const [playlist, setPlaylist] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedMood, setSelectedMood] = useState('');

  useEffect(() => {
    const fetchPlaylist = async () => {
      setLoading(true);
      try {
        const playlistData = getPlaylistById(id);
        if (playlistData) {
          setPlaylist(playlistData);
        }
      } catch (error) {
        console.error('Error fetching playlist:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPlaylist();
  }, [id]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleMoodFilter = (mood) => {
    setSelectedMood(selectedMood === mood ? '' : mood);
  };

  const getFilteredSongs = () => {
    if (!playlist?.songs) return [];
    
    if (selectedMood) {
      return playlist.songs.filter(song => {
        const moodDistribution = song.comments?.reduce((acc, comment) => {
          acc[comment.mood] = (acc[comment.mood] || 0) + 1;
          return acc;
        }, {}) || {};
        
        return moodDistribution[selectedMood] > 0;
      });
    }
    
    return playlist.songs;
  };

  const getSongsByMood = () => {
    if (!playlist?.songs) return {};
    
    const moodGroups = {};
    
    playlist.songs.forEach(song => {
      const moodDistribution = song.comments?.reduce((acc, comment) => {
        acc[comment.mood] = (acc[comment.mood] || 0) + 1;
        return acc;
      }, {}) || {};
      
      Object.entries(moodDistribution).forEach(([mood, count]) => {
        if (!moodGroups[mood]) {
          moodGroups[mood] = [];
        }
        moodGroups[mood].push({ ...song, moodCount: count });
      });
    });
    
    return moodGroups;
  };

  const moodGroups = getSongsByMood();
  const filteredSongs = getFilteredSongs();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16 flex items-center justify-center">
        <motion.div
          className="text-center"
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        >
          <Music className="h-16 w-16 text-spotify-green mx-auto mb-4" />
          <p className="text-spotify-text-secondary">Loading playlist...</p>
        </motion.div>
      </div>
    );
  }

  if (!playlist) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16 flex items-center justify-center">
        <div className="text-center">
          <Music className="h-16 w-16 text-spotify-text-secondary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-spotify-text mb-2">Playlist Not Found</h2>
          <p className="text-spotify-text-secondary mb-4">The playlist you're looking for doesn't exist.</p>
          <Link 
            to="/"
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-spotify-green to-spotify-blue text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Back Button */}
          <motion.div variants={itemVariants} className="mb-8">
            <Link 
              to="/"
              className="inline-flex items-center space-x-2 text-spotify-text-secondary hover:text-spotify-text transition-colors duration-300"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Home</span>
            </Link>
          </motion.div>

          {/* Playlist Header */}
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12"
            variants={itemVariants}
          >
            {/* Cover Image */}
            <div className="lg:col-span-1">
              <motion.div
                className="relative aspect-square rounded-2xl overflow-hidden shadow-2xl"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <img
                  src={playlist.coverImage || `https://picsum.photos/400/400?random=${playlist.id}`}
                  alt={playlist.name}
                  className="w-full h-full object-cover"
                />
                
                {/* Play Button Overlay */}
                <motion.div
                  className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300"
                  whileHover={{ scale: 1.05 }}
                >
                  <motion.button
                    onClick={handlePlayPause}
                    className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white p-6 rounded-full shadow-2xl hover:shadow-spotify-green/30 transition-all duration-300"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {isPlaying ? (
                      <Pause className="h-8 w-8" />
                    ) : (
                      <Play className="h-8 w-8 ml-1" />
                    )}
                  </motion.button>
                </motion.div>
              </motion.div>
            </div>

            {/* Playlist Info */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <motion.h1 
                  className="text-4xl md:text-5xl font-bold text-spotify-text mb-4"
                  variants={itemVariants}
                >
                  {playlist.name}
                </motion.h1>
                <motion.p 
                  className="text-xl text-spotify-text-secondary mb-4"
                  variants={itemVariants}
                >
                  {playlist.description}
                </motion.p>
                
                {/* Mood Badge */}
                <motion.div variants={itemVariants}>
                  <span className={`inline-flex items-center px-4 py-2 rounded-full text-white font-medium shadow-lg ${moodDetectionService.getMoodColor(playlist.mood)}`}>
                    {moodDetectionService.getMoodEmoji(playlist.mood)} {moodDetectionService.getMoodDisplayName(playlist.mood)}
                  </span>
                </motion.div>
              </div>

              {/* Stats */}
              <motion.div 
                className="flex items-center space-x-6 text-sm text-spotify-text-secondary"
                variants={itemVariants}
              >
                <div className="flex items-center space-x-2">
                  <Music className="h-4 w-4" />
                  <span>{playlist.songCount} songs</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>{playlist.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>{playlist.likes.toLocaleString()} likes</span>
                </div>
              </motion.div>

              {/* Action Buttons */}
              <motion.div 
                className="flex items-center space-x-4"
                variants={itemVariants}
              >
                <motion.button
                  onClick={handlePlayPause}
                  className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="h-5 w-5" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-5 w-5" />
                      <span>Play</span>
                    </>
                  )}
                </motion.button>

                <motion.button
                  className="p-3 text-spotify-text-secondary hover:text-spotify-text rounded-full hover:bg-white/10 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Shuffle className="h-5 w-5" />
                </motion.button>

                <motion.button
                  className="p-3 text-spotify-text-secondary hover:text-spotify-text rounded-full hover:bg-white/10 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Repeat className="h-5 w-5" />
                </motion.button>

                <motion.button
                  onClick={handleLike}
                  className={`p-3 rounded-full transition-all duration-300 ${
                    isLiked 
                      ? 'text-red-500 bg-red-500/20 shadow-lg' 
                      : 'text-spotify-text-secondary hover:text-red-500 hover:bg-red-500/20'
                  }`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Heart className={`h-5 w-5 ${isLiked ? 'fill-current animate-heartbeat' : ''}`} />
                </motion.button>

                <motion.button
                  className="p-3 text-spotify-text-secondary hover:text-spotify-text rounded-full hover:bg-white/10 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Share2 className="h-5 w-5" />
                </motion.button>
              </motion.div>

              {/* Mood Distribution */}
              {playlist.moodDistribution && (
                <motion.div variants={itemVariants}>
                  <h3 className="text-lg font-semibold text-spotify-text mb-3 flex items-center">
                    <Sparkles className="h-5 w-5 mr-2 text-spotify-green" />
                    Mood Breakdown
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(playlist.moodDistribution)
                      .sort(([,a], [,b]) => b - a)
                      .map(([mood, count]) => (
                        <motion.button
                          key={mood}
                          onClick={() => handleMoodFilter(mood)}
                          className={`px-4 py-2 rounded-full text-white font-medium shadow-lg transition-all duration-300 ${
                            selectedMood === mood 
                              ? 'ring-2 ring-spotify-green ring-offset-2 ring-offset-spotify-black' 
                              : ''
                          } ${moodDetectionService.getMoodColor(mood)}`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {moodDetectionService.getMoodEmoji(mood)} {moodDetectionService.getMoodDisplayName(mood)} ({count})
                        </motion.button>
                      ))}
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Songs Section */}
          <motion.div variants={itemVariants}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-spotify-text">
                Songs {selectedMood && `- ${moodDetectionService.getMoodDisplayName(selectedMood)}`}
              </h2>
              {selectedMood && (
                <motion.button
                  onClick={() => setSelectedMood('')}
                  className="text-spotify-text-secondary hover:text-spotify-text transition-colors duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Clear Filter
                </motion.button>
              )}
            </div>

            {filteredSongs.length > 0 ? (
              <motion.div 
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
                variants={containerVariants}
              >
                {filteredSongs.map((song, index) => (
                  <motion.div
                    key={song.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <SongCard
                      song={song}
                      onPlay={async (s) => {
                        const id = s?._id || s?.id;
                        if (id) {
                          try {
                            console.log('[Play] Sending POST /api/songs/' + id + '/play');
                            const res = await axios.post(`/api/songs/${id}/play`);
                            console.log('[Play] Response', { status: res.status, data: res.data });
                          } catch (err) {
                            console.log('[Play] Request failed', err?.response ? { status: err.response.status, data: err.response.data } : err);
                          }
                        }
                        try { window.dispatchEvent(new CustomEvent('play-song', { detail: s })); } catch {}
                      }}
                      onLike={(songId, isLiked) => console.log('Liked:', songId, isLiked)}
                      onDislike={(songId, isDisliked) => console.log('Disliked:', songId, isDisliked)}
                    />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <Music className="h-16 w-16 text-spotify-text-secondary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-spotify-text mb-2">No songs found</h3>
                <p className="text-spotify-text-secondary">
                  {selectedMood 
                    ? `No songs with ${moodDetectionService.getMoodDisplayName(selectedMood)} mood in this playlist`
                    : 'This playlist appears to be empty'
                  }
                </p>
              </motion.div>
            )}
          </motion.div>

          {/* Mood Groups Section */}
          {Object.keys(moodGroups).length > 0 && (
            <motion.div variants={itemVariants} className="mt-16">
              <h2 className="text-2xl font-bold text-spotify-text mb-6">Songs by Mood</h2>
              <div className="space-y-8">
                {Object.entries(moodGroups)
                  .sort(([,a], [,b]) => b.length - a.length)
                  .map(([mood, songs]) => (
                    <motion.div
                      key={mood}
                      className="space-y-4"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      <div className="flex items-center space-x-3">
                        <span className={`px-4 py-2 rounded-full text-white font-medium shadow-lg ${moodDetectionService.getMoodColor(mood)}`}>
                          {moodDetectionService.getMoodEmoji(mood)} {moodDetectionService.getMoodDisplayName(mood)} ({songs.length} songs)
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        {songs.slice(0, 4).map((song, index) => (
                          <motion.div
                            key={song.id}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: index * 0.1 }}
                          >
                            <SongCard
                              song={song}
                              onPlay={async (s) => {
                                const id = s?._id || s?.id;
                                if (id) {
                                  try {
                                    console.log('[Play] Sending POST /api/songs/' + id + '/play');
                                    const res = await axios.post(`/api/songs/${id}/play`);
                                    console.log('[Play] Response', { status: res.status, data: res.data });
                                  } catch (err) {
                                    console.log('[Play] Request failed', err?.response ? { status: err.response.status, data: err.response.data } : err);
                                  }
                                }
                                try { window.dispatchEvent(new CustomEvent('play-song', { detail: s })); } catch {}
                              }}
                              onLike={(songId, isLiked) => console.log('Liked:', songId, isLiked)}
                              onDislike={(songId, isDisliked) => console.log('Disliked:', songId, isDisliked)}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
};

export default PlaylistPage;
