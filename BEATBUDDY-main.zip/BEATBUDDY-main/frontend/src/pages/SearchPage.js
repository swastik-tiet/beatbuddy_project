import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Music, 
  TrendingUp,
  Clock,
  Sparkles
} from 'lucide-react';
import SongCard from '../components/SongCard';
import MoodSelector from '../components/MoodSelector';
import { searchSongs, getSongsByMood, mockSongs } from '../data/mockData';
import { moodDetectionService } from '../services/moodDetectionService';

const SearchPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMood, setSelectedMood] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);

  useEffect(() => {
    // Load recent searches from localStorage
    const saved = localStorage.getItem('beatbuddy_recent_searches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    if (searchQuery.trim() || selectedMood) {
      performSearch();
    } else {
      setSearchResults([]);
    }
  }, [searchQuery, selectedMood]);

  const performSearch = async () => {
    setIsSearching(true);
    
    try {
      let results = [];
      
      if (searchQuery.trim()) {
        // Search by query
        results = searchSongs(searchQuery);
      } else if (selectedMood) {
        // Search by mood
        results = getSongsByMood(selectedMood);
      }
      
      setSearchResults(results);
      
      // Save to recent searches
      if (searchQuery.trim()) {
        const newSearch = {
          query: searchQuery,
          timestamp: new Date().toISOString(),
          resultsCount: results.length
        };
        
        const updatedSearches = [
          newSearch,
          ...recentSearches.filter(s => s.query !== searchQuery)
        ].slice(0, 5);
        
        setRecentSearches(updatedSearches);
        localStorage.setItem('beatbuddy_recent_searches', JSON.stringify(updatedSearches));
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    performSearch();
  };

  const handleMoodSelect = (mood) => {
    setSelectedMood(mood);
    setSearchQuery(''); // Clear text search when mood is selected
  };

  const handleRecentSearchClick = (query) => {
    setSearchQuery(query);
    setSelectedMood(''); // Clear mood filter
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedMood('');
    setSearchResults([]);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  return (
    <motion.div
      className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="mb-8">
            <h1 className="text-4xl font-bold text-spotify-text mb-4">Search Music</h1>
            <p className="text-spotify-text-secondary text-lg">
              Find songs by title, artist, or mood. Discover music through crowdsourced mood analysis.
            </p>
          </motion.div>

          {/* Search Bar */}
          <motion.div variants={itemVariants} className="mb-8">
            <form onSubmit={handleSearch} className="relative">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-spotify-text-secondary" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for songs, artists, or albums..."
                  className="w-full pl-12 pr-4 py-4 bg-spotify-dark-gray border border-white/10 rounded-2xl text-spotify-text placeholder-spotify-text-secondary focus:outline-none focus:ring-2 focus:ring-spotify-green/50 focus:border-spotify-green/50 transition-all duration-300"
                />
                <motion.button
                  type="submit"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-spotify-green to-spotify-blue text-white p-2 rounded-xl hover:shadow-lg transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Search className="h-4 w-4" />
                </motion.button>
              </div>
            </form>
          </motion.div>

          {/* Filter Toggle */}
          <motion.div variants={itemVariants} className="mb-6">
            <motion.button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-2 bg-spotify-dark-gray text-spotify-text-secondary hover:text-spotify-text rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Filter className="h-4 w-4" />
              <span>Mood Filters</span>
            </motion.button>
          </motion.div>

          {/* Mood Filters */}
          <AnimatePresence>
            {showFilters && (
              <motion.div
                variants={itemVariants}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-8"
              >
                <MoodSelector
                  selectedMood={selectedMood}
                  onMoodSelect={handleMoodSelect}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active Filters */}
          {(searchQuery || selectedMood) && (
            <motion.div
              variants={itemVariants}
              className="mb-6 flex items-center space-x-4"
            >
              <span className="text-spotify-text-secondary">Active filters:</span>
              {searchQuery && (
                <motion.span
                  className="px-3 py-1 bg-spotify-green/20 text-spotify-green rounded-full text-sm"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  "{searchQuery}"
                </motion.span>
              )}
              {selectedMood && (
                <motion.span
                  className={`px-3 py-1 rounded-full text-sm text-white ${moodDetectionService.getMoodColor(selectedMood)}`}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  {moodDetectionService.getMoodEmoji(selectedMood)} {moodDetectionService.getMoodDisplayName(selectedMood)}
                </motion.span>
              )}
              <motion.button
                onClick={clearFilters}
                className="text-spotify-text-secondary hover:text-spotify-text transition-colors duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Clear all
              </motion.button>
            </motion.div>
          )}

          {/* Search Results */}
          <AnimatePresence mode="wait">
            {isSearching ? (
              <motion.div
                key="loading"
                className="text-center py-12"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div
                  className="w-16 h-16 bg-gradient-to-br from-spotify-green to-spotify-blue rounded-full flex items-center justify-center mx-auto mb-4"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Search className="h-8 w-8 text-white" />
                </motion.div>
                <p className="text-spotify-text-secondary">Searching...</p>
              </motion.div>
            ) : searchResults.length > 0 ? (
              <motion.div
                key="results"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <motion.div variants={itemVariants} className="mb-6">
                  <h2 className="text-2xl font-bold text-spotify-text mb-2">
                    Search Results ({searchResults.length})
                  </h2>
                  <p className="text-spotify-text-secondary">
                    {searchQuery ? `Found ${searchResults.length} songs matching "${searchQuery}"` : 
                     `Found ${searchResults.length} songs with ${moodDetectionService.getMoodDisplayName(selectedMood)} mood`}
                  </p>
                </motion.div>

                <motion.div 
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
                  variants={containerVariants}
                >
                  {searchResults.map((song, index) => (
                    <motion.div
                      key={song.id}
                      variants={itemVariants}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <SongCard
                        song={song}
                        onPlay={async (s) => {
                          try { window.dispatchEvent(new CustomEvent('play-song', { detail: s })); } catch {}
                          const id = s?._id || s?.id;
                          if (id) {
                            (async () => {
                              try {
                                console.log('[Play] Sending POST /api/songs/' + id + '/play');
                                const res = await axios.post(`/api/songs/${id}/play`);
                                console.log('[Play] Response', { status: res.status, data: res.data });
                              } catch (err) {
                                console.log('[Play] Request failed', err?.response ? { status: err.response.status, data: err.response.data } : err);
                              }
                            })();
                          }
                        }}
                        onLike={(songId, isLiked) => console.log('Liked:', songId, isLiked)}
                        onDislike={(songId, isDisliked) => console.log('Disliked:', songId, isDisliked)}
                      />
                    </motion.div>
                  ))}
                </motion.div>
              </motion.div>
            ) : (searchQuery || selectedMood) ? (
              <motion.div
                key="no-results"
                className="text-center py-12"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <Music className="h-16 w-16 text-spotify-text-secondary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-spotify-text mb-2">No results found</h3>
                <p className="text-spotify-text-secondary mb-4">
                  Try adjusting your search terms or mood filter
                </p>
                <motion.button
                  onClick={clearFilters}
                  className="px-6 py-2 bg-gradient-to-r from-spotify-green to-spotify-blue text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Clear Filters
                </motion.button>
              </motion.div>
            ) : (
              <motion.div
                key="default"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                  <motion.div variants={itemVariants} className="mb-8">
                    <h2 className="text-2xl font-bold text-spotify-text mb-4 flex items-center">
                      <Clock className="h-6 w-6 mr-2 text-spotify-green" />
                      Recent Searches
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      {recentSearches.map((search, index) => (
                        <motion.button
                          key={search.query}
                          onClick={() => handleRecentSearchClick(search.query)}
                          className="px-4 py-2 bg-spotify-dark-gray text-spotify-text-secondary hover:text-spotify-text rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {search.query}
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* Popular Moods */}
                <motion.div variants={itemVariants} className="mb-8">
                  <h2 className="text-2xl font-bold text-spotify-text mb-4 flex items-center">
                    <TrendingUp className="h-6 w-6 mr-2 text-spotify-green" />
                    Popular Moods
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                    {['happy', 'sad', 'energetic', 'calm', 'romantic'].map((mood, index) => (
                      <motion.button
                        key={mood}
                        onClick={() => handleMoodSelect(mood)}
                        className={`p-4 rounded-xl text-center transition-all duration-300 ${moodDetectionService.getMoodColor(mood)}`}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        whileHover={{ scale: 1.05, y: -5 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <div className="text-2xl mb-2">{moodDetectionService.getMoodEmoji(mood)}</div>
                        <div className="text-sm font-medium text-white">
                          {moodDetectionService.getMoodDisplayName(mood)}
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>

                {/* Trending Songs */}
                <motion.div variants={itemVariants}>
                  <h2 className="text-2xl font-bold text-spotify-text mb-4 flex items-center">
                    <Sparkles className="h-6 w-6 mr-2 text-spotify-green" />
                    Trending Songs
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {mockSongs.slice(0, 4).map((song, index) => (
                      <motion.div
                        key={song.id}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <SongCard
                          song={song}
                          onPlay={(song) => console.log('Playing:', song.title)}
                          onLike={(songId, isLiked) => console.log('Liked:', songId, isLiked)}
                          onDislike={(songId, isDisliked) => console.log('Disliked:', songId, isDisliked)}
                        />
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default SearchPage;
