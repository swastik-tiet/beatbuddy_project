import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import MoodSelector from "../components/MoodSelector";
import PlaylistCard from "../components/PlaylistCard";
import SongCard from "../components/SongCard";
import {
  Music,
  TrendingUp,
  Clock,
  Heart,
  Sparkles,
  Star,
  Brain,
  Activity,
} from "lucide-react";
import { mockSongs, mockPlaylists, getRecentComments } from "../data/mockData";
import axios from "axios";

const HomePage = () => {
  const [selectedMood, setSelectedMood] = useState("");
  const [moodPlaylists, setMoodPlaylists] = useState([]);
  const [recentSongs, setRecentSongs] = useState([]);
  const [trendingSongs, setTrendingSongs] = useState([]);
  const [recentComments, setRecentComments] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      setRecentComments(getRecentComments());
      try {
        console.log("[Songs] GET /api/songs?limit=8");
        const resAll = await axios.get("/api/songs", { params: { limit: 8 } });
        console.log("[Songs] Response (all)", {
          status: resAll.status,
          dataCount: resAll?.data?.data?.songs?.length,
        });
        const arrAll = (resAll?.data?.data?.songs || []).map((s) => ({
          ...s,
          id: s.id || s._id,
        }));
        setRecentSongs(arrAll.slice(0, 4));
      } catch (err) {
        console.log(
          "[Songs] GET /api/songs failed, using mock",
          err?.response
            ? { status: err.response.status, data: err.response.data }
            : err
        );
        setRecentSongs(mockSongs.slice(0, 4));
      }
      try {
        console.log("[Songs] GET /api/songs/trending?limit=8");
        const resTrend = await axios.get("/api/songs/trending", {
          params: { limit: 8 },
        });
        console.log("[Songs] Response (trending)", {
          status: resTrend.status,
          dataCount: resTrend?.data?.data?.songs?.length,
        });
        const arrTrend = (resTrend?.data?.data?.songs || []).map((s) => ({
          ...s,
          id: s.id || s._id,
        }));
        setTrendingSongs(arrTrend.slice(0, 8));
      } catch (err) {
        console.log(
          "[Songs] GET /api/songs/trending failed, using mock",
          err?.response
            ? { status: err.response.status, data: err.response.data }
            : err
        );
        setTrendingSongs(mockSongs.slice(4, 8));
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    if (selectedMood) {
      // Filter playlists by selected mood
      const filteredPlaylists = mockPlaylists.filter(
        (playlist) =>
          playlist.mood === selectedMood ||
          Object.keys(playlist.moodDistribution || {}).includes(selectedMood)
      );
      setMoodPlaylists(filteredPlaylists);
    } else {
      setMoodPlaylists(mockPlaylists);
    }
  }, [selectedMood]);

  const handleMoodSelect = (mood) => {
    setSelectedMood(mood);
  };

  const handlePlaylistPlay = (playlist) => {
    console.log("Playing playlist:", playlist.name);

    const playlistSongs = Array.isArray(playlist?.songs) ? playlist.songs : [];
    const firstSong = playlistSongs.length > 0 ? playlistSongs[0] : null;

    if (!firstSong) {
      console.log("Playlist has no songs to play");
      return;
    }

    const initialIndex = playlistSongs.findIndex((song) => {
      const left = song?._id || song?.id;
      const right = firstSong?._id || firstSong?.id;
      return left && right ? left === right : song === firstSong;
    });

    try {
      window.dispatchEvent(
        new CustomEvent("play-song", {
          detail: {
            song: firstSong,
            queue: playlistSongs,
            queueIndex: initialIndex >= 0 ? initialIndex : 0,
            playlistName: playlist?.name || playlist?.id || "Playlist",
          },
        })
      );
    } catch (e) {}

    const id = firstSong?._id || firstSong?.id;
    if (id) {
      (async () => {
        try {
          console.log("[Play] Sending POST /api/songs/" + id + "/play");
          const res = await axios.post(`/api/songs/${id}/play`);
          console.log("[Play] Response", {
            status: res.status,
            data: res.data,
          });
        } catch (err) {
          console.log(
            "[Play] Request failed",
            err?.response
              ? { status: err.response.status, data: err.response.data }
              : err
          );
        }
      })();
    }
  };

  const handleSongPlay = async (song) => {
    try {
      window.dispatchEvent(
        new CustomEvent("play-song", {
          detail: {
            song,
            queue: [song],
            queueIndex: 0,
          },
        })
      );
    } catch {}
    const id = song?._id || song?.id;
    if (id) {
      (async () => {
        try {
          console.log("[Play] Sending POST /api/songs/" + id + "/play");
          const res = await axios.post(`/api/songs/${id}/play`);
          console.log("[Play] Response", {
            status: res.status,
            data: res.data,
          });
        } catch (err) {
          console.log(
            "[Play] Request failed",
            err?.response
              ? { status: err.response.status, data: err.response.data }
              : err
          );
        }
      })();
    }
  };

  const handleSongLike = (songId, isLiked) => {
    console.log("Song liked:", songId, isLiked);
  };

  const handleSongDislike = (songId, isDisliked) => {
    console.log("Song disliked:", songId, isDisliked);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20,
      },
    },
  };

  return (
    <motion.div
      className="min-h-screen bg-gradient-to-br from-spotify-black via-spotify-dark-gray to-spotify-light-gray pt-16 relative overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-spotify-green rounded-full opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        {/* Hero Section */}
        <motion.div
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="flex items-center justify-center mb-6"
            variants={itemVariants}
          >
            <motion.div
              className="w-20 h-20 bg-gradient-to-br from-spotify-green to-spotify-blue rounded-full flex items-center justify-center shadow-2xl mr-4"
              animate={{
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <Music className="h-10 w-10 text-white" />
            </motion.div>
            <div className="text-left">
              <motion.h1
                className="text-5xl md:text-7xl font-black text-spotify-text mb-2"
                variants={itemVariants}
              >
                Discover Music for Your
                <span className="block gradient-text animate-pulse-slow">
                  {" "}
                  Mood
                </span>
              </motion.h1>
            </div>
          </motion.div>

          <motion.p
            className="text-xl md:text-2xl text-spotify-text-secondary max-w-3xl mx-auto leading-relaxed"
            variants={itemVariants}
          >
            BeatBuddy uses crowdsourced mood detection from user comments to
            create personalized playlists
          </motion.p>

          {/* Floating sparkles */}
          <motion.div
            className="flex justify-center mt-8 space-x-4"
            variants={itemVariants}
          >
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  y: [0, -10, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.3,
                }}
              >
                <Sparkles className="h-6 w-6 text-spotify-green" />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Mood Selection Section */}
        <motion.section
          className="mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <MoodSelector
            selectedMood={selectedMood}
            onMoodSelect={handleMoodSelect}
          />
        </motion.section>

        {/* Mood-Based Playlists */}
        <AnimatePresence mode="wait">
          {moodPlaylists.length > 0 && (
            <motion.section
              className="mb-16"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit={{ opacity: 0, y: -50 }}
              transition={{ duration: 0.5 }}
            >
              <motion.div
                className="flex items-center space-x-3 mb-8"
                variants={itemVariants}
              >
                <div className="w-12 h-12 bg-gradient-to-br from-spotify-green to-spotify-blue rounded-xl flex items-center justify-center shadow-lg">
                  <Music className="h-6 w-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold gradient-text">
                  {selectedMood
                    ? `${
                        selectedMood.charAt(0).toUpperCase() +
                        selectedMood.slice(1)
                      } Playlists`
                    : "Mood-Based Playlists"}
                </h2>
              </motion.div>

              <motion.div
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
                variants={containerVariants}
              >
                {moodPlaylists.map((playlist, index) => (
                  <motion.div
                    key={playlist.id}
                    variants={itemVariants}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.2 }}
                  >
                    <PlaylistCard
                      playlist={playlist}
                      onPlay={handlePlaylistPlay}
                    />
                  </motion.div>
                ))}
              </motion.div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Recent Comments Feed */}
        {recentComments.length > 0 && (
          <motion.section
            className="mb-16"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.div
              className="flex items-center space-x-3 mb-8"
              variants={itemVariants}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-spotify-purple to-spotify-pink rounded-xl flex items-center justify-center shadow-lg">
                <Brain className="h-6 w-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold gradient-text">
                Recent Mood Insights
              </h2>
            </motion.div>

            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
            >
              {recentComments.slice(0, 6).map((comment, index) => (
                <motion.div
                  key={comment.id}
                  variants={itemVariants}
                  className="bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray p-4 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300"
                  whileHover={{ scale: 1.02, y: -2 }}
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-spotify-green to-spotify-blue rounded-full flex items-center justify-center flex-shrink-0">
                      <Star className="h-4 w-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-spotify-text mb-2 line-clamp-2">
                        "{comment.text}"
                      </p>
                      <div className="flex items-center justify-between text-xs text-spotify-text-secondary">
                        <span>{comment.username}</span>
                        <span>
                          {comment.songTitle} - {comment.songArtist}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.section>
        )}

        {/* Recent Songs */}
        <motion.section
          className="mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="flex items-center space-x-3 mb-8"
            variants={itemVariants}
          >
            <div className="w-12 h-12 bg-gradient-to-br from-spotify-purple to-spotify-pink rounded-xl flex items-center justify-center shadow-lg">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-3xl font-bold gradient-text">
              Recently Discussed
            </h2>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={containerVariants}
          >
            {recentSongs.map((song, index) => (
              <motion.div
                key={song.id}
                variants={itemVariants}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <SongCard
                  song={song}
                  onPlay={handleSongPlay}
                  onLike={handleSongLike}
                  onDislike={handleSongDislike}
                />
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        {/* Trending Songs */}
        <motion.section
          className="mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="flex items-center space-x-3 mb-8"
            variants={itemVariants}
          >
            <div className="w-12 h-12 bg-gradient-to-br from-spotify-orange to-spotify-red rounded-xl flex items-center justify-center shadow-lg">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-3xl font-bold gradient-text">Trending Now</h2>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={containerVariants}
          >
            {trendingSongs.map((song, index) => (
              <motion.div
                key={song.id}
                variants={itemVariants}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <SongCard
                  song={song}
                  onPlay={handleSongPlay}
                  onLike={handleSongLike}
                  onDislike={handleSongDislike}
                />
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        {/* Call to Action */}
        <motion.div
          className="text-center py-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="relative bg-gradient-to-r from-spotify-green via-spotify-blue to-spotify-purple p-12 rounded-3xl shadow-2xl overflow-hidden"
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            {/* Animated background */}
            <div className="absolute inset-0 bg-gradient-to-r from-spotify-green via-spotify-blue to-spotify-purple opacity-20 animate-gradient-x" />

            <motion.div
              className="relative z-10"
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Brain className="h-20 w-20 text-white mx-auto mb-6 drop-shadow-lg" />
            </motion.div>

            <motion.h3
              className="text-3xl font-bold text-white mb-4"
              variants={itemVariants}
            >
              Ready to discover your perfect mood music?
            </motion.h3>

            <motion.p
              className="text-white/90 text-lg mb-8 max-w-2xl mx-auto"
              variants={itemVariants}
            >
              Join our community and help create the most accurate mood-based
              music recommendations through your comments
            </motion.p>

            <motion.div
              className="flex justify-center space-x-4"
              variants={itemVariants}
            >
              {[...Array(5)].map((_, i) => (
                <motion.div
                  key={i}
                  className="w-2 h-2 bg-white rounded-full"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    delay: i * 0.2,
                  }}
                />
              ))}
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default HomePage;
