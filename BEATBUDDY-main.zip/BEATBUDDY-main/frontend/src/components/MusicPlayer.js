import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Shuffle,
  Repeat,
} from "lucide-react";

const FALLBACK_AUDIO_URL =
  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";

const getFallbackCover = (seed) =>
  `https://picsum.photos/60/60?random=${
    seed ?? Math.floor(Math.random() * 1000)
  }`;

const isPlayableStream = (url) => {
  if (typeof url !== "string") return false;
  return (
    /(mp3|wav|ogg|aac|m4a)(\?|$)/i.test(url) && !url.includes("example.com")
  );
};

const firstNonEmptyString = (...values) => {
  for (const value of values) {
    if (typeof value === "string" && value.trim().length) {
      return value.trim();
    }
  }
  return "";
};

const normalizeSong = (rawSong, { playlistName, index } = {}) => {
  if (!rawSong) return null;

  const audioCandidate = firstNonEmptyString(
    rawSong.audioUrl,
    rawSong.previewUrl,
    rawSong.streamUrl,
    rawSong.mediaUrl
  );

  return {
    id:
      rawSong._id ||
      rawSong.id ||
      rawSong.externalId ||
      `${Date.now()}-${Math.random()}`,
    title: firstNonEmptyString(rawSong.title, rawSong.name) || "Unknown Title",
    artist:
      firstNonEmptyString(
        rawSong.artist,
        rawSong.author,
        rawSong.channelTitle
      ) || "Unknown Artist",
    coverImage:
      firstNonEmptyString(
        rawSong.coverImage,
        rawSong.thumbnail,
        rawSong.imageUrl
      ) || getFallbackCover(index),
    audioUrl: isPlayableStream(audioCandidate)
      ? audioCandidate
      : FALLBACK_AUDIO_URL,
    original: rawSong,
    playlistName: playlistName || rawSong.playlistName || null,
  };
};

const findQueueIndex = (queue, rawSong, fallbackIndex = 0) => {
  if (!rawSong) return Math.max(0, Math.min(fallbackIndex, queue.length - 1));
  const rawIds = [rawSong._id, rawSong.id, rawSong.externalId].filter(Boolean);

  const idx = queue.findIndex((entry) => {
    if (!entry) return false;
    if (entry.original === rawSong) return true;
    const entryIds = [
      entry.original?._id,
      entry.original?.id,
      entry.original?.externalId,
      entry.id,
    ].filter(Boolean);
    return rawIds.some((id) => entryIds.includes(id));
  });

  if (idx >= 0) return idx;
  return Math.max(0, Math.min(fallbackIndex, queue.length - 1));
};

const formatTime = (value) => {
  if (!Number.isFinite(value) || value < 0) return "0:00";
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60);
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
};

const MusicPlayer = () => {
  const [queue, setQueue] = useState([]);
  const [queueIndex, setQueueIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);

  const audioRef = useRef(null);
  const lastSongIdRef = useRef(null);

  const currentSong = queue.length
    ? queue[Math.min(queueIndex, queue.length - 1)]
    : null;

  useEffect(() => {
    const handleGlobalPlay = (event) => {
      const detail = event.detail || {};
      const playlistName = detail.playlistName || detail.playlist?.name || null;
      const incomingQueue = Array.isArray(detail.queue)
        ? detail.queue
        : detail.playlist?.songs || [];

      let normalizedQueue = incomingQueue
        .map((song, index) => normalizeSong(song, { playlistName, index }))
        .filter(Boolean);

      if (!normalizedQueue.length && detail.song) {
        const single = normalizeSong(detail.song, { playlistName, index: 0 });
        if (single) normalizedQueue = [single];
      }

      if (!normalizedQueue.length) return;

      const startIndex = findQueueIndex(
        normalizedQueue,
        detail.song,
        typeof detail.queueIndex === "number" ? detail.queueIndex : 0
      );

      setQueue(normalizedQueue);
      setQueueIndex(startIndex);
      setIsPlaying(true);
      setCurrentTime(0);
      setDuration(0);
    };

    window.addEventListener("play-song", handleGlobalPlay);
    return () => window.removeEventListener("play-song", handleGlobalPlay);
  }, []);

  useEffect(() => {
    const handleGlobalPause = () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
    };

    const handleGlobalResume = () => {
      if (!audioRef.current) return;
      audioRef.current.volume = isMuted ? 0 : volume;
      const playPromise = audioRef.current.play();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(() => {});
      }
      setIsPlaying(true);
    };

    window.addEventListener("pause-song", handleGlobalPause);
    window.addEventListener("resume-song", handleGlobalResume);

    return () => {
      window.removeEventListener("pause-song", handleGlobalPause);
      window.removeEventListener("resume-song", handleGlobalResume);
    };
  }, [isMuted, volume]);

  useEffect(() => {
    if (!audioRef.current) return;
    audioRef.current.volume = isMuted ? 0 : volume;
  }, [isMuted, volume]);

  useEffect(() => {
    if (!audioRef.current || !currentSong) return;

    const audio = audioRef.current;
    const currentId = currentSong.id;

    if (lastSongIdRef.current === currentId) {
      audio.volume = isMuted ? 0 : volume;
      return;
    }

    lastSongIdRef.current = currentId;

    audio.pause();
    audio.src = currentSong.audioUrl;
    audio.currentTime = 0;
    audio.volume = isMuted ? 0 : volume;
    setCurrentTime(0);
    setDuration(0);

    const playPromise = audio.play();
    if (playPromise && typeof playPromise.catch === "function") {
      playPromise.catch(() => {});
    }

    setIsPlaying(true);
  }, [currentSong, isMuted, volume]);

  const handlePlayPause = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
      try {
        window.dispatchEvent(
          new CustomEvent("pause-song", {
            detail: { id: currentSong?.id },
          })
        );
      } catch (error) {
        console.error("Pause event dispatch failed:", error);
      }
    } else {
      const playPromise = audioRef.current.play();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(() => {});
      }
      setIsPlaying(true);
      try {
        window.dispatchEvent(
          new CustomEvent("resume-song", {
            detail: { id: currentSong?.id },
          })
        );
      } catch (error) {
        console.error("Resume event dispatch failed:", error);
      }
    }
  };

  const handleNext = () => {
    if (!queue.length) return;

    if (isShuffle && queue.length > 1) {
      setQueueIndex((prev) => {
        let next = prev;
        while (next === prev) {
          next = Math.floor(Math.random() * queue.length);
        }
        return next;
      });
      return;
    }

    setQueueIndex((prev) => {
      if (prev + 1 >= queue.length) {
        if (isRepeat) {
          return 0;
        }
        setIsPlaying(false);
        return prev;
      }
      return prev + 1;
    });
  };

  const handlePrevious = () => {
    if (!queue.length) return;

    if (audioRef.current && audioRef.current.currentTime > 5) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      return;
    }

    if (isShuffle && queue.length > 1) {
      setQueueIndex((prev) => {
        let next = prev;
        while (next === prev) {
          next = Math.floor(Math.random() * queue.length);
        }
        return next;
      });
      return;
    }

    setQueueIndex((prev) => {
      if (prev === 0) {
        return isRepeat ? Math.max(queue.length - 1, 0) : 0;
      }
      return prev - 1;
    });
  };

  const handleTimeUpdate = () => {
    if (!audioRef.current) return;
    setCurrentTime(audioRef.current.currentTime || 0);
    const metaDuration = audioRef.current.duration;
    if (Number.isFinite(metaDuration)) {
      setDuration(metaDuration);
    }
  };

  const handleLoadedMetadata = () => {
    if (!audioRef.current) return;
    const metaDuration = audioRef.current.duration;
    setDuration(Number.isFinite(metaDuration) ? metaDuration : 0);
  };

  const handleSeek = (event) => {
    if (!audioRef.current || duration <= 0) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const percent = (event.clientX - rect.left) / rect.width;
    const newTime = Math.max(0, Math.min(percent * duration, duration));
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (event) => {
    const newVolume = parseFloat(event.target.value);
    setVolume(newVolume);
    if (newVolume === 0) {
      setIsMuted(true);
    } else {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      setIsMuted(false);
      audioRef.current.volume = volume;
    } else {
      setIsMuted(true);
      audioRef.current.volume = 0;
    }
  };

  const handleEnded = () => {
    if (isRepeat) {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        const playPromise = audioRef.current.play();
        if (playPromise && typeof playPromise.catch === "function") {
          playPromise.catch(() => {});
        }
      }
      setIsPlaying(true);
      return;
    }

    if ((isShuffle && queue.length > 1) || queue.length > 1) {
      handleNext();
      return;
    }

    setIsPlaying(false);
    setCurrentTime(0);
  };

  if (!currentSong) {
    return null;
  }

  return (
    <motion.div
      className="fixed bottom-0 left-0 right-0 bg-spotify-dark-gray border-t border-spotify-light-gray z-40"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <audio
        key={currentSong.id}
        ref={audioRef}
        src={currentSong.audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleEnded}
      />

      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1 min-w-0">
            <img
              src={currentSong.coverImage}
              alt={currentSong.title}
              className="w-12 h-12 rounded-md object-cover"
            />
            <div className="min-w-0">
              <h4 className="font-medium text-spotify-text truncate">
                {currentSong.title}
              </h4>
              <p className="text-sm text-spotify-text-secondary truncate">
                {currentSong.artist}
                {currentSong.playlistName
                  ? ` • ${currentSong.playlistName}`
                  : ""}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <motion.button
              onClick={() => setIsShuffle((prev) => !prev)}
              className={`transition-colors ${
                isShuffle
                  ? "text-spotify-green"
                  : "text-spotify-text-secondary hover:text-spotify-text"
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Shuffle className="h-5 w-5" />
            </motion.button>

            <motion.button
              onClick={handlePrevious}
              className="text-spotify-text-secondary hover:text-spotify-text transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SkipBack className="h-5 w-5" />
            </motion.button>

            <motion.button
              onClick={handlePlayPause}
              className="bg-spotify-green text-spotify-black p-2 rounded-full hover:bg-green-400 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isPlaying ? (
                <Pause className="h-6 w-6" />
              ) : (
                <Play className="h-6 w-6 ml-1" />
              )}
            </motion.button>

            <motion.button
              onClick={handleNext}
              className="text-spotify-text-secondary hover:text-spotify-text transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <SkipForward className="h-5 w-5" />
            </motion.button>

            <motion.button
              onClick={() => setIsRepeat((prev) => !prev)}
              className={`transition-colors ${
                isRepeat
                  ? "text-spotify-green"
                  : "text-spotify-text-secondary hover:text-spotify-text"
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Repeat className="h-5 w-5" />
            </motion.button>
          </div>

          <div className="flex items-center space-x-2 flex-1 justify-end">
            <motion.button
              onClick={toggleMute}
              className="text-spotify-text-secondary hover:text-spotify-text transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isMuted ? (
                <VolumeX className="h-5 w-5" />
              ) : (
                <Volume2 className="h-5 w-5" />
              )}
            </motion.button>

            <div className="w-24">
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-full h-1 bg-spotify-light-gray rounded-lg appearance-none cursor-pointer slider"
              />
            </div>
          </div>
        </div>

        <div className="mt-3">
          <div
            className="w-full h-1 bg-spotify-light-gray rounded-full cursor-pointer relative"
            onClick={handleSeek}
          >
            <motion.div
              className="h-full bg-spotify-green rounded-full"
              style={{
                width:
                  duration > 0 ? `${(currentTime / duration) * 100}%` : "0%",
              }}
              initial={{ width: 0 }}
              animate={{
                width:
                  duration > 0 ? `${(currentTime / duration) * 100}%` : "0%",
              }}
            />
          </div>
          <div className="flex justify-between text-xs text-spotify-text-secondary mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
      </div>

      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 12px;
          width: 12px;
          border-radius: 50%;
          background: #1db954;
          cursor: pointer;
        }

        .slider::-moz-range-thumb {
          height: 12px;
          width: 12px;
          border-radius: 50%;
          background: #1db954;
          cursor: pointer;
          border: none;
        }
      `}</style>
    </motion.div>
  );
};

export default MusicPlayer;
