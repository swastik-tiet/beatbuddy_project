import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Play, 
  Heart, 
  Clock, 
  Music,
  Users,
  Sparkles
} from 'lucide-react';
import { moodDetectionService } from '../services/moodDetectionService';

const PlaylistCard = ({ 
  playlist, 
  onPlay, 
  onLike,
  className = '' 
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(playlist?.isLiked || false);

  const handlePlay = () => {
    onPlay?.(playlist);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    onLike?.(playlist.id, !isLiked);
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.9 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    },
    hover: {
      y: -8,
      scale: 1.02,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    }
  };

  return (
    <motion.div
      className={`relative group card-hover interactive-card ${className}`}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <div className="bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray rounded-2xl p-4 border border-white/10 overflow-hidden">
        {/* Cover Image Container */}
        <div className="relative aspect-square rounded-xl overflow-hidden mb-4 group">
          <motion.img
            src={playlist.coverImage || `https://picsum.photos/300/300?random=${playlist.id}`}
            alt={playlist.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play Button Overlay */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <motion.button
                  onClick={handlePlay}
                  className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white p-4 rounded-full shadow-2xl hover:shadow-spotify-green/30 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Play className="h-6 w-6 ml-1" />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Shimmer effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
          </div>

          {/* Mood indicator */}
          <div className="absolute top-2 left-2">
            <div className={`px-2 py-1 rounded-full text-xs font-medium text-white shadow-lg ${moodDetectionService.getMoodColor(playlist.mood)}`}>
              {moodDetectionService.getMoodEmoji(playlist.mood)} {moodDetectionService.getMoodDisplayName(playlist.mood)}
            </div>
          </div>
        </div>

        {/* Playlist Info */}
        <div className="space-y-3">
          <Link to={`/playlist/${playlist.id}`}>
            <motion.h3 
              className="font-bold text-spotify-text hover:text-spotify-green transition-colors duration-300 truncate text-lg"
              whileHover={{ x: 5 }}
            >
              {playlist.name}
            </motion.h3>
          </Link>
          
          <p className="text-sm text-spotify-text-secondary line-clamp-2">
            {playlist.description}
          </p>

          {/* Stats */}
          <div className="flex items-center justify-between text-xs text-spotify-text-secondary">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Music className="h-3 w-3" />
                <span>{playlist.songCount} songs</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>{playlist.duration}</span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className="h-3 w-3" />
              <span>{playlist.likes.toLocaleString()}</span>
            </div>
          </div>

          {/* Mood Distribution */}
          {playlist.moodDistribution && (
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-xs text-spotify-text-secondary">
                <Sparkles className="h-3 w-3" />
                <span>Mood breakdown</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {Object.entries(playlist.moodDistribution)
                  .sort(([,a], [,b]) => b - a)
                  .slice(0, 3)
                  .map(([mood, count]) => (
                    <motion.span
                      key={mood}
                      className={`px-2 py-1 text-xs rounded-full text-white font-medium shadow-sm ${moodDetectionService.getMoodColor(mood)}`}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      whileHover={{ scale: 1.1 }}
                    >
                      {moodDetectionService.getMoodDisplayName(mood)} ({count})
                    </motion.span>
                  ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <motion.button
              onClick={handleLike}
              className={`p-2 rounded-full transition-all duration-300 ${
                isLiked 
                  ? 'text-red-500 bg-red-500/20 shadow-lg' 
                  : 'text-spotify-text-secondary hover:text-red-500 hover:bg-red-500/20'
              }`}
              whileHover={{ scale: 1.1, rotate: 5 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart className={`h-4 w-4 ${isLiked ? 'fill-current animate-heartbeat' : ''}`} />
            </motion.button>

            <div className="flex items-center space-x-2 text-xs text-spotify-text-secondary">
              <Users className="h-3 w-3" />
              <span>Crowdsourced</span>
            </div>
          </div>
        </div>
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-spotify-green rounded-full opacity-0 group-hover:opacity-100"
              style={{
                left: `${20 + i * 30}%`,
                top: `${10 + i * 20}%`,
              }}
              animate={{
                y: [0, -20, 0],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.5,
              }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default PlaylistCard;
