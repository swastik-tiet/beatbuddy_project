import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Heart, 
  MessageCircle, 
  User,
  Sparkles,
  Clock
} from 'lucide-react';
import { moodDetectionService } from '../services/moodDetectionService';

const CommentSection = ({ 
  comments = [], 
  onAddComment, 
  songId,
  className = '' 
}) => {
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [detectedMood, setDetectedMood] = useState(null);
  const [showMoodPreview, setShowMoodPreview] = useState(false);

  const handleCommentChange = (e) => {
    const text = e.target.value;
    setNewComment(text);
    
    // Detect mood as user types (with debounce)
    if (text.length > 10) {
      const mood = moodDetectionService.detectMood(text);
      setDetectedMood(mood);
      setShowMoodPreview(true);
    } else {
      setDetectedMood(null);
      setShowMoodPreview(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim() || isSubmitting) return;

    setIsSubmitting(true);
    
    try {
      // Create new comment object
      const comment = {
        id: Date.now(),
        userId: 'currentUser',
        username: 'You',
        text: newComment.trim(),
        timestamp: new Date().toISOString(),
        likes: 0,
        mood: detectedMood || 'neutral'
      };

      await onAddComment?.(comment, songId);
      setNewComment('');
      setDetectedMood(null);
      setShowMoodPreview(false);
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Comment Input */}
      <motion.div
        className="bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray rounded-2xl p-6 border border-white/10"
        variants={itemVariants}
        initial="hidden"
        animate="visible"
      >
        <h3 className="text-lg font-semibold text-spotify-text mb-4 flex items-center">
          <MessageCircle className="h-5 w-5 mr-2 text-spotify-green" />
          Share your thoughts
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <textarea
              value={newComment}
              onChange={handleCommentChange}
              placeholder="How does this song make you feel? Share your mood..."
              className="w-full h-24 bg-spotify-black/50 border border-white/10 rounded-xl p-4 text-spotify-text placeholder-spotify-text-secondary resize-none focus:outline-none focus:ring-2 focus:ring-spotify-green/50 focus:border-spotify-green/50 transition-all duration-300"
              disabled={isSubmitting}
            />
            
            {/* Mood Preview */}
            <AnimatePresence>
              {showMoodPreview && detectedMood && (
                <motion.div
                  className="absolute top-2 right-2"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className={`px-3 py-1 rounded-full text-xs font-medium text-white shadow-lg ${moodDetectionService.getMoodColor(detectedMood)}`}>
                    <div className="flex items-center space-x-1">
                      <Sparkles className="h-3 w-3" />
                      <span>{moodDetectionService.getMoodDisplayName(detectedMood)}</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-xs text-spotify-text-secondary">
              {newComment.length > 0 && (
                <span>Mood detected: {detectedMood ? moodDetectionService.getMoodDisplayName(detectedMood) : 'Analyzing...'}</span>
              )}
            </div>
            
            <motion.button
              type="submit"
              disabled={!newComment.trim() || isSubmitting}
              className={`px-6 py-2 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                newComment.trim() && !isSubmitting
                  ? 'bg-gradient-to-r from-spotify-green to-spotify-blue text-white hover:shadow-lg hover:scale-105'
                  : 'bg-spotify-dark-gray text-spotify-text-secondary cursor-not-allowed'
              }`}
              whileHover={newComment.trim() && !isSubmitting ? { scale: 1.05 } : {}}
              whileTap={newComment.trim() && !isSubmitting ? { scale: 0.95 } : {}}
            >
              <Send className="h-4 w-4" />
              <span>{isSubmitting ? 'Posting...' : 'Post Comment'}</span>
            </motion.button>
          </div>
        </form>
      </motion.div>

      {/* Comments List */}
      <motion.div
        className="space-y-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <h3 className="text-lg font-semibold text-spotify-text flex items-center">
          <MessageCircle className="h-5 w-5 mr-2 text-spotify-green" />
          Comments ({comments.length})
        </h3>
        
        {comments.length === 0 ? (
          <motion.div
            className="text-center py-8 text-spotify-text-secondary"
            variants={itemVariants}
          >
            <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No comments yet. Be the first to share your thoughts!</p>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {comments.map((comment, index) => (
              <motion.div
                key={comment.id}
                variants={itemVariants}
                className="bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray rounded-xl p-4 border border-white/10 hover:border-white/20 transition-all duration-300"
              >
                <div className="flex items-start space-x-3">
                  {/* User Avatar */}
                  <div className="w-10 h-10 bg-gradient-to-br from-spotify-green to-spotify-blue rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="h-5 w-5 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    {/* Comment Header */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-spotify-text">
                          {comment.username}
                        </span>
                        
                        {/* Mood Tag */}
                        <motion.span
                          className={`px-2 py-1 text-xs rounded-full text-white font-medium shadow-sm ${moodDetectionService.getMoodColor(comment.mood)}`}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          {moodDetectionService.getMoodEmoji(comment.mood)} {moodDetectionService.getMoodDisplayName(comment.mood)}
                        </motion.span>
                      </div>
                      
                      <div className="flex items-center space-x-2 text-xs text-spotify-text-secondary">
                        <Clock className="h-3 w-3" />
                        <span>{formatTimestamp(comment.timestamp)}</span>
                      </div>
                    </div>
                    
                    {/* Comment Text */}
                    <p className="text-spotify-text text-sm leading-relaxed mb-3">
                      {comment.text}
                    </p>
                    
                    {/* Comment Actions */}
                    <div className="flex items-center space-x-4">
                      <motion.button
                        className="flex items-center space-x-1 text-spotify-text-secondary hover:text-spotify-green transition-colors duration-300"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Heart className="h-4 w-4" />
                        <span className="text-xs">{comment.likes}</span>
                      </motion.button>
                      
                      <motion.button
                        className="flex items-center space-x-1 text-spotify-text-secondary hover:text-spotify-blue transition-colors duration-300"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <MessageCircle className="h-4 w-4" />
                        <span className="text-xs">Reply</span>
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default CommentSection;
