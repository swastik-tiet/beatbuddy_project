import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Play, 
  Heart, 
  ThumbsDown, 
  MoreHorizontal,
  Pause,
  Volume2
} from 'lucide-react';
import { moodDetectionService } from '../services/moodDetectionService';

const SongCard = ({ 
  song, 
  isPlaying = false, 
  onPlay, 
  onPause, 
  onLike, 
  onDislike,
  showMoodTags = true,
  className = '' 
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(song?.isLiked || false);
  const [isDisliked, setIsDisliked] = useState(song?.isDisliked || false);

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause?.();
    } else {
      onPlay?.(song);
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
    onLike?.(song.id, !isLiked);
  };

  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
    onDislike?.(song.id, !isDisliked);
  };

  // Get mood distribution from comments
  const getMoodDistribution = () => {
    if (!song.comments) return {};
    
    return song.comments.reduce((acc, comment) => {
      acc[comment.mood] = (acc[comment.mood] || 0) + 1;
      return acc;
    }, {});
  };

  const moodDistribution = getMoodDistribution();
  const topMoods = Object.entries(moodDistribution)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 3);

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.9 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    },
    hover: {
      y: -8,
      scale: 1.02,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    }
  };

  return (
    <motion.div
      className={`relative group card-hover interactive-card ${className}`}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <div className="bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray rounded-2xl p-4 border border-white/10 overflow-hidden">
        {/* Cover Image Container */}
        <div className="relative aspect-square rounded-xl overflow-hidden mb-4 group">
          <motion.img
            src={song.coverImage || `https://picsum.photos/300/300?random=${song.id}`}
            alt={song.title}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play Button Overlay */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <motion.button
                  onClick={handlePlayPause}
                  className="bg-gradient-to-r from-spotify-green to-spotify-blue text-white p-4 rounded-full shadow-2xl hover:shadow-spotify-green/30 transition-all duration-300"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {isPlaying ? (
                    <Pause className="h-6 w-6" />
                  ) : (
                    <Play className="h-6 w-6 ml-1" />
                  )}
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Music wave animation when playing */}
          {isPlaying && (
            <motion.div
              className="absolute bottom-2 left-2 music-wave"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </motion.div>
          )}

          {/* Shimmer effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
          </div>
        </div>

        {/* Song Info */}
        <div className="space-y-3">
          <Link to={`/song/${song.id}`}>
            <motion.h3 
              className="font-bold text-spotify-text hover:text-spotify-green transition-colors duration-300 truncate text-lg"
              whileHover={{ x: 5 }}
            >
              {song.title}
            </motion.h3>
          </Link>
          <p className="text-sm text-spotify-text-secondary truncate">
            {song.artist}
          </p>

          {/* Mood Tags from Comments */}
          {showMoodTags && topMoods.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {topMoods.map(([mood, count], index) => (
                <motion.span
                  key={mood}
                  className={`px-3 py-1 text-xs rounded-full text-white font-medium shadow-lg ${moodDetectionService.getMoodColor(mood)}`}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.1 }}
                >
                  {moodDetectionService.getMoodDisplayName(mood)} ({count})
                </motion.span>
              ))}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2">
              <motion.button
                onClick={handleLike}
                className={`p-2 rounded-full transition-all duration-300 ${
                  isLiked 
                    ? 'text-red-500 bg-red-500/20 shadow-lg' 
                    : 'text-spotify-text-secondary hover:text-red-500 hover:bg-red-500/20'
                }`}
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
              >
                <Heart className={`h-4 w-4 ${isLiked ? 'fill-current animate-heartbeat' : ''}`} />
              </motion.button>
              
              <motion.button
                onClick={handleDislike}
                className={`p-2 rounded-full transition-all duration-300 ${
                  isDisliked 
                    ? 'text-blue-500 bg-blue-500/20 shadow-lg' 
                    : 'text-spotify-text-secondary hover:text-blue-500 hover:bg-blue-500/20'
                }`}
                whileHover={{ scale: 1.1, rotate: -5 }}
                whileTap={{ scale: 0.9 }}
              >
                <ThumbsDown className={`h-4 w-4 ${isDisliked ? 'fill-current' : ''}`} />
              </motion.button>
            </div>

            <motion.button
              className="p-2 text-spotify-text-secondary hover:text-spotify-text rounded-full hover:bg-white/10 transition-all duration-300"
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
            >
              <MoreHorizontal className="h-4 w-4" />
            </motion.button>
          </div>
        </div>
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-spotify-green rounded-full opacity-0 group-hover:opacity-100"
              style={{
                left: `${20 + i * 30}%`,
                top: `${10 + i * 20}%`,
              }}
              animate={{
                y: [0, -20, 0],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.5,
              }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default SongCard;
