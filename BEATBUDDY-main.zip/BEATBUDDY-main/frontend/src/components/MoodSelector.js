import React from 'react';
import { motion } from 'framer-motion';
import { 
  Smile, 
  Frown, 
  Zap, 
  Heart, 
  Coffee, 
  Moon, 
  Sun, 
  Music,
  Star,
  Flame
} from 'lucide-react';

const MoodSelector = ({ selectedMood, onMoodSelect, className = '' }) => {
  const moods = [
    { 
      id: 'happy', 
      label: 'Happy', 
      icon: Smile, 
      color: 'from-spotify-yellow to-orange-400',
      bgColor: 'bg-gradient-to-br from-spotify-yellow to-orange-400',
      shadow: 'shadow-yellow-500/30'
    },
    { 
      id: 'sad', 
      label: 'Sad', 
      icon: Frown, 
      color: 'from-spotify-blue to-indigo-500',
      bgColor: 'bg-gradient-to-br from-spotify-blue to-indigo-500',
      shadow: 'shadow-blue-500/30'
    },
    { 
      id: 'energetic', 
      label: 'Energetic', 
      icon: Zap, 
      color: 'from-spotify-orange to-red-500',
      bgColor: 'bg-gradient-to-br from-spotify-orange to-red-500',
      shadow: 'shadow-orange-500/30'
    },
    { 
      id: 'calm', 
      label: 'Calm', 
      icon: Coffee, 
      color: 'from-teal-400 to-cyan-500',
      bgColor: 'bg-gradient-to-br from-teal-400 to-cyan-500',
      shadow: 'shadow-teal-500/30'
    },
    { 
      id: 'romantic', 
      label: 'Romantic', 
      icon: Heart, 
      color: 'from-spotify-pink to-rose-500',
      bgColor: 'bg-gradient-to-br from-spotify-pink to-rose-500',
      shadow: 'shadow-pink-500/30'
    },
    { 
      id: 'chill', 
      label: 'Chill', 
      icon: Moon, 
      color: 'from-indigo-500 to-purple-600',
      bgColor: 'bg-gradient-to-br from-indigo-500 to-purple-600',
      shadow: 'shadow-indigo-500/30'
    },
    { 
      id: 'upbeat', 
      label: 'Upbeat', 
      icon: Sun, 
      color: 'from-yellow-400 to-amber-500',
      bgColor: 'bg-gradient-to-br from-yellow-400 to-amber-500',
      shadow: 'shadow-yellow-500/30'
    },
    { 
      id: 'focused', 
      label: 'Focused', 
      icon: Star, 
      color: 'from-spotify-purple to-violet-600',
      bgColor: 'bg-gradient-to-br from-spotify-purple to-violet-600',
      shadow: 'shadow-purple-500/30'
    },
    { 
      id: 'party', 
      label: 'Party', 
      icon: Music, 
      color: 'from-spotify-red to-pink-600',
      bgColor: 'bg-gradient-to-br from-spotify-red to-pink-600',
      shadow: 'shadow-red-500/30'
    },
    { 
      id: 'intense', 
      label: 'Intense', 
      icon: Flame, 
      color: 'from-red-600 to-orange-600',
      bgColor: 'bg-gradient-to-br from-red-600 to-orange-600',
      shadow: 'shadow-red-500/30'
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { 
      opacity: 0, 
      y: 20, 
      scale: 0.8 
    },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  return (
    <div className={`${className}`}>
      <motion.h3 
        className="text-2xl font-bold text-spotify-text mb-6 text-center gradient-text"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        How are you feeling today?
      </motion.h3>
      
      <motion.div 
        className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {moods.map((mood, index) => {
          const Icon = mood.icon;
          const isSelected = selectedMood === mood.id;
          
          return (
            <motion.div
              key={mood.id}
              variants={itemVariants}
              whileHover={{ 
                scale: 1.05,
                y: -5,
                transition: { type: "spring", stiffness: 400, damping: 10 }
              }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.button
                onClick={() => onMoodSelect(mood.id)}
                className={`relative w-full aspect-square rounded-2xl transition-all duration-500 overflow-hidden group ${
                  isSelected
                    ? `${mood.bgColor} text-white shadow-xl ${mood.shadow} scale-105`
                    : 'bg-gradient-to-br from-spotify-light-gray to-spotify-dark-gray text-spotify-text-secondary hover:text-spotify-text border border-white/10'
                }`}
                whileHover={{
                  boxShadow: isSelected ? `0 20px 40px ${mood.shadow}` : "0 10px 30px rgba(0,0,0,0.3)"
                }}
              >
                {/* Background gradient overlay */}
                {!isSelected && (
                  <div className={`absolute inset-0 bg-gradient-to-br ${mood.color} opacity-0 group-hover:opacity-20 transition-opacity duration-300`} />
                )}
                
                {/* Shimmer effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                </div>

                {/* Content */}
                <div className="relative z-10 flex flex-col items-center justify-center h-full p-4">
                  <motion.div
                    className={`mb-3 ${isSelected ? 'animate-bounce-slow' : 'group-hover:animate-bounce'}`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className={`h-8 w-8 ${isSelected ? 'text-white' : 'group-hover:text-white transition-colors duration-300'}`} />
                  </motion.div>
                  
                  <span className={`text-sm font-semibold text-center ${isSelected ? 'text-white' : 'group-hover:text-white transition-colors duration-300'}`}>
                    {mood.label}
                  </span>
                </div>

                {/* Selection indicator */}
                {isSelected && (
                  <motion.div
                    className="absolute top-2 right-2 w-3 h-3 bg-white rounded-full"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}

                {/* Pulse effect for selected items */}
                {isSelected && (
                  <motion.div
                    className="absolute inset-0 rounded-2xl border-2 border-white/30"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  />
                )}
              </motion.button>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Interactive hint */}
      {!selectedMood && (
        <motion.div
          className="text-center mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <motion.p 
            className="text-spotify-text-secondary text-lg"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            ✨ Select your mood to discover personalized music
          </motion.p>
        </motion.div>
      )}
    </div>
  );
};

export default MoodSelector;
