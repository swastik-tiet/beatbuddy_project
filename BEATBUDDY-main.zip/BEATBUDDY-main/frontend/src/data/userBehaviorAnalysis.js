// User Behavior Analysis for Automatic Mood Detection
// This system learns from user's listening patterns to predict mood without explicit input

export class UserBehaviorAnalyzer {
  constructor() {
    this.userHistory = this.loadUserHistory();
    this.moodPatterns = this.initializeMoodPatterns();
    this.timeBasedPatterns = this.initializeTimePatterns();
    this.interactionPatterns = this.initializeInteractionPatterns();
  }

  // Load user's listening history from localStorage or initialize
  loadUserHistory() {
    const saved = localStorage.getItem('beatbuddy_user_history');
    return saved ? JSON.parse(saved) : {
      listeningHistory: [],
      likedSongs: [],
      dislikedSongs: [],
      playCounts: {},
      timeStamps: [],
      skipPatterns: {},
      sessionDurations: [],
      moodPredictions: []
    };
  }

  // Save user history to localStorage
  saveUserHistory() {
    localStorage.setItem('beatbuddy_user_history', JSON.stringify(this.userHistory));
  }

  // Initialize mood patterns based on audio features
  initializeMoodPatterns() {
    return {
      happy: {
        avgValence: 0.7,
        avgEnergy: 0.6,
        avgDanceability: 0.7,
        avgTempo: 120,
        commonGenres: ['Pop', 'Dance', 'Hip Hop'],
        timeOfDay: ['morning', 'afternoon']
      },
      sad: {
        avgValence: 0.3,
        avgEnergy: 0.4,
        avgDanceability: 0.4,
        avgTempo: 80,
        commonGenres: ['Soul', 'R&B', 'Indie'],
        timeOfDay: ['evening', 'night']
      },
      energetic: {
        avgValence: 0.6,
        avgEnergy: 0.8,
        avgDanceability: 0.8,
        avgTempo: 130,
        commonGenres: ['Rock', 'Electronic', 'Pop'],
        timeOfDay: ['morning', 'afternoon', 'evening']
      },
      calm: {
        avgValence: 0.5,
        avgEnergy: 0.3,
        avgDanceability: 0.4,
        avgTempo: 70,
        commonGenres: ['Ambient', 'Classical', 'Jazz'],
        timeOfDay: ['night', 'evening']
      },
      romantic: {
        avgValence: 0.6,
        avgEnergy: 0.4,
        avgDanceability: 0.5,
        avgTempo: 90,
        commonGenres: ['R&B', 'Soul', 'Pop'],
        timeOfDay: ['evening', 'night']
      },
      chill: {
        avgValence: 0.5,
        avgEnergy: 0.3,
        avgDanceability: 0.4,
        avgTempo: 75,
        commonGenres: ['Lo-fi', 'Ambient', 'Jazz'],
        timeOfDay: ['night', 'evening']
      },
      upbeat: {
        avgValence: 0.7,
        avgEnergy: 0.7,
        avgDanceability: 0.7,
        avgTempo: 110,
        commonGenres: ['Pop', 'Dance', 'Hip Hop'],
        timeOfDay: ['morning', 'afternoon']
      },
      focused: {
        avgValence: 0.4,
        avgEnergy: 0.5,
        avgDanceability: 0.3,
        avgTempo: 85,
        commonGenres: ['Classical', 'Instrumental', 'Ambient'],
        timeOfDay: ['morning', 'afternoon']
      },
      party: {
        avgValence: 0.8,
        avgEnergy: 0.9,
        avgDanceability: 0.9,
        avgTempo: 125,
        commonGenres: ['Dance', 'Electronic', 'Pop'],
        timeOfDay: ['evening', 'night']
      },
      intense: {
        avgValence: 0.4,
        avgEnergy: 0.8,
        avgDanceability: 0.5,
        avgTempo: 140,
        commonGenres: ['Rock', 'Metal', 'Electronic'],
        timeOfDay: ['afternoon', 'evening']
      }
    };
  }

  // Initialize time-based patterns
  initializeTimePatterns() {
    return {
      morning: ['happy', 'energetic', 'focused', 'upbeat'],
      afternoon: ['energetic', 'focused', 'intense', 'upbeat'],
      evening: ['romantic', 'chill', 'calm', 'party'],
      night: ['sad', 'calm', 'chill', 'romantic']
    };
  }

  // Initialize interaction patterns
  initializeInteractionPatterns() {
    return {
      highEngagement: ['happy', 'energetic', 'party'],
      lowEngagement: ['sad', 'calm', 'chill'],
      mixedEngagement: ['romantic', 'focused', 'intense']
    };
  }

  // Record a new listening session
  recordListeningSession(song, action = 'play', duration = null) {
    const session = {
      songId: song.id,
      song: song,
      action: action, // 'play', 'like', 'dislike', 'skip'
      timestamp: new Date().toISOString(),
      timeOfDay: this.getTimeOfDay(),
      duration: duration,
      audioFeatures: song.audioFeatures
    };

    this.userHistory.listeningHistory.push(session);
    this.userHistory.timeStamps.push(session.timestamp);

    // Update play counts
    this.userHistory.playCounts[song.id] = (this.userHistory.playCounts[song.id] || 0) + 1;

    // Record likes/dislikes
    if (action === 'like') {
      this.userHistory.likedSongs.push(song.id);
    } else if (action === 'dislike') {
      this.userHistory.dislikedSongs.push(song.id);
    }

    // Record skip patterns
    if (action === 'skip') {
      this.userHistory.skipPatterns[song.id] = (this.userHistory.skipPatterns[song.id] || 0) + 1;
    }

    this.saveUserHistory();
  }

  // Get current time of day
  getTimeOfDay() {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 17) return 'afternoon';
    if (hour >= 17 && hour < 22) return 'evening';
    return 'night';
  }

  // Analyze recent listening patterns to predict mood
  analyzeRecentBehavior(hours = 24) {
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
    const recentSessions = this.userHistory.listeningHistory.filter(
      session => new Date(session.timestamp) > cutoffTime
    );

    if (recentSessions.length === 0) {
      return this.getDefaultMood();
    }

    const moodScores = this.calculateMoodScores(recentSessions);
    const timeBasedMood = this.getTimeBasedMood();
    const interactionMood = this.getInteractionBasedMood(recentSessions);

    // Combine all factors to predict mood
    const finalMood = this.combineMoodFactors(moodScores, timeBasedMood, interactionMood);
    
    // Store prediction for learning
    this.userHistory.moodPredictions.push({
      timestamp: new Date().toISOString(),
      predictedMood: finalMood,
      confidence: this.calculateConfidence(moodScores)
    });

    this.saveUserHistory();
    return finalMood;
  }

  // Calculate mood scores based on audio features
  calculateMoodScores(sessions) {
    const moodScores = {};
    const audioFeatures = sessions.map(s => s.audioFeatures);

    // Calculate average audio features
    const avgFeatures = {
      valence: audioFeatures.reduce((sum, f) => sum + f.valence, 0) / audioFeatures.length,
      energy: audioFeatures.reduce((sum, f) => sum + f.energy, 0) / audioFeatures.length,
      danceability: audioFeatures.reduce((sum, f) => sum + f.danceability, 0) / audioFeatures.length,
      tempo: audioFeatures.reduce((sum, f) => sum + f.tempo, 0) / audioFeatures.length,
      acousticness: audioFeatures.reduce((sum, f) => sum + f.acousticness, 0) / audioFeatures.length,
      instrumentalness: audioFeatures.reduce((sum, f) => sum + f.instrumentalness, 0) / audioFeatures.length
    };

    // Score each mood based on how well it matches the audio features
    Object.keys(this.moodPatterns).forEach(mood => {
      const pattern = this.moodPatterns[mood];
      let score = 0;

      // Compare with mood patterns
      score += this.calculateSimilarity(avgFeatures.valence, pattern.avgValence) * 0.3;
      score += this.calculateSimilarity(avgFeatures.energy, pattern.avgEnergy) * 0.25;
      score += this.calculateSimilarity(avgFeatures.danceability, pattern.avgDanceability) * 0.2;
      score += this.calculateSimilarity(avgFeatures.tempo / 200, pattern.avgTempo / 200) * 0.15;
      score += this.calculateSimilarity(avgFeatures.acousticness, pattern.avgAcousticness || 0.5) * 0.1;

      moodScores[mood] = score;
    });

    return moodScores;
  }

  // Calculate similarity between two values (0-1)
  calculateSimilarity(value1, value2) {
    return 1 - Math.abs(value1 - value2);
  }

  // Get mood based on time of day
  getTimeBasedMood() {
    const timeOfDay = this.getTimeOfDay();
    const possibleMoods = this.timeBasedPatterns[timeOfDay];
    return possibleMoods[Math.floor(Math.random() * possibleMoods.length)];
  }

  // Get mood based on interaction patterns
  getInteractionBasedMood(sessions) {
    const likeCount = sessions.filter(s => s.action === 'like').length;
    const skipCount = sessions.filter(s => s.action === 'skip').length;
    const totalSessions = sessions.length;

    const engagementRate = likeCount / totalSessions;
    const skipRate = skipCount / totalSessions;

    if (engagementRate > 0.7) return 'happy';
    if (engagementRate > 0.5) return 'energetic';
    if (skipRate > 0.5) return 'sad';
    if (skipRate > 0.3) return 'calm';
    
    return 'focused';
  }

  // Combine different mood factors
  combineMoodFactors(moodScores, timeMood, interactionMood) {
    // Weight the different factors
    const weights = {
      audioFeatures: 0.5,
      timeOfDay: 0.3,
      interaction: 0.2
    };

    // Normalize mood scores
    const maxScore = Math.max(...Object.values(moodScores));
    const normalizedScores = {};
    Object.keys(moodScores).forEach(mood => {
      normalizedScores[mood] = moodScores[mood] / maxScore;
    });

    // Add weights for time and interaction
    normalizedScores[timeMood] = (normalizedScores[timeMood] || 0) + weights.timeOfDay;
    normalizedScores[interactionMood] = (normalizedScores[interactionMood] || 0) + weights.interaction;

    // Return the mood with highest score
    return Object.keys(normalizedScores).reduce((a, b) => 
      normalizedScores[a] > normalizedScores[b] ? a : b
    );
  }

  // Calculate confidence in mood prediction
  calculateConfidence(moodScores) {
    const scores = Object.values(moodScores);
    const maxScore = Math.max(...scores);
    const secondMaxScore = Math.max(...scores.filter(s => s !== maxScore));
    
    // Higher confidence if there's a clear winner
    return maxScore - secondMaxScore;
  }

  // Get default mood based on time of day
  getDefaultMood() {
    const timeOfDay = this.getTimeOfDay();
    const defaultMoods = {
      morning: 'energetic',
      afternoon: 'focused',
      evening: 'chill',
      night: 'calm'
    };
    return defaultMoods[timeOfDay];
  }

  // Get personalized recommendations based on learned patterns
  getPersonalizedRecommendations(songs, limit = 10) {
    const currentMood = this.analyzeRecentBehavior();
    const userPreferences = this.analyzeUserPreferences();
    
    // Score songs based on current mood and user preferences
    const scoredSongs = songs.map(song => {
      let score = 0;
      
      // Mood-based scoring
      const moodScore = this.calculateMoodScore(song, currentMood);
      score += moodScore * 0.4;
      
      // Preference-based scoring
      const preferenceScore = this.calculatePreferenceScore(song, userPreferences);
      score += preferenceScore * 0.3;
      
      // Popularity and recency
      score += (song.popularity / 100) * 0.2;
      score += this.calculateRecencyScore(song) * 0.1;
      
      return { ...song, personalScore: score };
    });

    return scoredSongs
      .sort((a, b) => b.personalScore - a.personalScore)
      .slice(0, limit)
      .map(song => {
        const { personalScore, ...songWithoutScore } = song;
        return songWithoutScore;
      });
  }

  // Analyze user preferences from history
  analyzeUserPreferences() {
    const likedSongs = this.userHistory.likedSongs;
    const dislikedSongs = this.userHistory.dislikedSongs;
    
    // Get audio features of liked songs
    const likedFeatures = this.userHistory.listeningHistory
      .filter(session => likedSongs.includes(session.songId))
      .map(session => session.audioFeatures);

    if (likedFeatures.length === 0) return null;

    // Calculate average preferred features
    return {
      avgValence: likedFeatures.reduce((sum, f) => sum + f.valence, 0) / likedFeatures.length,
      avgEnergy: likedFeatures.reduce((sum, f) => sum + f.energy, 0) / likedFeatures.length,
      avgDanceability: likedFeatures.reduce((sum, f) => sum + f.danceability, 0) / likedFeatures.length,
      avgTempo: likedFeatures.reduce((sum, f) => sum + f.tempo, 0) / likedFeatures.length,
      preferredGenres: this.getPreferredGenres(),
      preferredMoods: this.getPreferredMoods()
    };
  }

  // Get preferred genres from listening history
  getPreferredGenres() {
    const likedSongs = this.userHistory.listeningHistory
      .filter(session => this.userHistory.likedSongs.includes(session.songId))
      .map(session => session.song.genres)
      .flat();

    const genreCounts = {};
    likedSongs.forEach(genre => {
      genreCounts[genre] = (genreCounts[genre] || 0) + 1;
    });

    return Object.keys(genreCounts)
      .sort((a, b) => genreCounts[b] - genreCounts[a])
      .slice(0, 5);
  }

  // Get preferred moods from listening history
  getPreferredMoods() {
    const likedSongs = this.userHistory.listeningHistory
      .filter(session => this.userHistory.likedSongs.includes(session.songId))
      .map(session => session.song.moods)
      .flat();

    const moodCounts = {};
    likedSongs.forEach(mood => {
      moodCounts[mood] = (moodCounts[mood] || 0) + 1;
    });

    return Object.keys(moodCounts)
      .sort((a, b) => moodCounts[b] - moodCounts[a])
      .slice(0, 3);
  }

  // Calculate mood score for a song
  calculateMoodScore(song, targetMood) {
    const pattern = this.moodPatterns[targetMood];
    if (!pattern) return 0.5;

    let score = 0;
    score += this.calculateSimilarity(song.audioFeatures.valence, pattern.avgValence) * 0.3;
    score += this.calculateSimilarity(song.audioFeatures.energy, pattern.avgEnergy) * 0.25;
    score += this.calculateSimilarity(song.audioFeatures.danceability, pattern.avgDanceability) * 0.2;
    score += this.calculateSimilarity(song.audioFeatures.tempo / 200, pattern.avgTempo / 200) * 0.15;
    score += this.calculateSimilarity(song.audioFeatures.acousticness, pattern.avgAcousticness || 0.5) * 0.1;

    return score;
  }

  // Calculate preference score for a song
  calculatePreferenceScore(song, preferences) {
    if (!preferences) return 0.5;

    let score = 0;
    score += this.calculateSimilarity(song.audioFeatures.valence, preferences.avgValence) * 0.3;
    score += this.calculateSimilarity(song.audioFeatures.energy, preferences.avgEnergy) * 0.25;
    score += this.calculateSimilarity(song.audioFeatures.danceability, preferences.avgDanceability) * 0.2;
    score += this.calculateSimilarity(song.audioFeatures.tempo / 200, preferences.avgTempo / 200) * 0.15;
    score += this.calculateSimilarity(song.audioFeatures.acousticness, preferences.avgAcousticness || 0.5) * 0.1;

    // Bonus for preferred genres and moods
    if (preferences.preferredGenres.some(genre => song.genres.includes(genre))) {
      score += 0.2;
    }
    if (preferences.preferredMoods.some(mood => song.moods.includes(mood))) {
      score += 0.2;
    }

    return Math.min(score, 1);
  }

  // Calculate recency score (prefer newer songs)
  calculateRecencyScore(song) {
    const currentYear = new Date().getFullYear();
    const songYear = song.releaseYear || currentYear;
    const yearDiff = currentYear - songYear;
    
    // Prefer songs from the last 10 years, but don't completely exclude older songs
    return Math.max(0.1, 1 - (yearDiff / 50));
  }

  // Get user insights and statistics
  getUserInsights() {
    const totalSessions = this.userHistory.listeningHistory.length;
    const totalLikes = this.userHistory.likedSongs.length;
    const totalDislikes = this.userHistory.dislikedSongs.length;
    
    return {
      totalSessions,
      totalLikes,
      totalDislikes,
      likeRate: totalSessions > 0 ? totalLikes / totalSessions : 0,
      mostListenedMood: this.getMostListenedMood(),
      preferredTimeOfDay: this.getPreferredTimeOfDay(),
      listeningStreak: this.getListeningStreak(),
      topGenres: this.getPreferredGenres(),
      topMoods: this.getPreferredMoods()
    };
  }

  // Get most listened mood
  getMostListenedMood() {
    const moodCounts = {};
    this.userHistory.listeningHistory.forEach(session => {
      session.song.moods.forEach(mood => {
        moodCounts[mood] = (moodCounts[mood] || 0) + 1;
      });
    });

    return Object.keys(moodCounts).reduce((a, b) => 
      moodCounts[a] > moodCounts[b] ? a : b, 'happy'
    );
  }

  // Get preferred time of day
  getPreferredTimeOfDay() {
    const timeCounts = {};
    this.userHistory.listeningHistory.forEach(session => {
      const timeOfDay = this.getTimeOfDayFromTimestamp(session.timestamp);
      timeCounts[timeOfDay] = (timeCounts[timeOfDay] || 0) + 1;
    });

    return Object.keys(timeCounts).reduce((a, b) => 
      timeCounts[a] > timeCounts[b] ? a : b, 'afternoon'
    );
  }

  // Get time of day from timestamp
  getTimeOfDayFromTimestamp(timestamp) {
    const hour = new Date(timestamp).getHours();
    if (hour >= 5 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 17) return 'afternoon';
    if (hour >= 17 && hour < 22) return 'evening';
    return 'night';
  }

  // Get current listening streak
  getListeningStreak() {
    const sortedSessions = this.userHistory.listeningHistory
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    if (sortedSessions.length === 0) return 0;

    let streak = 1;
    const oneDay = 24 * 60 * 60 * 1000;
    
    for (let i = 1; i < sortedSessions.length; i++) {
      const currentDate = new Date(sortedSessions[i - 1].timestamp);
      const previousDate = new Date(sortedSessions[i].timestamp);
      
      if (currentDate.getDate() === previousDate.getDate() || 
          currentDate.getDate() === previousDate.getDate() + 1) {
        streak++;
      } else {
        break;
      }
    }

    return streak;
  }
}

// Export a singleton instance
export const userBehaviorAnalyzer = new UserBehaviorAnalyzer();

