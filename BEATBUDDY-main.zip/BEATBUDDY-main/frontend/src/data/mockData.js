// Mock data for the BeatBuddy app
// This includes songs with user comments and mood analysis

export const mockSongs = [
  {
    id: 1,
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    coverImage: "https://picsum.photos/300/300?random=1",
    duration: "3:20",
    releaseYear: 2020,
    genres: ["Pop", "Synthwave", "R&B"],
    comments: [
      {
        id: 1,
        userId: "user1",
        username: "MusicLover",
        text: "This song makes me feel so energetic and happy! Perfect for driving at night.",
        timestamp: "2024-01-15T10:30:00Z",
        likes: 45,
        mood: "energetic"
      },
      {
        id: 2,
        userId: "user2",
        username: "NightRider",
        text: "Love the retro vibes! Makes me nostalgic for the 80s.",
        timestamp: "2024-01-14T22:15:00Z",
        likes: 32,
        mood: "nostalgic"
      },
      {
        id: 3,
        userId: "user3",
        username: "DanceQueen",
        text: "This is my go-to party song! Gets everyone dancing.",
        timestamp: "2024-01-13T19:45:00Z",
        likes: 67,
        mood: "party"
      }
    ]
  },
  {
    id: 2,
    title: "Someone Like You",
    artist: "Adele",
    album: "21",
    coverImage: "https://picsum.photos/300/300?random=2",
    duration: "4:45",
    releaseYear: 2011,
    genres: ["Pop", "Soul", "R&B"],
    comments: [
      {
        id: 4,
        userId: "user4",
        username: "Heartbroken",
        text: "This song makes me cry every time. So emotional and touching.",
        timestamp: "2024-01-15T14:20:00Z",
        likes: 89,
        mood: "sad"
      },
      {
        id: 5,
        userId: "user5",
        username: "SoulSinger",
        text: "Adele's voice is so powerful and soulful. This song is beautiful.",
        timestamp: "2024-01-14T16:30:00Z",
        likes: 56,
        mood: "romantic"
      },
      {
        id: 6,
        userId: "user6",
        username: "MusicTherapist",
        text: "Perfect for when you need to feel your emotions. Very therapeutic.",
        timestamp: "2024-01-13T11:15:00Z",
        likes: 42,
        mood: "calm"
      }
    ]
  },
  {
    id: 3,
    title: "Shape of You",
    artist: "Ed Sheeran",
    album: "÷ (Divide)",
    coverImage: "https://picsum.photos/300/300?random=3",
    duration: "3:53",
    releaseYear: 2017,
    genres: ["Pop", "Tropical House"],
    comments: [
      {
        id: 7,
        userId: "user7",
        username: "BeachVibes",
        text: "This song reminds me of summer vacations. So chill and relaxing.",
        timestamp: "2024-01-15T09:45:00Z",
        likes: 38,
        mood: "chill"
      },
      {
        id: 8,
        userId: "user8",
        username: "WorkoutBuddy",
        text: "Great workout song! Gets me pumped and motivated.",
        timestamp: "2024-01-14T07:30:00Z",
        likes: 51,
        mood: "energetic"
      },
      {
        id: 9,
        userId: "user9",
        username: "RomanticSoul",
        text: "Such a romantic song! Perfect for date nights.",
        timestamp: "2024-01-13T20:15:00Z",
        likes: 44,
        mood: "romantic"
      }
    ]
  },
  {
    id: 4,
    title: "Bohemian Rhapsody",
    artist: "Queen",
    album: "A Night at the Opera",
    coverImage: "https://picsum.photos/300/300?random=4",
    duration: "5:55",
    releaseYear: 1975,
    genres: ["Rock", "Progressive Rock", "Opera"],
    comments: [
      {
        id: 10,
        userId: "user10",
        username: "RockLegend",
        text: "This is pure genius! The most epic song ever created.",
        timestamp: "2024-01-15T12:00:00Z",
        likes: 156,
        mood: "energetic"
      },
      {
        id: 11,
        userId: "user11",
        username: "ClassicLover",
        text: "Takes me back to my childhood. Such a classic masterpiece.",
        timestamp: "2024-01-14T18:45:00Z",
        likes: 78,
        mood: "nostalgic"
      },
      {
        id: 12,
        userId: "user12",
        username: "MusicNerd",
        text: "The composition is absolutely brilliant. A work of art.",
        timestamp: "2024-01-13T15:20:00Z",
        likes: 92,
        mood: "focused"
      }
    ]
  },
  {
    id: 5,
    title: "All of Me",
    artist: "John Legend",
    album: "Love in the Future",
    coverImage: "https://picsum.photos/300/300?random=5",
    duration: "4:29",
    releaseYear: 2013,
    genres: ["R&B", "Soul", "Pop"],
    comments: [
      {
        id: 13,
        userId: "user13",
        username: "LoveStory",
        text: "This song is so romantic! Makes me believe in love again.",
        timestamp: "2024-01-15T21:30:00Z",
        likes: 73,
        mood: "romantic"
      },
      {
        id: 14,
        userId: "user14",
        username: "SmoothOperator",
        text: "John's voice is so smooth and calming. Perfect for relaxing.",
        timestamp: "2024-01-14T23:15:00Z",
        likes: 45,
        mood: "calm"
      },
      {
        id: 15,
        userId: "user15",
        username: "WeddingPlanner",
        text: "This was our wedding song! So beautiful and meaningful.",
        timestamp: "2024-01-13T14:45:00Z",
        likes: 89,
        mood: "romantic"
      }
    ]
  },
  {
    id: 6,
    title: "Smells Like Teen Spirit",
    artist: "Nirvana",
    album: "Nevermind",
    coverImage: "https://picsum.photos/300/300?random=6",
    duration: "5:01",
    releaseYear: 1991,
    genres: ["Rock", "Grunge", "Alternative Rock"],
    comments: [
      {
        id: 16,
        userId: "user16",
        username: "GrungeFan",
        text: "This song is so powerful and intense! Gets me pumped up.",
        timestamp: "2024-01-15T17:20:00Z",
        likes: 112,
        mood: "energetic"
      },
      {
        id: 17,
        userId: "user17",
        username: "AngryTeen",
        text: "Perfect for when I'm feeling angry and frustrated.",
        timestamp: "2024-01-14T13:30:00Z",
        likes: 67,
        mood: "angry"
      },
      {
        id: 18,
        userId: "user18",
        username: "90sKid",
        text: "Takes me back to the 90s! Such a nostalgic feeling.",
        timestamp: "2024-01-13T10:15:00Z",
        likes: 54,
        mood: "nostalgic"
      }
    ]
  },
  {
    id: 7,
    title: "Hotel California",
    artist: "Eagles",
    album: "Hotel California",
    coverImage: "https://picsum.photos/300/300?random=7",
    duration: "6:30",
    releaseYear: 1976,
    genres: ["Rock", "Soft Rock", "Country Rock"],
    comments: [
      {
        id: 19,
        userId: "user19",
        username: "RoadTripper",
        text: "Perfect for long drives. So calming and atmospheric.",
        timestamp: "2024-01-15T08:45:00Z",
        likes: 48,
        mood: "calm"
      },
      {
        id: 20,
        userId: "user20",
        username: "ClassicRock",
        text: "This song is timeless. Such a beautiful composition.",
        timestamp: "2024-01-14T19:30:00Z",
        likes: 76,
        mood: "focused"
      },
      {
        id: 21,
        userId: "user21",
        username: "CaliforniaDreamer",
        text: "Makes me dream of California. So peaceful and dreamy.",
        timestamp: "2024-01-13T16:45:00Z",
        likes: 39,
        mood: "chill"
      }
    ]
  },
  {
    id: 8,
    title: "Dance Monkey",
    artist: "Tones and I",
    album: "The Kids Are Coming",
    coverImage: "https://picsum.photos/300/300?random=8",
    duration: "3:29",
    releaseYear: 2019,
    genres: ["Pop", "Indie Pop"],
    comments: [
      {
        id: 22,
        userId: "user22",
        username: "PartyAnimal",
        text: "This song is so fun! Gets everyone dancing at parties.",
        timestamp: "2024-01-15T22:15:00Z",
        likes: 95,
        mood: "party"
      },
      {
        id: 23,
        userId: "user23",
        username: "HappyVibes",
        text: "Such a happy and upbeat song! Makes me smile every time.",
        timestamp: "2024-01-14T11:30:00Z",
        likes: 62,
        mood: "happy"
      },
      {
        id: 24,
        userId: "user24",
        username: "WorkoutEnthusiast",
        text: "Perfect for workouts! So energetic and motivating.",
        timestamp: "2024-01-13T06:45:00Z",
        likes: 58,
        mood: "energetic"
      }
    ]
  }
];

// Mock playlists generated from mood-based comments
export const mockPlaylists = [
  {
    id: "happy-playlist",
    name: "Happy Vibes",
    description: "Songs that make people feel happy and joyful",
    coverImage: "https://picsum.photos/300/300?random=happy",
    mood: "happy",
    songCount: 12,
    duration: "45 min",
    likes: 1234,
    songs: [mockSongs[7], mockSongs[0]], // Dance Monkey, Blinding Lights
    moodDistribution: {
      happy: 8,
      energetic: 3,
      party: 1
    }
  },
  {
    id: "sad-playlist",
    name: "Melancholy Moments",
    description: "Songs for when you need to feel your emotions",
    coverImage: "https://picsum.photos/300/300?random=sad",
    mood: "sad",
    songCount: 8,
    duration: "32 min",
    likes: 856,
    songs: [mockSongs[1]], // Someone Like You
    moodDistribution: {
      sad: 6,
      calm: 2
    }
  },
  {
    id: "energetic-playlist",
    name: "Power Up",
    description: "High-energy songs to get you pumped",
    coverImage: "https://picsum.photos/300/300?random=energetic",
    mood: "energetic",
    songCount: 15,
    duration: "58 min",
    likes: 2100,
    songs: [mockSongs[0], mockSongs[3], mockSongs[5]], // Blinding Lights, Bohemian Rhapsody, Smells Like Teen Spirit
    moodDistribution: {
      energetic: 10,
      angry: 3,
      party: 2
    }
  },
  {
    id: "romantic-playlist",
    name: "Love Stories",
    description: "Romantic songs for special moments",
    coverImage: "https://picsum.photos/300/300?random=romantic",
    mood: "romantic",
    songCount: 10,
    duration: "42 min",
    likes: 1678,
    songs: [mockSongs[4], mockSongs[1]], // All of Me, Someone Like You
    moodDistribution: {
      romantic: 7,
      calm: 2,
      sad: 1
    }
  },
  {
    id: "calm-playlist",
    name: "Peaceful Mind",
    description: "Calming songs for relaxation and focus",
    coverImage: "https://picsum.photos/300/300?random=calm",
    mood: "calm",
    songCount: 14,
    duration: "55 min",
    likes: 945,
    songs: [mockSongs[6], mockSongs[1]], // Hotel California, Someone Like You
    moodDistribution: {
      calm: 9,
      chill: 3,
      focused: 2
    }
  },
  {
    id: "party-playlist",
    name: "Celebration Time",
    description: "Party anthems to get the celebration started",
    coverImage: "https://picsum.photos/300/300?random=party",
    mood: "party",
    songCount: 18,
    duration: "65 min",
    likes: 2890,
    songs: [mockSongs[7], mockSongs[0]], // Dance Monkey, Blinding Lights
    moodDistribution: {
      party: 12,
      energetic: 4,
      happy: 2
    }
  }
];

// Mock user data
export const mockUsers = [
  {
    id: "user1",
    username: "MusicLover",
    avatar: "https://picsum.photos/50/50?random=user1"
  },
  {
    id: "user2",
    username: "NightRider",
    avatar: "https://picsum.photos/50/50?random=user2"
  },
  {
    id: "user3",
    username: "DanceQueen",
    avatar: "https://picsum.photos/50/50?random=user3"
  },
  {
    id: "user4",
    username: "Heartbroken",
    avatar: "https://picsum.photos/50/50?random=user4"
  },
  {
    id: "user5",
    username: "SoulSinger",
    avatar: "https://picsum.photos/50/50?random=user5"
  }
];

// Helper functions
export const getSongById = (id) => {
  return mockSongs.find(song => song.id === parseInt(id));
};

export const getPlaylistById = (id) => {
  return mockPlaylists.find(playlist => playlist.id === id);
};

export const searchSongs = (query) => {
  const lowercaseQuery = query.toLowerCase();
  return mockSongs.filter(song => 
    song.title.toLowerCase().includes(lowercaseQuery) ||
    song.artist.toLowerCase().includes(lowercaseQuery) ||
    song.album.toLowerCase().includes(lowercaseQuery) ||
    song.genres.some(genre => genre.toLowerCase().includes(lowercaseQuery))
  );
};

export const getSongsByMood = (mood) => {
  return mockSongs.filter(song => {
    const moodDistribution = song.comments.reduce((acc, comment) => {
      acc[comment.mood] = (acc[comment.mood] || 0) + 1;
      return acc;
    }, {});
    
    return moodDistribution[mood] > 0;
  });
};

export const getRecentComments = () => {
  const allComments = mockSongs.flatMap(song => 
    song.comments.map(comment => ({
      ...comment,
      songTitle: song.title,
      songArtist: song.artist,
      songId: song.id
    }))
  );
  
  return allComments
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 10);
};

