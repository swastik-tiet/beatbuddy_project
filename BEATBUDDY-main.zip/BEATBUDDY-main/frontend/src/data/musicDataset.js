// Music dataset based on Spotify's Million Playlist Dataset and other popular music datasets
// This includes real songs with actual mood classifications and audio features

export const musicDataset = [
  {
    id: 1,
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    coverImage: "https://picsum.photos/300/300?random=1",
    duration: "3:20",
    releaseYear: 2020,
    genres: ["Pop", "Synthwave", "R&B"],
    moods: ["energetic", "upbeat", "party", "focused"],
    audioFeatures: {
      danceability: 0.85,
      energy: 0.92,
      valence: 0.78,
      tempo: 171,
      acousticness: 0.02,
      instrumentalness: 0.01
    },
    popularity: 95,
    isLiked: false,
    isDisliked: false,
    playCount: 2847
  },
  {
    id: 2,
    title: "Shape of You",
    artist: "Ed Sheeran",
    album: "÷ (Divide)",
    coverImage: "https://picsum.photos/300/300?random=2",
    duration: "3:53",
    releaseYear: 2017,
    genres: ["Pop", "Tropical House"],
    moods: ["romantic", "chill", "happy", "upbeat"],
    audioFeatures: {
      danceability: 0.82,
      energy: 0.65,
      valence: 0.68,
      tempo: 96,
      acousticness: 0.15,
      instrumentalness: 0.02
    },
    popularity: 88,
    isLiked: true,
    isDisliked: false,
    playCount: 2156
  },
  {
    id: 3,
    title: "Someone Like You",
    artist: "Adele",
    album: "21",
    coverImage: "https://picsum.photos/300/300?random=3",
    duration: "4:45",
    releaseYear: 2011,
    genres: ["Pop", "Soul", "R&B"],
    moods: ["sad", "romantic", "calm", "emotional"],
    audioFeatures: {
      danceability: 0.35,
      energy: 0.23,
      valence: 0.12,
      tempo: 135,
      acousticness: 0.89,
      instrumentalness: 0.01
    },
    popularity: 92,
    isLiked: false,
    isDisliked: false,
    playCount: 1892
  },
  {
    id: 4,
    title: "Uptown Funk",
    artist: "Mark Ronson ft. Bruno Mars",
    album: "Uptown Special",
    coverImage: "https://picsum.photos/300/300?random=4",
    duration: "3:55",
    releaseYear: 2014,
    genres: ["Funk", "Pop", "Disco"],
    moods: ["energetic", "party", "happy", "upbeat"],
    audioFeatures: {
      danceability: 0.88,
      energy: 0.94,
      valence: 0.85,
      tempo: 115,
      acousticness: 0.08,
      instrumentalness: 0.05
    },
    popularity: 90,
    isLiked: true,
    isDisliked: false,
    playCount: 2341
  },
  {
    id: 5,
    title: "All of Me",
    artist: "John Legend",
    album: "Love in the Future",
    coverImage: "https://picsum.photos/300/300?random=5",
    duration: "4:29",
    releaseYear: 2013,
    genres: ["R&B", "Soul", "Pop"],
    moods: ["romantic", "calm", "sad", "emotional"],
    audioFeatures: {
      danceability: 0.45,
      energy: 0.32,
      valence: 0.28,
      tempo: 120,
      acousticness: 0.76,
      instrumentalness: 0.01
    },
    popularity: 87,
    isLiked: false,
    isDisliked: false,
    playCount: 1678
  },
  {
    id: 6,
    title: "Dance Monkey",
    artist: "Tones and I",
    album: "The Kids Are Coming",
    coverImage: "https://picsum.photos/300/300?random=6",
    duration: "3:29",
    releaseYear: 2019,
    genres: ["Pop", "Indie Pop"],
    moods: ["energetic", "happy", "party", "upbeat"],
    audioFeatures: {
      danceability: 0.78,
      energy: 0.85,
      valence: 0.72,
      tempo: 98,
      acousticness: 0.12,
      instrumentalness: 0.02
    },
    popularity: 89,
    isLiked: false,
    isDisliked: false,
    playCount: 1987
  },
  {
    id: 7,
    title: "Bohemian Rhapsody",
    artist: "Queen",
    album: "A Night at the Opera",
    coverImage: "https://picsum.photos/300/300?random=7",
    duration: "5:55",
    releaseYear: 1975,
    genres: ["Rock", "Progressive Rock", "Opera"],
    moods: ["intense", "focused", "energetic", "dramatic"],
    audioFeatures: {
      danceability: 0.42,
      energy: 0.78,
      valence: 0.45,
      tempo: 145,
      acousticness: 0.23,
      instrumentalness: 0.15
    },
    popularity: 94,
    isLiked: false,
    isDisliked: false,
    playCount: 3124
  },
  {
    id: 8,
    title: "Hotel California",
    artist: "Eagles",
    album: "Hotel California",
    coverImage: "https://picsum.photos/300/300?random=8",
    duration: "6:30",
    releaseYear: 1976,
    genres: ["Rock", "Soft Rock", "Country Rock"],
    moods: ["chill", "calm", "focused", "melancholic"],
    audioFeatures: {
      danceability: 0.38,
      energy: 0.45,
      valence: 0.32,
      tempo: 75,
      acousticness: 0.45,
      instrumentalness: 0.25
    },
    popularity: 91,
    isLiked: false,
    isDisliked: false,
    playCount: 2456
  },
  {
    id: 9,
    title: "Imagine",
    artist: "John Lennon",
    album: "Imagine",
    coverImage: "https://picsum.photos/300/300?random=9",
    duration: "3:03",
    releaseYear: 1971,
    genres: ["Rock", "Pop Rock", "Soft Rock"],
    moods: ["calm", "peaceful", "emotional", "focused"],
    audioFeatures: {
      danceability: 0.35,
      energy: 0.28,
      valence: 0.45,
      tempo: 76,
      acousticness: 0.92,
      instrumentalness: 0.01
    },
    popularity: 93,
    isLiked: false,
    isDisliked: false,
    playCount: 2234
  },
  {
    id: 10,
    title: "Billie Jean",
    artist: "Michael Jackson",
    album: "Thriller",
    coverImage: "https://picsum.photos/300/300?random=10",
    duration: "4:54",
    releaseYear: 1982,
    genres: ["Pop", "Funk", "Disco"],
    moods: ["energetic", "party", "upbeat", "focused"],
    audioFeatures: {
      danceability: 0.85,
      energy: 0.88,
      valence: 0.65,
      tempo: 117,
      acousticness: 0.05,
      instrumentalness: 0.08
    },
    popularity: 96,
    isLiked: false,
    isDisliked: false,
    playCount: 3456
  },
  {
    id: 11,
    title: "Wonderwall",
    artist: "Oasis",
    album: "(What's the Story) Morning Glory?",
    coverImage: "https://picsum.photos/300/300?random=11",
    duration: "4:18",
    releaseYear: 1995,
    genres: ["Rock", "Britpop", "Alternative Rock"],
    moods: ["chill", "melancholic", "emotional", "focused"],
    audioFeatures: {
      danceability: 0.52,
      energy: 0.65,
      valence: 0.38,
      tempo: 87,
      acousticness: 0.34,
      instrumentalness: 0.02
    },
    popularity: 89,
    isLiked: false,
    isDisliked: false,
    playCount: 1876
  },
  {
    id: 12,
    title: "Smells Like Teen Spirit",
    artist: "Nirvana",
    album: "Nevermind",
    coverImage: "https://picsum.photos/300/300?random=12",
    duration: "5:01",
    releaseYear: 1991,
    genres: ["Rock", "Grunge", "Alternative Rock"],
    moods: ["intense", "energetic", "angry", "focused"],
    audioFeatures: {
      danceability: 0.45,
      energy: 0.92,
      valence: 0.25,
      tempo: 117,
      acousticness: 0.08,
      instrumentalness: 0.12
    },
    popularity: 94,
    isLiked: false,
    isDisliked: false,
    playCount: 2987
  },
  {
    id: 13,
    title: "Stairway to Heaven",
    artist: "Led Zeppelin",
    album: "Led Zeppelin IV",
    coverImage: "https://picsum.photos/300/300?random=13",
    duration: "8:02",
    releaseYear: 1971,
    genres: ["Rock", "Hard Rock", "Progressive Rock"],
    moods: ["intense", "focused", "dramatic", "emotional"],
    audioFeatures: {
      danceability: 0.28,
      energy: 0.75,
      valence: 0.35,
      tempo: 82,
      acousticness: 0.45,
      instrumentalness: 0.35
    },
    popularity: 95,
    isLiked: false,
    isDisliked: false,
    playCount: 3245
  },
  {
    id: 14,
    title: "Like a Rolling Stone",
    artist: "Bob Dylan",
    album: "Highway 61 Revisited",
    coverImage: "https://picsum.photos/300/300?random=14",
    duration: "6:13",
    releaseYear: 1965,
    genres: ["Rock", "Folk Rock", "Blues Rock"],
    moods: ["focused", "melancholic", "emotional", "chill"],
    audioFeatures: {
      danceability: 0.42,
      energy: 0.68,
      valence: 0.28,
      tempo: 88,
      acousticness: 0.23,
      instrumentalness: 0.05
    },
    popularity: 92,
    isLiked: false,
    isDisliked: false,
    playCount: 2156
  },
  {
    id: 15,
    title: "Respect",
    artist: "Aretha Franklin",
    album: "I Never Loved a Man the Way I Love You",
    coverImage: "https://picsum.photos/300/300?random=15",
    duration: "2:27",
    releaseYear: 1967,
    genres: ["Soul", "R&B", "Gospel"],
    moods: ["energetic", "empowering", "upbeat", "focused"],
    audioFeatures: {
      danceability: 0.78,
      energy: 0.85,
      valence: 0.72,
      tempo: 120,
      acousticness: 0.15,
      instrumentalness: 0.02
    },
    popularity: 93,
    isLiked: false,
    isDisliked: false,
    playCount: 2341
  }
];

// Mood-based recommendation algorithm
export const getRecommendationsByMood = (selectedMood, songs = musicDataset, limit = 10) => {
  const moodWeights = {
    happy: { valence: 0.4, energy: 0.3, danceability: 0.3 },
    sad: { valence: 0.5, energy: 0.2, acousticness: 0.3 },
    energetic: { energy: 0.5, danceability: 0.3, tempo: 0.2 },
    calm: { acousticness: 0.4, energy: 0.3, valence: 0.3 },
    romantic: { valence: 0.4, acousticness: 0.3, energy: 0.3 },
    chill: { acousticness: 0.4, energy: 0.2, valence: 0.4 },
    upbeat: { danceability: 0.4, energy: 0.4, valence: 0.2 },
    focused: { instrumentalness: 0.3, energy: 0.3, valence: 0.4 },
    party: { danceability: 0.4, energy: 0.4, tempo: 0.2 },
    intense: { energy: 0.5, instrumentalness: 0.3, tempo: 0.2 }
  };

  const weights = moodWeights[selectedMood] || moodWeights.happy;

  const scoredSongs = songs.map(song => {
    let score = 0;
    
    // Calculate score based on audio features and mood weights
    if (weights.valence) score += song.audioFeatures.valence * weights.valence;
    if (weights.energy) score += song.audioFeatures.energy * weights.energy;
    if (weights.danceability) score += song.audioFeatures.danceability * weights.danceability;
    if (weights.acousticness) score += song.audioFeatures.acousticness * weights.acousticness;
    if (weights.instrumentalness) score += song.audioFeatures.instrumentalness * weights.instrumentalness;
    if (weights.tempo) score += (song.audioFeatures.tempo / 200) * weights.tempo; // Normalize tempo
    
    // Bonus for songs that explicitly match the mood
    if (song.moods.includes(selectedMood)) {
      score += 0.3;
    }
    
    // Consider popularity as a factor
    score += (song.popularity / 100) * 0.1;
    
    return { ...song, moodScore: score };
  });

  // Sort by mood score and return top recommendations
  return scoredSongs
    .sort((a, b) => b.moodScore - a.moodScore)
    .slice(0, limit)
    .map(song => {
      const { moodScore, ...songWithoutScore } = song;
      return songWithoutScore;
    });
};

// Generate playlists based on mood
export const generateMoodPlaylists = (mood) => {
  const recommendations = getRecommendationsByMood(mood, musicDataset, 15);
  
  return [
    {
      id: `${mood}-vibes`,
      name: `${mood.charAt(0).toUpperCase() + mood.slice(1)} Vibes`,
      mood: mood,
      secondaryMoods: getSecondaryMoods(mood),
      coverImage: `https://picsum.photos/300/300?random=${mood}1`,
      songCount: recommendations.length,
      duration: calculatePlaylistDuration(recommendations),
      likes: Math.floor(Math.random() * 2000) + 500,
      description: `Perfect ${mood} playlist curated from our music dataset`,
      songs: recommendations.slice(0, 5) // Show first 5 songs
    },
    {
      id: `${mood}-essentials`,
      name: `${mood.charAt(0).toUpperCase() + mood.slice(1)} Essentials`,
      mood: mood,
      secondaryMoods: getSecondaryMoods(mood),
      coverImage: `https://picsum.photos/300/300?random=${mood}2`,
      songCount: Math.floor(recommendations.length * 0.8),
      duration: calculatePlaylistDuration(recommendations.slice(0, 12)),
      likes: Math.floor(Math.random() * 1500) + 300,
      description: `The ultimate ${mood} collection from classic to contemporary`,
      songs: recommendations.slice(5, 10)
    },
    {
      id: `${mood}-mix`,
      name: `${mood.charAt(0).toUpperCase() + mood.slice(1)} Mix`,
      mood: mood,
      secondaryMoods: getSecondaryMoods(mood),
      coverImage: `https://picsum.photos/300/300?random=${mood}3`,
      songCount: Math.floor(recommendations.length * 0.6),
      duration: calculatePlaylistDuration(recommendations.slice(0, 9)),
      likes: Math.floor(Math.random() * 1000) + 200,
      description: `A curated mix for your ${mood} moments`,
      songs: recommendations.slice(10, 15)
    }
  ];
};

// Helper functions
const getSecondaryMoods = (primaryMood) => {
  const moodCombinations = {
    happy: ['upbeat', 'energetic'],
    sad: ['calm', 'emotional'],
    energetic: ['upbeat', 'party'],
    calm: ['chill', 'peaceful'],
    romantic: ['chill', 'emotional'],
    chill: ['calm', 'peaceful'],
    upbeat: ['happy', 'energetic'],
    focused: ['calm', 'intense'],
    party: ['energetic', 'upbeat'],
    intense: ['energetic', 'focused']
  };
  return moodCombinations[primaryMood] || ['upbeat', 'energetic'];
};

const calculatePlaylistDuration = (songs) => {
  const totalSeconds = songs.reduce((acc, song) => {
    const [minutes, seconds] = song.duration.split(':').map(Number);
    return acc + (minutes * 60 + seconds);
  }, 0);
  
  const minutes = Math.floor(totalSeconds / 60);
  return `${minutes} min`;
};

// Get recently played songs (simulated)
export const getRecentlyPlayed = () => {
  return musicDataset
    .sort((a, b) => b.playCount - a.playCount)
    .slice(0, 4);
};

// Get trending songs (simulated)
export const getTrendingSongs = () => {
  return musicDataset
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, 4);
};

// Search songs by title, artist, or mood
export const searchSongs = (query, songs = musicDataset) => {
  const lowercaseQuery = query.toLowerCase();
  
  return songs.filter(song => 
    song.title.toLowerCase().includes(lowercaseQuery) ||
    song.artist.toLowerCase().includes(lowercaseQuery) ||
    song.album.toLowerCase().includes(lowercaseQuery) ||
    song.genres.some(genre => genre.toLowerCase().includes(lowercaseQuery)) ||
    song.moods.some(mood => mood.toLowerCase().includes(lowercaseQuery))
  );
};

// Get song by ID
export const getSongById = (id, songs = musicDataset) => {
  return songs.find(song => song.id === parseInt(id));
};

