// Mood Detection Service for analyzing user comments
// This service uses keyword analysis and sentiment detection to categorize moods

export class MoodDetectionService {
  constructor() {
    this.moodKeywords = this.initializeMoodKeywords();
    this.sentimentWords = this.initializeSentimentWords();
  }

  // Initialize mood-specific keywords
  initializeMoodKeywords() {
    return {
      happy: [
        'happy', 'joy', 'excited', 'cheerful', 'upbeat', 'energetic', 'positive',
        'smile', 'laugh', 'fun', 'great', 'amazing', 'wonderful', 'fantastic',
        'love', 'adore', 'enjoy', 'favorite', 'best', 'perfect', 'beautiful',
        'sunshine', 'bright', 'vibrant', 'lively', 'bouncy', 'catchy', 'uplifting'
      ],
      sad: [
        'sad', 'depressed', 'melancholy', 'blue', 'down', 'cry', 'tears',
        'heartbroken', 'lonely', 'missing', 'nostalgic', 'emotional', 'touching',
        'soulful', 'deep', 'meaningful', 'beautiful', 'haunting', 'melancholic',
        'sorrow', 'grief', 'pain', 'hurt', 'broken', 'empty', 'lost'
      ],
      energetic: [
        'energetic', 'powerful', 'intense', 'strong', 'dynamic', 'explosive',
        'electric', 'thrilling', 'adrenaline', 'pump', 'workout', 'gym',
        'motivation', 'drive', 'force', 'energy', 'power', 'strength',
        'fast', 'quick', 'rapid', 'furious', 'wild', 'crazy', 'insane'
      ],
      calm: [
        'calm', 'peaceful', 'relaxing', 'soothing', 'gentle', 'soft', 'quiet',
        'serene', 'tranquil', 'meditation', 'zen', 'chill', 'mellow',
        'smooth', 'easy', 'comfortable', 'cozy', 'warm', 'gentle', 'tender',
        'delicate', 'subtle', 'minimal', 'simple', 'pure', 'clean'
      ],
      romantic: [
        'romantic', 'love', 'passion', 'intimate', 'sexy', 'smooth', 'sultry',
        'seductive', 'beautiful', 'gorgeous', 'stunning', 'amazing', 'perfect',
        'sweet', 'tender', 'gentle', 'warm', 'cozy', 'intimate', 'close',
        'connection', 'chemistry', 'spark', 'magic', 'special', 'unique'
      ],
      angry: [
        'angry', 'furious', 'rage', 'hate', 'violent', 'aggressive', 'intense',
        'powerful', 'strong', 'forceful', 'explosive', 'wild', 'crazy',
        'insane', 'mad', 'frustrated', 'annoyed', 'irritated', 'pissed',
        'livid', 'enraged', 'fuming', 'boiling', 'hot', 'fire', 'burn'
      ],
      nostalgic: [
        'nostalgic', 'memory', 'remember', 'childhood', 'past', 'old', 'vintage',
        'retro', 'classic', 'timeless', 'throwback', 'blast', 'from', 'the',
        'past', 'good', 'old', 'days', 'memories', 'reminisce', 'nostalgia'
      ],
      focused: [
        'focused', 'concentration', 'study', 'work', 'productive', 'efficient',
        'clear', 'sharp', 'precise', 'accurate', 'detailed', 'complex',
        'intellectual', 'smart', 'clever', 'brilliant', 'genius', 'masterpiece',
        'perfect', 'flawless', 'excellent', 'outstanding', 'exceptional'
      ],
      party: [
        'party', 'celebration', 'fun', 'dance', 'club', 'night', 'out',
        'wild', 'crazy', 'insane', 'amazing', 'fantastic', 'epic', 'legendary',
        'unforgettable', 'memorable', 'special', 'unique', 'different',
        'exciting', 'thrilling', 'adventurous', 'bold', 'daring', 'brave'
      ],
      chill: [
        'chill', 'relaxed', 'easy', 'smooth', 'mellow', 'laid', 'back',
        'casual', 'comfortable', 'cozy', 'warm', 'gentle', 'soft', 'quiet',
        'peaceful', 'serene', 'tranquil', 'calm', 'cool', 'nice', 'good',
        'pleasant', 'enjoyable', 'nice', 'fine', 'okay', 'alright'
      ]
    };
  }

  // Initialize sentiment words for additional analysis
  initializeSentimentWords() {
    return {
      positive: [
        'love', 'like', 'enjoy', 'adore', 'favorite', 'best', 'great', 'amazing',
        'wonderful', 'fantastic', 'perfect', 'beautiful', 'gorgeous', 'stunning',
        'incredible', 'unbelievable', 'outstanding', 'excellent', 'brilliant',
        'genius', 'masterpiece', 'epic', 'legendary', 'unforgettable'
      ],
      negative: [
        'hate', 'dislike', 'terrible', 'awful', 'horrible', 'worst', 'bad',
        'ugly', 'disgusting', 'annoying', 'irritating', 'boring', 'dull',
        'stupid', 'idiotic', 'ridiculous', 'nonsense', 'garbage', 'trash',
        'waste', 'pointless', 'meaningless', 'empty', 'shallow'
      ]
    };
  }

  // Detect mood from comment text
  detectMood(comment) {
    const text = comment.toLowerCase();
    const words = text.split(/\s+/);
    
    const moodScores = {};
    
    // Initialize all mood scores
    Object.keys(this.moodKeywords).forEach(mood => {
      moodScores[mood] = 0;
    });

    // Score based on keyword matches
    words.forEach(word => {
      Object.entries(this.moodKeywords).forEach(([mood, keywords]) => {
        if (keywords.includes(word)) {
          moodScores[mood] += 1;
        }
      });
    });

    // Additional sentiment analysis
    const sentimentScore = this.analyzeSentiment(text);
    
    // Adjust scores based on sentiment
    if (sentimentScore > 0.3) {
      moodScores.happy += 0.5;
      moodScores.energetic += 0.3;
    } else if (sentimentScore < -0.3) {
      moodScores.sad += 0.5;
      moodScores.angry += 0.3;
    }

    // Find the mood with highest score
    const maxScore = Math.max(...Object.values(moodScores));
    const detectedMoods = Object.entries(moodScores)
      .filter(([mood, score]) => score === maxScore && score > 0)
      .map(([mood]) => mood);

    // Return primary mood or default
    return detectedMoods.length > 0 ? detectedMoods[0] : 'neutral';
  }

  // Analyze sentiment of text
  analyzeSentiment(text) {
    const words = text.toLowerCase().split(/\s+/);
    let positiveCount = 0;
    let negativeCount = 0;

    words.forEach(word => {
      if (this.sentimentWords.positive.includes(word)) {
        positiveCount += 1;
      } else if (this.sentimentWords.negative.includes(word)) {
        negativeCount += 1;
      }
    });

    const total = positiveCount + negativeCount;
    if (total === 0) return 0;

    return (positiveCount - negativeCount) / total;
  }

  // Get mood color for UI
  getMoodColor(mood) {
    const colors = {
      happy: 'bg-gradient-to-r from-spotify-yellow to-orange-400',
      sad: 'bg-gradient-to-r from-spotify-blue to-indigo-500',
      energetic: 'bg-gradient-to-r from-spotify-orange to-red-500',
      calm: 'bg-gradient-to-r from-teal-400 to-cyan-500',
      romantic: 'bg-gradient-to-r from-spotify-pink to-rose-500',
      angry: 'bg-gradient-to-r from-red-600 to-orange-600',
      nostalgic: 'bg-gradient-to-r from-purple-500 to-pink-500',
      focused: 'bg-gradient-to-r from-spotify-purple to-violet-600',
      party: 'bg-gradient-to-r from-spotify-red to-pink-600',
      chill: 'bg-gradient-to-r from-indigo-500 to-purple-600',
      neutral: 'bg-gradient-to-r from-gray-500 to-gray-600'
    };
    return colors[mood] || colors.neutral;
  }

  // Get mood emoji for UI
  getMoodEmoji(mood) {
    const emojis = {
      happy: '😊',
      sad: '😢',
      energetic: '⚡',
      calm: '😌',
      romantic: '💕',
      angry: '😠',
      nostalgic: '📷',
      focused: '🎯',
      party: '🎉',
      chill: '😎',
      neutral: '😐'
    };
    return emojis[mood] || emojis.neutral;
  }

  // Get mood display name
  getMoodDisplayName(mood) {
    const names = {
      happy: 'Happy',
      sad: 'Sad',
      energetic: 'Energetic',
      calm: 'Calm',
      romantic: 'Romantic',
      angry: 'Angry',
      nostalgic: 'Nostalgic',
      focused: 'Focused',
      party: 'Party',
      chill: 'Chill',
      neutral: 'Neutral'
    };
    return names[mood] || 'Unknown';
  }

  // Analyze multiple comments and get mood distribution
  analyzeMoodDistribution(comments) {
    const moodCounts = {};
    
    comments.forEach(comment => {
      const mood = this.detectMood(comment.text);
      moodCounts[mood] = (moodCounts[mood] || 0) + 1;
    });

    return moodCounts;
  }

  // Get primary mood from comment collection
  getPrimaryMood(comments) {
    const distribution = this.analyzeMoodDistribution(comments);
    const maxCount = Math.max(...Object.values(distribution));
    
    const primaryMoods = Object.entries(distribution)
      .filter(([mood, count]) => count === maxCount)
      .map(([mood]) => mood);

    return primaryMoods.length > 0 ? primaryMoods[0] : 'neutral';
  }

  // Get mood confidence score (0-1)
  getMoodConfidence(comment) {
    const text = comment.toLowerCase();
    const words = text.split(/\s+/);
    
    let totalMatches = 0;
    let maxMatches = 0;

    Object.values(this.moodKeywords).forEach(keywords => {
      let matches = 0;
      words.forEach(word => {
        if (keywords.includes(word)) {
          matches += 1;
        }
      });
      totalMatches += matches;
      maxMatches = Math.max(maxMatches, matches);
    });

    if (totalMatches === 0) return 0;
    
    // Higher confidence if there are more keyword matches
    return Math.min(1, (maxMatches / words.length) * 2);
  }
}

// Export singleton instance
export const moodDetectionService = new MoodDetectionService();

