import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import SongPage from './pages/SongPage';
import SearchPage from './pages/SearchPage';
import PlaylistPage from './pages/PlaylistPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import MusicPlayer from './components/MusicPlayer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-spotify-black text-spotify-text">
        <Navbar />
        <main className="pb-20">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/song/:id" element={<SongPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/playlist/:id" element={<PlaylistPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
            </Routes>
          </AnimatePresence>
        </main>
        <MusicPlayer />
      </div>
    </Router>
  );
}

export default App;
