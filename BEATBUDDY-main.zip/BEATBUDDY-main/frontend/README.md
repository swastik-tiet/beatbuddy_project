# BeatBuddy - Mood-Based Music Recommendation App

A modern, Spotify-inspired web application that recommends music based on your current mood. Built with React, TailwindCSS, and Framer Motion.

## 🎵 Features

### Homepage
- **Mood Selection**: Interactive mood buttons (Happy, Sad, Energetic, Calm, Romantic, etc.)
- **Auto-Generated Playlists**: Dynamic playlist creation based on selected mood
- **Recently Played**: Quick access to your recent music
- **Trending Songs**: Discover what's popular right now

### Song Page
- **Song Details**: Complete song information with cover art
- **Play Controls**: Play/pause functionality with audio preview
- **Like/Dislike System**: Rate songs with counters
- **Comments Section**: User comments with mood tagging
- **Lyrics Display**: Full song lyrics

### Search Page
- **Advanced Search**: Search by title, artist, or mood
- **Mood Filtering**: Filter results by specific moods
- **Real-time Results**: Instant search results with loading states

### Playlist Page
- **Playlist Details**: Complete playlist information
- **Song List**: All songs in the playlist with play buttons
- **Mood Tags**: Visual mood indicators for each song
- **Playlist Actions**: Play, shuffle, like, and share functionality

## 🎨 Design Features

- **Spotify-Inspired Theme**: Dark theme with green and purple accents
- **Responsive Design**: Works perfectly on desktop and mobile
- **Smooth Animations**: Framer Motion powered transitions
- **Modern UI**: Clean, intuitive interface with hover effects
- **Custom Scrollbars**: Styled scrollbars matching the theme

## 🛠️ Tech Stack

- **React 18**: Modern React with functional components and hooks
- **TailwindCSS**: Utility-first CSS framework for styling
- **Framer Motion**: Animation library for smooth transitions
- **React Router**: Client-side routing
- **Lucide React**: Beautiful icon library
- **Axios**: HTTP client for API calls (ready for backend integration)

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd beatbuddy-frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

4. **Open your browser**
   Navigate to `http://localhost:3000`

### Available Scripts

- `npm start` - Runs the app in development mode
- `npm build` - Builds the app for production
- `npm test` - Launches the test runner
- `npm eject` - Ejects from Create React App (not recommended)

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Navbar.js       # Navigation bar with logo and auth buttons
│   ├── MoodSelector.js # Mood selection interface
│   ├── SongCard.js     # Individual song display card
│   ├── PlaylistCard.js # Playlist preview card
│   ├── CommentSection.js # Comments and mood tagging
│   └── MusicPlayer.js  # Audio player controls
├── pages/              # Page components
│   ├── HomePage.js     # Main landing page
│   ├── SongPage.js     # Individual song page
│   ├── SearchPage.js   # Search functionality
│   └── PlaylistPage.js # Playlist details page
├── App.js              # Main app component with routing
├── index.js            # App entry point
└── index.css           # Global styles and Tailwind imports
```

## 🎯 Key Components

### MoodSelector
Interactive mood selection with colorful buttons and smooth animations. Supports 10 different moods with unique colors and icons.

### SongCard
Versatile song display component with:
- Cover image with play overlay
- Title and artist information
- Mood tags with color coding
- Like/dislike buttons with counters
- Hover animations

### CommentSection
Full-featured commenting system with:
- Comment input with mood tagging
- Real-time comment display
- User avatars and timestamps
- Like functionality for comments

### MusicPlayer
Fixed bottom player with:
- Play/pause controls
- Progress bar with seeking
- Volume control
- Song information display
- Shuffle and repeat buttons

## 🎨 Customization

### Colors
The app uses a custom color palette defined in `tailwind.config.js`:

```javascript
colors: {
  'spotify-black': '#121212',
  'spotify-dark-gray': '#181818',
  'spotify-light-gray': '#282828',
  'spotify-green': '#1DB954',
  'spotify-purple': '#8B5CF6',
  'spotify-text': '#FFFFFF',
  'spotify-text-secondary': '#B3B3B3',
}
```

### Animations
Custom animations are defined in the Tailwind config and used throughout the app for smooth transitions and hover effects.

## 🔧 Backend Integration

The app is designed to easily integrate with a backend API. Key integration points:

- **API Calls**: Axios is configured and ready for HTTP requests
- **Data Structure**: Mock data follows a consistent structure for easy API replacement
- **State Management**: Component state is structured for easy backend integration

### Example API Integration

```javascript
// Replace mock data with API calls
const fetchSongs = async () => {
  try {
    const response = await axios.get('/api/songs');
    setSongs(response.data);
  } catch (error) {
    console.error('Error fetching songs:', error);
  }
};
```

## 📱 Responsive Design

The app is fully responsive with breakpoints:
- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: > 1024px

All components adapt their layout and functionality for different screen sizes.

## 🎵 Mock Data

The app includes comprehensive mock data for:
- Songs with mood tags
- Playlists with descriptions
- User comments with timestamps
- Audio preview URLs

This allows for full testing and demonstration without a backend.

## 🚀 Deployment

### Build for Production
```bash
npm run build
```

### Deploy to Netlify/Vercel
1. Connect your repository
2. Set build command: `npm run build`
3. Set publish directory: `build`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🎵 Future Enhancements

- [ ] User authentication and profiles
- [ ] Real-time collaborative playlists
- [ ] Advanced audio features (equalizer, crossfade)
- [ ] Social features (following, sharing)
- [ ] AI-powered mood detection
- [ ] Offline mode support
- [ ] Dark/light theme toggle
- [ ] Accessibility improvements

---

Built with ❤️ using React and TailwindCSS
