const mongoose = require('mongoose');

const songSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Song title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  artist: {
    type: String,
    required: [true, 'Artist name is required'],
    trim: true,
    maxlength: [100, 'Artist name cannot exceed 100 characters']
  },
  album: {
    type: String,
    trim: true,
    maxlength: [100, 'Album name cannot exceed 100 characters']
  },
  coverImage: {
    type: String,
    required: [true, 'Cover image URL is required']
  },
  audioUrl: {
    type: String,
    required: [true, 'Audio URL is required']
  },
  duration: {
    type: Number, // Duration in seconds
    required: [true, 'Duration is required'],
    min: [1, 'Duration must be at least 1 second']
  },
  releaseYear: {
    type: Number,
    min: [1900, 'Release year must be after 1900'],
    max: [new Date().getFullYear() + 1, 'Release year cannot be in the future']
  },
  genres: [{
    type: String,
    enum: ['pop', 'rock', 'jazz', 'classical', 'hip-hop', 'electronic', 'country', 'r&b', 'indie', 'folk', 'blues', 'reggae', 'metal', 'punk', 'alternative'],
    required: true
  }],
  language: {
    type: String,
    default: 'en'
  },
  explicit: {
    type: Boolean,
    default: false
  },
  // Crowdsourced mood data
  moodDistribution: {
    happy: { type: Number, default: 0 },
    sad: { type: Number, default: 0 },
    energetic: { type: Number, default: 0 },
    calm: { type: Number, default: 0 },
    romantic: { type: Number, default: 0 },
    angry: { type: Number, default: 0 },
    melancholic: { type: Number, default: 0 },
    uplifting: { type: Number, default: 0 },
    chill: { type: Number, default: 0 },
    party: { type: Number, default: 0 }
  },
  // Calculated primary mood based on distribution
  primaryMood: {
    type: String,
    enum: ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'],
    default: null
  },
  // Audio features (optional, for advanced recommendations)
  audioFeatures: {
    tempo: { type: Number, min: 0, max: 300 },
    energy: { type: Number, min: 0, max: 1 },
    danceability: { type: Number, min: 0, max: 1 },
    valence: { type: Number, min: 0, max: 1 }, // Positivity
    acousticness: { type: Number, min: 0, max: 1 },
    instrumentalness: { type: Number, min: 0, max: 1 },
    loudness: { type: Number }, // in dB
    key: { type: Number, min: 0, max: 11 }, // 0=C, 1=C#, etc.
    mode: { type: Number, enum: [0, 1] }, // 0=minor, 1=major
    timeSignature: { type: Number, min: 3, max: 7 }
  },
  // Statistics
  stats: {
    totalPlays: { type: Number, default: 0 },
    totalLikes: { type: Number, default: 0 },
    totalDislikes: { type: Number, default: 0 },
    totalComments: { type: Number, default: 0 },
    averageRating: { type: Number, default: 0, min: 0, max: 5 },
    ratingCount: { type: Number, default: 0 }
  },
  // Metadata
  isActive: {
    type: Boolean,
    default: true
  },
  source: {
    type: String,
    enum: ['uploaded', 'youtube', 'spotify', 'soundcloud', 'other'],
    default: 'uploaded'
  },
  externalId: {
    type: String, // ID from external service (YouTube, Spotify, etc.)
    sparse: true
  },
  tags: [{
    type: String,
    trim: true,
    maxlength: 50
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for formatted duration
songSchema.virtual('durationFormatted').get(function() {
  const minutes = Math.floor(this.duration / 60);
  const seconds = this.duration % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

// Virtual for total mood votes
songSchema.virtual('totalMoodVotes').get(function() {
  return Object.values(this.moodDistribution).reduce((sum, count) => sum + count, 0);
});

// Virtual for comments
songSchema.virtual('comments', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'songId'
});

// Virtual for likes
songSchema.virtual('likes', {
  ref: 'Like',
  localField: '_id',
  foreignField: 'songId'
});

// Indexes for better query performance
songSchema.index({ title: 'text', artist: 'text', album: 'text' });
songSchema.index({ artist: 1 });
songSchema.index({ genres: 1 });
songSchema.index({ primaryMood: 1 });
songSchema.index({ 'stats.totalPlays': -1 });
songSchema.index({ 'stats.averageRating': -1 });
songSchema.index({ releaseYear: -1 });
songSchema.index({ isActive: 1 });

// Pre-save middleware to calculate primary mood
songSchema.pre('save', function(next) {
  if (this.isModified('moodDistribution')) {
    const distribution = this.moodDistribution;
    let maxVotes = 0;
    let primaryMood = null;

    for (const [mood, votes] of Object.entries(distribution)) {
      if (votes > maxVotes) {
        maxVotes = votes;
        primaryMood = mood;
      }
    }

    this.primaryMood = maxVotes > 0 ? primaryMood : null;
  }
  next();
});

// Method to update mood distribution
songSchema.methods.updateMoodDistribution = function(mood, increment = 1) {
  if (this.moodDistribution[mood] !== undefined) {
    this.moodDistribution[mood] += increment;
    
    // Recalculate primary mood
    let maxVotes = 0;
    let primaryMood = null;

    for (const [moodKey, votes] of Object.entries(this.moodDistribution)) {
      if (votes > maxVotes) {
        maxVotes = votes;
        primaryMood = moodKey;
      }
    }

    this.primaryMood = maxVotes > 0 ? primaryMood : null;
  }
};

// Method to get mood breakdown
songSchema.methods.getMoodBreakdown = function() {
  const totalVotes = this.totalMoodVotes;
  if (totalVotes === 0) return {};

  const breakdown = {};
  for (const [mood, votes] of Object.entries(this.moodDistribution)) {
    if (votes > 0) {
      breakdown[mood] = {
        votes,
        percentage: Math.round((votes / totalVotes) * 100)
      };
    }
  }

  return breakdown;
};

// Static method to find songs by mood
songSchema.statics.findByMood = function(mood, limit = 20) {
  return this.find({ 
    primaryMood: mood, 
    isActive: true 
  })
  .sort({ 'stats.totalPlays': -1, 'stats.averageRating': -1 })
  .limit(limit);
};

// Static method to search songs
songSchema.statics.searchSongs = function(query, limit = 20) {
  return this.find({
    $and: [
      { isActive: true },
      {
        $or: [
          { title: { $regex: query, $options: 'i' } },
          { artist: { $regex: query, $options: 'i' } },
          { album: { $regex: query, $options: 'i' } },
          { tags: { $in: [new RegExp(query, 'i')] } }
        ]
      }
    ]
  })
  .sort({ 'stats.totalPlays': -1, 'stats.averageRating': -1 })
  .limit(limit);
};

// Static method to get trending songs
songSchema.statics.getTrending = function(limit = 20) {
  return this.find({ isActive: true })
    .sort({ 'stats.totalPlays': -1, 'stats.totalLikes': -1 })
    .limit(limit);
};

module.exports = mongoose.model('Song', songSchema);


