const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  songId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Song',
    required: [true, 'Song ID is required'],
    index: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required'],
    index: true
  },
  text: {
    type: String,
    required: [true, 'Comment text is required'],
    trim: true,
    maxlength: [1000, 'Comment cannot exceed 1000 characters'],
    minlength: [1, 'Comment cannot be empty']
  },
  // Auto-detected mood from comment text
  detectedMood: {
    type: String,
    enum: ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'],
    required: [true, 'Detected mood is required']
  },
  // Mood confidence score (0-1)
  moodConfidence: {
    type: Number,
    required: true,
    min: 0,
    max: 1,
    default: 0.5
  },
  // User's explicit mood selection (optional)
  userSelectedMood: {
    type: String,
    enum: ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'],
    default: null
  },
  // Final mood used for recommendations (detected or user-selected)
  finalMood: {
    type: String,
    enum: ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'],
    required: true
  },
  // Sentiment analysis results
  sentiment: {
    score: { type: Number, min: -1, max: 1 }, // -1 (negative) to 1 (positive)
    comparative: { type: Number }, // Normalized score
    tokens: [{ type: String }], // Words analyzed
    positive: [{ type: String }], // Positive words found
    negative: [{ type: String }] // Negative words found
  },
  // Keywords that triggered mood detection
  moodKeywords: [{
    word: { type: String },
    mood: { type: String },
    confidence: { type: Number }
  }],
  // Engagement metrics
  likes: {
    type: Number,
    default: 0
  },
  dislikes: {
    type: Number,
    default: 0
  },
  replies: [{
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    text: {
      type: String,
      required: true,
      maxlength: [500, 'Reply cannot exceed 500 characters']
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Moderation
  isModerated: {
    type: Boolean,
    default: false
  },
  isHidden: {
    type: Boolean,
    default: false
  },
  moderationReason: {
    type: String,
    enum: ['spam', 'inappropriate', 'offensive', 'irrelevant', 'other'],
    default: null
  },
  // Metadata
  language: {
    type: String,
    default: 'en'
  },
  userAgent: {
    type: String,
    default: null
  },
  ipAddress: {
    type: String,
    default: null
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for user info (populated)
commentSchema.virtual('user', {
  ref: 'User',
  localField: 'userId',
  foreignField: '_id',
  justOne: true
});

// Virtual for song info (populated)
commentSchema.virtual('song', {
  ref: 'Song',
  localField: 'songId',
  foreignField: '_id',
  justOne: true
});

// Virtual for total engagement
commentSchema.virtual('totalEngagement').get(function() {
  return this.likes + this.dislikes;
});

// Virtual for engagement ratio
commentSchema.virtual('engagementRatio').get(function() {
  const total = this.totalEngagement;
  return total > 0 ? this.likes / total : 0;
});

// Indexes for better query performance
commentSchema.index({ songId: 1, createdAt: -1 });
commentSchema.index({ userId: 1, createdAt: -1 });
commentSchema.index({ detectedMood: 1 });
commentSchema.index({ finalMood: 1 });
commentSchema.index({ 'sentiment.score': 1 });
commentSchema.index({ isHidden: 1 });
commentSchema.index({ isModerated: 1 });

// Pre-save middleware to set final mood
commentSchema.pre('save', function(next) {
  // Use user-selected mood if available, otherwise use detected mood
  this.finalMood = this.userSelectedMood || this.detectedMood;
  next();
});

// Post-save middleware to update song's mood distribution
commentSchema.post('save', async function() {
  try {
    const Song = mongoose.model('Song');
    const song = await Song.findById(this.songId);
    
    if (song) {
      // Update mood distribution
      song.updateMoodDistribution(this.finalMood, 1);
      await song.save();
    }
  } catch (error) {
    console.error('Error updating song mood distribution:', error);
  }
});

// Post-remove middleware to update song's mood distribution
commentSchema.post('remove', async function() {
  try {
    const Song = mongoose.model('Song');
    const song = await Song.findById(this.songId);
    
    if (song) {
      // Decrease mood distribution
      song.updateMoodDistribution(this.finalMood, -1);
      await song.save();
    }
  } catch (error) {
    console.error('Error updating song mood distribution:', error);
  }
});

// Method to add reply
commentSchema.methods.addReply = function(userId, text) {
  this.replies.push({
    userId,
    text,
    createdAt: new Date()
  });
  return this.save();
};

// Method to like/dislike comment
commentSchema.methods.toggleLike = function(userId, isLike = true) {
  // This would typically involve a separate Like model
  // For simplicity, we're just incrementing the counter
  if (isLike) {
    this.likes += 1;
  } else {
    this.dislikes += 1;
  }
  return this.save();
};

// Static method to find comments by song
commentSchema.statics.findBySong = function(songId, options = {}) {
  const {
    page = 1,
    limit = 20,
    sort = 'createdAt',
    order = 'desc',
    includeHidden = false
  } = options;

  const query = { songId };
  if (!includeHidden) {
    query.isHidden = false;
  }

  return this.find(query)
    .populate('userId', 'fullName avatar')
    .sort({ [sort]: order === 'desc' ? -1 : 1 })
    .skip((page - 1) * limit)
    .limit(limit);
};

// Static method to find comments by mood
commentSchema.statics.findByMood = function(mood, options = {}) {
  const {
    page = 1,
    limit = 20,
    sort = 'createdAt',
    order = 'desc'
  } = options;

  return this.find({ 
    finalMood: mood,
    isHidden: false
  })
    .populate('userId', 'fullName avatar')
    .populate('songId', 'title artist coverImage')
    .sort({ [sort]: order === 'desc' ? -1 : 1 })
    .skip((page - 1) * limit)
    .limit(limit);
};

// Static method to find recent comments
commentSchema.statics.findRecent = function(limit = 20) {
  return this.find({ isHidden: false })
    .populate('userId', 'fullName avatar')
    .populate('songId', 'title artist coverImage')
    .sort({ createdAt: -1 })
    .limit(limit);
};

// Static method to get mood statistics
commentSchema.statics.getMoodStats = function() {
  return this.aggregate([
    { $match: { isHidden: false } },
    {
      $group: {
        _id: '$finalMood',
        count: { $sum: 1 },
        avgConfidence: { $avg: '$moodConfidence' },
        avgSentiment: { $avg: '$sentiment.score' }
      }
    },
    { $sort: { count: -1 } }
  ]);
};

module.exports = mongoose.model('Comment', commentSchema);


