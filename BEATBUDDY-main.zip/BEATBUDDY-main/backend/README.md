# BeatBuddy Backend API

A comprehensive Node.js + Express backend API for the BeatBuddy music recommendation app, featuring crowdsourced mood detection and personalized music recommendations.

## 🚀 Features

### Core Features
- **User Authentication**: JWT-based authentication with secure password hashing
- **Songs Management**: Complete CRUD operations for songs with metadata
- **Mood Detection Engine**: AI-powered mood analysis from user comments
- **Comments System**: User comments with automatic mood tagging
- **Recommendation Engine**: Personalized music recommendations based on user preferences
- **Crowdsourced Mood Tags**: Community-driven mood classification for songs

### Technical Features
- **RESTful API**: Well-structured REST endpoints with proper HTTP status codes
- **Input Validation**: Comprehensive request validation using express-validator
- **Error Handling**: Centralized error handling with detailed logging
- **Rate Limiting**: API rate limiting to prevent abuse
- **Security**: Helmet.js security headers, CORS configuration
- **Logging**: Structured logging with Winston
- **Database**: MongoDB with Mongoose ODM
- **Performance**: Optimized queries with proper indexing

## 🛠️ Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose
- **Authentication**: JWT (jsonwebtoken)
- **Password Hashing**: bcryptjs
- **Validation**: express-validator
- **Logging**: Winston
- **Security**: Helmet, CORS
- **Rate Limiting**: express-rate-limit
- **Mood Detection**: Natural.js, Sentiment.js

## 📋 Prerequisites

- Node.js (v16 or higher)
- MongoDB (local or cloud instance)
- npm or yarn

## 🚀 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   ```bash
   cp config.env.example .env
   ```
   
   Edit `.env` file with your configuration:
   ```env
   PORT=5000
   NODE_ENV=development
   MONGODB_URI=mongodb://localhost:27017/beatbuddy
   JWT_SECRET=your-super-secret-jwt-key
   JWT_EXPIRE=7d
   ```

4. **Start the server**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## 📚 API Documentation

### Authentication Endpoints

#### POST `/api/auth/signup`
Register a new user account.

**Request Body:**
```json
{
  "fullName": "John Doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": {
      "id": "user_id",
      "fullName": "John Doe",
      "email": "john@example.com"
    },
    "token": "jwt_token"
  }
}
```

#### POST `/api/auth/login`
Authenticate user and get JWT token.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

#### GET `/api/auth/me`
Get current user profile (requires authentication).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

### Songs Endpoints

#### GET `/api/songs`
Get all songs with pagination and filtering.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20, max: 100)
- `genre` (optional): Filter by genre
- `mood` (optional): Filter by mood
- `artist` (optional): Filter by artist
- `sort` (optional): Sort field (title, artist, releaseYear, stats.totalPlays, stats.averageRating)
- `order` (optional): Sort order (asc, desc)

**Example:**
```
GET /api/songs?page=1&limit=10&mood=happy&sort=stats.totalPlays&order=desc
```

#### GET `/api/songs/:id`
Get song by ID.

#### GET `/api/songs/search/:query`
Search songs by title, artist, or album.

#### GET `/api/songs/mood/:mood`
Get songs by specific mood.

#### GET `/api/songs/trending`
Get trending songs.

#### POST `/api/songs/:id/like`
Like a song (requires authentication).

#### POST `/api/songs/:id/dislike`
Dislike a song (requires authentication).

### Comments Endpoints

#### POST `/api/comments`
Add a new comment to a song (requires authentication).

**Request Body:**
```json
{
  "songId": "song_id",
  "text": "This song makes me feel so happy and energetic!",
  "userSelectedMood": "happy" // optional
}
```

**Response:**
```json
{
  "success": true,
  "message": "Comment added successfully",
  "data": {
    "comment": {
      "id": "comment_id",
      "text": "This song makes me feel so happy and energetic!",
      "detectedMood": "happy",
      "confidence": 0.85,
      "sentiment": {
        "score": 0.8,
        "positive": ["happy", "energetic"],
        "negative": []
      }
    }
  }
}
```

#### GET `/api/comments`
Get comments with filtering and pagination.

#### GET `/api/comments/:id`
Get comment by ID.

#### PUT `/api/comments/:id`
Update a comment (requires authentication, owner only).

#### DELETE `/api/comments/:id`
Delete a comment (requires authentication, owner only).

#### POST `/api/comments/:id/like`
Like a comment (requires authentication).

#### POST `/api/comments/:id/dislike`
Dislike a comment (requires authentication).

### Moods Endpoints

#### GET `/api/moods`
Get all available moods with statistics.

#### GET `/api/moods/:mood/songs`
Get songs by specific mood.

#### GET `/api/moods/:mood/comments`
Get comments by specific mood.

#### GET `/api/moods/stats/overview`
Get mood statistics overview.

#### POST `/api/moods/detect`
Detect mood from text (for testing/development).

**Request Body:**
```json
{
  "text": "This song makes me feel so happy and energetic!"
}
```

### Users Endpoints

#### GET `/api/users/profile`
Get current user's profile (requires authentication).

#### PUT `/api/users/profile`
Update current user's profile (requires authentication).

#### GET `/api/users/:id`
Get user by ID (public profile).

#### GET `/api/users/:id/comments`
Get comments by user.

#### GET `/api/users/:id/stats`
Get user statistics.

## 🔧 Database Models

### User Model
```javascript
{
  fullName: String,
  email: String (unique),
  password: String (hashed),
  avatar: String,
  role: String (user/admin),
  isActive: Boolean,
  preferences: {
    favoriteGenres: [String],
    favoriteMoods: [String],
    language: String
  },
  stats: {
    totalLikes: Number,
    totalComments: Number,
    totalPlaylists: Number,
    lastActive: Date
  }
}
```

### Song Model
```javascript
{
  title: String,
  artist: String,
  album: String,
  coverImage: String,
  audioUrl: String,
  duration: Number,
  releaseYear: Number,
  genres: [String],
  moodDistribution: {
    happy: Number,
    sad: Number,
    energetic: Number,
    // ... other moods
  },
  primaryMood: String,
  audioFeatures: {
    tempo: Number,
    energy: Number,
    danceability: Number,
    // ... other features
  },
  stats: {
    totalPlays: Number,
    totalLikes: Number,
    totalDislikes: Number,
    totalComments: Number,
    averageRating: Number
  }
}
```

### Comment Model
```javascript
{
  songId: ObjectId,
  userId: ObjectId,
  text: String,
  detectedMood: String,
  moodConfidence: Number,
  userSelectedMood: String,
  finalMood: String,
  sentiment: {
    score: Number,
    comparative: Number,
    tokens: [String],
    positive: [String],
    negative: [String]
  },
  moodKeywords: [{
    word: String,
    mood: String,
    confidence: Number
  }],
  likes: Number,
  dislikes: Number,
  replies: [{
    userId: ObjectId,
    text: String,
    createdAt: Date
  }]
}
```

## 🧠 Mood Detection

The mood detection system uses a combination of:

1. **Keyword Analysis**: Predefined mood-specific keywords
2. **Sentiment Analysis**: Natural language processing for sentiment
3. **Confidence Scoring**: Weighted scoring system for mood classification

### Supported Moods
- Happy 😊
- Sad 😢
- Energetic ⚡
- Calm 😌
- Romantic 💕
- Angry 😠
- Melancholic 😔
- Uplifting ✨
- Chill 😎
- Party 🎉

## 🔒 Security Features

- **Password Hashing**: bcryptjs with configurable rounds
- **JWT Authentication**: Secure token-based authentication
- **Input Validation**: Comprehensive request validation
- **Rate Limiting**: API rate limiting to prevent abuse
- **Security Headers**: Helmet.js for security headers
- **CORS Configuration**: Configurable CORS settings
- **Error Handling**: Secure error responses

## 📊 Performance Optimizations

- **Database Indexing**: Optimized indexes for common queries
- **Query Optimization**: Efficient MongoDB queries
- **Pagination**: Proper pagination for large datasets
- **Caching**: Ready for Redis integration
- **Compression**: Response compression with compression middleware

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

## 📝 Logging

The application uses Winston for structured logging:

- **Console Logging**: Development environment
- **File Logging**: Production environment
- **Error Logging**: Separate error log files
- **Request Logging**: HTTP request logging with Morgan

## 🚀 Deployment

### Environment Variables
```env
# Server
PORT=5000
NODE_ENV=production

# Database
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/beatbuddy

# JWT
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRE=7d

# Security
BCRYPT_ROUNDS=12
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# CORS
CORS_ORIGIN=https://your-frontend-domain.com
```

### Production Checklist
- [ ] Set NODE_ENV=production
- [ ] Configure MongoDB connection string
- [ ] Set secure JWT_SECRET
- [ ] Configure CORS_ORIGIN
- [ ] Set up proper logging
- [ ] Configure rate limiting
- [ ] Set up monitoring and alerts

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the API documentation
- Review the logs for debugging

## 🔮 Future Enhancements

- [ ] Real-time notifications with Socket.io
- [ ] Advanced recommendation algorithms
- [ ] Social features (following, sharing)
- [ ] Playlist management
- [ ] Audio streaming capabilities
- [ ] Mobile app API endpoints
- [ ] Analytics and insights
- [ ] Machine learning improvements


