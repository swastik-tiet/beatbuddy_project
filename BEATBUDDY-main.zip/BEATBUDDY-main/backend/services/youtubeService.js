const https = require('https');
const Song = require('../models/Song');

const YT_API_BASE = 'https://www.googleapis.com/youtube/v3';
const API_KEY = process.env.YOUTUBE_API_KEY;
const REGION_CODE = process.env.YOUTUBE_REGION || 'US';

function httpGetJson(url) {
  return new Promise((resolve, reject) => {
    https
      .get(url, res => {
        let data = '';
        res.on('data', chunk => (data += chunk));
        res.on('end', () => {
          try {
            const json = JSON.parse(data);
            if (res.statusCode >= 400) return reject(json);
            resolve(json);
          } catch (e) {
            reject(e);
          }
        });
      })
      .on('error', reject);
  });
}

function iso8601ToSeconds(duration) {
  const re = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
  const m = re.exec(duration || '');
  if (!m) return 0;
  const h = parseInt(m[1] || '0', 10);
  const min = parseInt(m[2] || '0', 10);
  const s = parseInt(m[3] || '0', 10);
  return h * 3600 + min * 60 + s;
}

function classifyGenres({ title = '', description = '', tags = [] }) {
  const text = `${title} ${description} ${tags.join(' ')}`.toLowerCase();
  const mapping = [
    { key: 'pop', words: ['pop', 'synth', 'dance pop'] },
    { key: 'rock', words: ['rock', 'guitar', 'metal', 'punk'] },
    { key: 'jazz', words: ['jazz', 'sax', 'swing', 'bebop'] },
    { key: 'classical', words: ['classical', 'symphony', 'orchestra', 'mozart', 'beethoven'] },
    { key: 'hip-hop', words: ['hip hop', 'hip-hop', 'rap', 'trap'] },
    { key: 'electronic', words: ['edm', 'electro', 'house', 'techno', 'trance', 'dubstep'] },
    { key: 'country', words: ['country', 'banjo'] },
    { key: 'r&b', words: ['r&b', 'rnb', 'soul'] },
    { key: 'indie', words: ['indie'] },
    { key: 'folk', words: ['folk'] },
    { key: 'blues', words: ['blues'] },
    { key: 'reggae', words: ['reggae', 'dancehall'] },
    { key: 'metal', words: ['metal', 'deathcore', 'metalcore'] },
    { key: 'punk', words: ['punk'] },
    { key: 'alternative', words: ['alternative', 'alt'] }
  ];
  const genres = new Set();
  for (const m of mapping) {
    if (m.words.some(w => text.includes(w))) genres.add(m.key);
  }
  if (genres.size === 0) genres.add('pop');
  return Array.from(genres);
}

function parseArtistTitle(title) {
  const t = title || '';
  if (t.includes(' - ')) {
    const [artist, rest] = t.split(' - ', 2);
    return { artist: artist.trim(), title: rest.trim() };
  }
  return { artist: 'Unknown', title: t.trim() };
}

async function getVideosDetails(ids) {
  if (!ids.length) return [];
  const url = `${YT_API_BASE}/videos?part=snippet,contentDetails&id=${ids.join(',')}&key=${API_KEY}`;
  const json = await httpGetJson(encodeURI(url));
  return json.items || [];
}

async function searchYouTubeVideos(q, maxResults = 10) {
  const url = `${YT_API_BASE}/search?part=snippet&type=video&videoCategoryId=10&regionCode=${REGION_CODE}&q=${encodeURIComponent(q)}&maxResults=${Math.min(
    Number(maxResults) || 10,
    50
  )}&key=${API_KEY}`;
  const json = await httpGetJson(url);
  const ids = (json.items || []).map(i => i.id && i.id.videoId).filter(Boolean);
  const details = await getVideosDetails(ids);
  return details;
}

async function fetchPlaylistVideos(playlistId, maxResults = 25) {
  const url = `${YT_API_BASE}/playlistItems?part=snippet&playlistId=${encodeURIComponent(playlistId)}&maxResults=${Math.min(
    Number(maxResults) || 25,
    50
  )}&key=${API_KEY}`;
  const json = await httpGetJson(url);
  const ids = (json.items || [])
    .map(i => i.snippet && i.snippet.resourceId && i.snippet.resourceId.videoId)
    .filter(Boolean);
  const details = await getVideosDetails(ids);
  return details;
}

function mapVideoToSongPayload(item) {
  const id = item.id;
  const snippet = item.snippet || {};
  const content = item.contentDetails || {};
  const { artist, title } = parseArtistTitle(snippet.title || '');
  const tags = snippet.tags || [];
  const genres = classifyGenres({ title: snippet.title, description: snippet.description || '', tags });
  const duration = iso8601ToSeconds(content.duration || 'PT0S');
  const publishedAt = snippet.publishedAt ? new Date(snippet.publishedAt) : null;
  const releaseYear = publishedAt ? publishedAt.getFullYear() : undefined;

  return {
    title,
    artist,
    album: '',
    coverImage: (snippet.thumbnails && (snippet.thumbnails.high || snippet.thumbnails.medium || snippet.thumbnails.default) || {}).url || '',
    audioUrl: `https://www.youtube.com/watch?v=${id}`,
    duration: duration || 180,
    releaseYear,
    genres,
    language: 'en',
    explicit: false,
    audioFeatures: {},
    stats: {},
    isActive: true,
    source: 'youtube',
    externalId: id,
    tags: Array.from(new Set([...(tags || []), 'youtube']))
  };
}

async function upsertSongsFromVideos(items) {
  const results = [];
  for (const item of items) {
    const payload = mapVideoToSongPayload(item);
    if (!payload.coverImage) continue;
    const update = {
      $setOnInsert: {
        title: payload.title,
        artist: payload.artist,
        album: payload.album,
        language: payload.language,
        explicit: payload.explicit,
        audioFeatures: payload.audioFeatures,
        stats: payload.stats,
        isActive: payload.isActive,
        source: payload.source,
        externalId: payload.externalId
      },
      $set: {
        coverImage: payload.coverImage,
        audioUrl: payload.audioUrl,
        duration: payload.duration,
        releaseYear: payload.releaseYear,
        genres: payload.genres,
        tags: payload.tags
      }
    };
    const doc = await Song.findOneAndUpdate(
      { externalId: payload.externalId, source: 'youtube' },
      update,
      { upsert: true, new: true }
    );
    results.push(doc);
  }
  return results;
}

async function importFromSearch(q, maxResults) {
  if (!API_KEY) throw new Error('YOUTUBE_API_KEY is not set');
  const videos = await searchYouTubeVideos(q, maxResults);
  return upsertSongsFromVideos(videos);
}

async function importFromPlaylist(playlistId, maxResults) {
  if (!API_KEY) throw new Error('YOUTUBE_API_KEY is not set');
  const videos = await fetchPlaylistVideos(playlistId, maxResults);
  return upsertSongsFromVideos(videos);
}

module.exports = {
  importFromSearch,
  importFromPlaylist
};
