const natural = require('natural');
const Sentiment = require('sentiment');

class MoodDetectionService {
  constructor() {
    this.sentiment = new Sentiment();
    this.tokenizer = new natural.WordTokenizer();
    this.initializeMoodKeywords();
    this.initializeSentimentWords();
  }

  initializeMoodKeywords() {
    this.moodKeywords = {
      happy: [
        'happy', 'joy', 'cheerful', 'delighted', 'excited', 'thrilled', 'amazing', 'wonderful', 'fantastic',
        'great', 'awesome', 'brilliant', 'perfect', 'love', 'adore', 'enjoy', 'fun', 'laugh', 'smile',
        'positive', 'uplifting', 'energizing', 'feel good', 'makes me happy', 'puts me in a good mood',
        'sunshine', 'bright', 'vibrant', 'colorful', 'dance', 'sing', 'celebrate', 'party', 'festive'
      ],
      sad: [
        'sad', 'depressed', 'melancholy', 'blue', 'down', 'low', 'miserable', 'heartbroken', 'cry',
        'tears', 'weep', 'sob', 'grief', 'sorrow', 'pain', 'hurt', 'lonely', 'alone', 'empty',
        'hopeless', 'despair', 'gloomy', 'dark', 'heavy', 'weight', 'burden', 'miss', 'loss',
        'nostalgic', 'yearning', 'longing', 'missing', 'reminds me of', 'brings back memories'
      ],
      energetic: [
        'energetic', 'energized', 'pumped', 'hyped', 'excited', 'thrilled', 'adrenaline', 'rush',
        'powerful', 'strong', 'intense', 'dynamic', 'vibrant', 'lively', 'active', 'motivated',
        'inspired', 'driven', 'focused', 'determined', 'confident', 'bold', 'aggressive', 'fierce',
        'workout', 'exercise', 'gym', 'running', 'training', 'competition', 'challenge', 'victory'
      ],
      calm: [
        'calm', 'peaceful', 'serene', 'tranquil', 'relaxed', 'chilled', 'mellow', 'smooth', 'gentle',
        'soft', 'quiet', 'soothing', 'comforting', 'healing', 'therapeutic', 'meditation', 'zen',
        'mindful', 'centered', 'balanced', 'grounded', 'stable', 'steady', 'consistent', 'flow',
        'nature', 'ocean', 'forest', 'mountains', 'sunset', 'morning', 'evening', 'night'
      ],
      romantic: [
        'romantic', 'love', 'passionate', 'intimate', 'tender', 'sweet', 'affectionate', 'caring',
        'warm', 'heart', 'soul', 'connection', 'bond', 'relationship', 'couple', 'together',
        'forever', 'eternal', 'beautiful', 'gorgeous', 'stunning', 'perfect', 'dream', 'fantasy',
        'date', 'dinner', 'candlelight', 'rose', 'flower', 'kiss', 'hug', 'embrace'
      ],
      angry: [
        'angry', 'mad', 'furious', 'rage', 'fury', 'outrage', 'irritated', 'annoyed', 'frustrated',
        'aggressive', 'violent', 'intense', 'powerful', 'strong', 'forceful', 'assertive', 'bold',
        'confrontational', 'defiant', 'rebellious', 'fight', 'battle', 'war', 'struggle', 'conflict',
        'hate', 'despise', 'loathe', 'disgust', 'repulsion', 'rejection', 'betrayal', 'betrayed'
      ],
      melancholic: [
        'melancholic', 'melancholy', 'nostalgic', 'yearning', 'longing', 'wistful', 'dreamy',
        'contemplative', 'reflective', 'thoughtful', 'introspective', 'philosophical', 'deep',
        'profound', 'meaningful', 'significant', 'important', 'valuable', 'precious', 'treasured',
        'memories', 'past', 'history', 'legacy', 'heritage', 'tradition', 'roots', 'origin'
      ],
      uplifting: [
        'uplifting', 'inspiring', 'motivational', 'encouraging', 'empowering', 'strengthening',
        'confidence', 'hope', 'optimism', 'positive', 'bright', 'light', 'shine', 'glow',
        'radiant', 'brilliant', 'sparkle', 'twinkle', 'glitter', 'magical', 'wonderful',
        'amazing', 'incredible', 'extraordinary', 'exceptional', 'outstanding', 'remarkable'
      ],
      chill: [
        'chill', 'relaxed', 'laid-back', 'easy-going', 'casual', 'comfortable', 'cozy', 'warm',
        'friendly', 'welcoming', 'inviting', 'pleasant', 'nice', 'good', 'fine', 'okay',
        'decent', 'satisfactory', 'adequate', 'sufficient', 'enough', 'plenty', 'abundant',
        'generous', 'kind', 'gentle', 'soft', 'smooth', 'flowing', 'natural', 'organic'
      ],
      party: [
        'party', 'celebration', 'festival', 'carnival', 'revelry', 'merriment', 'fun', 'enjoyment',
        'entertainment', 'amusement', 'pleasure', 'delight', 'joy', 'happiness', 'excitement',
        'thrill', 'adventure', 'experience', 'journey', 'trip', 'voyage', 'exploration',
        'discovery', 'new', 'fresh', 'original', 'unique', 'special', 'different', 'unusual'
      ]
    };
  }

  initializeSentimentWords() {
    // Add custom sentiment words for better mood detection
    this.sentiment.registerLanguage('en', {
      labels: {
        'happy': 2,
        'joy': 2,
        'excited': 2,
        'thrilled': 2,
        'amazing': 2,
        'wonderful': 2,
        'fantastic': 2,
        'brilliant': 2,
        'perfect': 2,
        'love': 2,
        'adore': 2,
        'enjoy': 1,
        'fun': 1,
        'uplifting': 2,
        'energizing': 1,
        'sad': -2,
        'depressed': -2,
        'melancholy': -1,
        'blue': -1,
        'miserable': -2,
        'heartbroken': -2,
        'cry': -1,
        'grief': -2,
        'sorrow': -2,
        'pain': -2,
        'hurt': -1,
        'lonely': -1,
        'hopeless': -2,
        'despair': -2,
        'angry': -2,
        'furious': -2,
        'rage': -2,
        'irritated': -1,
        'annoyed': -1,
        'frustrated': -1,
        'hate': -2,
        'despise': -2,
        'calm': 1,
        'peaceful': 1,
        'serene': 1,
        'relaxed': 1,
        'soothing': 1,
        'comforting': 1,
        'romantic': 2,
        'passionate': 1,
        'tender': 1,
        'sweet': 1,
        'beautiful': 1,
        'gorgeous': 1,
        'energetic': 1,
        'pumped': 1,
        'powerful': 1,
        'strong': 1,
        'motivated': 1,
        'inspired': 1,
        'confident': 1,
        'melancholic': -1,
        'nostalgic': 0,
        'yearning': 0,
        'contemplative': 0,
        'reflective': 0,
        'uplifting': 2,
        'inspiring': 2,
        'motivational': 1,
        'encouraging': 1,
        'hope': 1,
        'optimism': 1,
        'chill': 1,
        'laid-back': 1,
        'comfortable': 1,
        'cozy': 1,
        'party': 1,
        'celebration': 1,
        'festival': 1,
        'fun': 1,
        'entertainment': 1
      }
    });
  }

  detectMood(comment) {
    const text = comment.toLowerCase();
    const tokens = this.tokenizer.tokenize(text);
    const sentimentResult = this.sentiment.analyze(text);
    
    // Calculate mood scores
    const moodScores = {};
    const moodKeywords = {};

    // Initialize all moods with 0 score
    Object.keys(this.moodKeywords).forEach(mood => {
      moodScores[mood] = 0;
      moodKeywords[mood] = [];
    });

    // Check for mood keywords
    tokens.forEach(token => {
      Object.entries(this.moodKeywords).forEach(([mood, keywords]) => {
        if (keywords.includes(token)) {
          moodScores[mood] += 1;
          moodKeywords[mood].push({
            word: token,
            mood: mood,
            confidence: 0.8
          });
        }
      });
    });

    // Check for multi-word phrases
    Object.entries(this.moodKeywords).forEach(([mood, keywords]) => {
      keywords.forEach(keyword => {
        if (keyword.includes(' ') && text.includes(keyword)) {
          moodScores[mood] += 2; // Higher weight for phrases
          moodKeywords[mood].push({
            word: keyword,
            mood: mood,
            confidence: 0.9
          });
        }
      });
    });

    // Factor in sentiment analysis
    const sentimentScore = sentimentResult.score;
    const sentimentComparative = sentimentResult.comparative;

    // Adjust mood scores based on sentiment
    if (sentimentScore > 0) {
      moodScores.happy += Math.abs(sentimentScore) * 0.5;
      moodScores.energetic += Math.abs(sentimentScore) * 0.3;
      moodScores.uplifting += Math.abs(sentimentScore) * 0.4;
    } else if (sentimentScore < 0) {
      moodScores.sad += Math.abs(sentimentScore) * 0.5;
      moodScores.melancholic += Math.abs(sentimentScore) * 0.3;
      moodScores.angry += Math.abs(sentimentScore) * 0.2;
    }

    // Find the mood with highest score
    let detectedMood = 'chill'; // Default mood
    let maxScore = 0;
    let confidence = 0.5; // Default confidence

    Object.entries(moodScores).forEach(([mood, score]) => {
      if (score > maxScore) {
        maxScore = score;
        detectedMood = mood;
      }
    });

    // Calculate confidence based on score and sentiment
    if (maxScore > 0) {
      confidence = Math.min(0.9, 0.5 + (maxScore * 0.1) + (Math.abs(sentimentComparative) * 0.3));
    }

    // Special cases based on sentiment patterns
    if (sentimentScore > 2 && moodScores.happy > 0) {
      detectedMood = 'happy';
      confidence = Math.max(confidence, 0.8);
    } else if (sentimentScore < -2 && moodScores.sad > 0) {
      detectedMood = 'sad';
      confidence = Math.max(confidence, 0.8);
    } else if (sentimentScore > 1 && moodScores.energetic > 0) {
      detectedMood = 'energetic';
      confidence = Math.max(confidence, 0.7);
    }

    return {
      detectedMood,
      confidence,
      moodScores,
      moodKeywords: moodKeywords[detectedMood] || [],
      sentiment: {
        score: sentimentScore,
        comparative: sentimentComparative,
        tokens: sentimentResult.tokens,
        positive: sentimentResult.positive,
        negative: sentimentResult.negative
      }
    };
  }

  getMoodColor(mood) {
    const moodColors = {
      happy: '#FFD700', // Gold
      sad: '#4682B4', // Steel Blue
      energetic: '#FF4500', // Orange Red
      calm: '#98FB98', // Pale Green
      romantic: '#FF69B4', // Hot Pink
      angry: '#DC143C', // Crimson
      melancholic: '#708090', // Slate Gray
      uplifting: '#32CD32', // Lime Green
      chill: '#87CEEB', // Sky Blue
      party: '#FF1493' // Deep Pink
    };
    return moodColors[mood] || '#808080';
  }

  getMoodEmoji(mood) {
    const moodEmojis = {
      happy: '😊',
      sad: '😢',
      energetic: '⚡',
      calm: '😌',
      romantic: '💕',
      angry: '😠',
      melancholic: '😔',
      uplifting: '✨',
      chill: '😎',
      party: '🎉'
    };
    return moodEmojis[mood] || '🎵';
  }

  getMoodDisplayName(mood) {
    const moodNames = {
      happy: 'Happy',
      sad: 'Sad',
      energetic: 'Energetic',
      calm: 'Calm',
      romantic: 'Romantic',
      angry: 'Angry',
      melancholic: 'Melancholic',
      uplifting: 'Uplifting',
      chill: 'Chill',
      party: 'Party'
    };
    return moodNames[mood] || 'Unknown';
  }

  analyzeMoodDistribution(comments) {
    const distribution = {
      happy: 0,
      sad: 0,
      energetic: 0,
      calm: 0,
      romantic: 0,
      angry: 0,
      melancholic: 0,
      uplifting: 0,
      chill: 0,
      party: 0
    };

    comments.forEach(comment => {
      if (comment.finalMood && distribution[comment.finalMood] !== undefined) {
        distribution[comment.finalMood]++;
      }
    });

    return distribution;
  }

  getPrimaryMood(comments) {
    const distribution = this.analyzeMoodDistribution(comments);
    let maxCount = 0;
    let primaryMood = null;

    Object.entries(distribution).forEach(([mood, count]) => {
      if (count > maxCount) {
        maxCount = count;
        primaryMood = mood;
      }
    });

    return primaryMood;
  }

  getMoodConfidence(comment) {
    // This would typically be calculated during mood detection
    // For now, return a default confidence based on comment length
    const length = comment.text.length;
    if (length < 10) return 0.3;
    if (length < 50) return 0.5;
    if (length < 100) return 0.7;
    return 0.8;
  }
}

module.exports = new MoodDetectionService();


