const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Song = require('../models/Song');
const Comment = require('../models/Comment');

// Sample data
const sampleUsers = [
  {
    fullName: 'John Doe',
    email: 'john@example.com',
    password: 'Password123',
    preferences: {
      favoriteGenres: ['pop', 'rock'],
      favoriteMoods: ['happy', 'energetic'],
      language: 'en'
    }
  },
  {
    fullName: 'Jane Smith',
    email: 'jane@example.com',
    password: 'Password123',
    preferences: {
      favoriteGenres: ['jazz', 'classical'],
      favoriteMoods: ['calm', 'romantic'],
      language: 'en'
    }
  },
  {
    fullName: 'Mike Johnson',
    email: 'mike@example.com',
    password: 'Password123',
    preferences: {
      favoriteGenres: ['hip-hop', 'electronic'],
      favoriteMoods: ['energetic', 'party'],
      language: 'en'
    }
  }
];

const sampleSongs = [
  {
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    album: 'After Hours',
    coverImage: 'https://picsum.photos/300/300?random=1',
    audioUrl: 'https://example.com/audio/blinding-lights.mp3',
    duration: 200, // 3:20
    releaseYear: 2020,
    genres: ['pop', 'synthwave', 'r&b'],
    audioFeatures: {
      tempo: 171,
      energy: 0.8,
      danceability: 0.9,
      valence: 0.6,
      acousticness: 0.1,
      instrumentalness: 0.0,
      loudness: -5.8,
      key: 1,
      mode: 1,
      timeSignature: 4
    }
  },
  {
    title: 'Shape of You',
    artist: 'Ed Sheeran',
    album: '÷ (Divide)',
    coverImage: 'https://picsum.photos/300/300?random=2',
    audioUrl: 'https://example.com/audio/shape-of-you.mp3',
    duration: 233, // 3:53
    releaseYear: 2017,
    genres: ['pop', 'tropical house'],
    audioFeatures: {
      tempo: 96,
      energy: 0.7,
      danceability: 0.8,
      valence: 0.7,
      acousticness: 0.2,
      instrumentalness: 0.0,
      loudness: -6.2,
      key: 7,
      mode: 1,
      timeSignature: 4
    }
  },
  {
    title: 'Bohemian Rhapsody',
    artist: 'Queen',
    album: 'A Night at the Opera',
    coverImage: 'https://picsum.photos/300/300?random=3',
    audioUrl: 'https://example.com/audio/bohemian-rhapsody.mp3',
    duration: 354, // 5:54
    releaseYear: 1975,
    genres: ['rock', 'progressive rock'],
    audioFeatures: {
      tempo: 72,
      energy: 0.6,
      danceability: 0.3,
      valence: 0.4,
      acousticness: 0.3,
      instrumentalness: 0.1,
      loudness: -8.5,
      key: 8,
      mode: 1,
      timeSignature: 4
    }
  },
  {
    title: 'Billie Jean',
    artist: 'Michael Jackson',
    album: 'Thriller',
    coverImage: 'https://picsum.photos/300/300?random=4',
    audioUrl: 'https://example.com/audio/billie-jean.mp3',
    duration: 294, // 4:54
    releaseYear: 1982,
    genres: ['pop', 'funk', 'disco'],
    audioFeatures: {
      tempo: 117,
      energy: 0.8,
      danceability: 0.9,
      valence: 0.5,
      acousticness: 0.1,
      instrumentalness: 0.0,
      loudness: -6.8,
      key: 0,
      mode: 1,
      timeSignature: 4
    }
  },
  {
    title: 'Hotel California',
    artist: 'Eagles',
    album: 'Hotel California',
    coverImage: 'https://picsum.photos/300/300?random=5',
    audioUrl: 'https://example.com/audio/hotel-california.mp3',
    duration: 391, // 6:31
    releaseYear: 1976,
    genres: ['rock', 'soft rock'],
    audioFeatures: {
      tempo: 75,
      energy: 0.5,
      danceability: 0.4,
      valence: 0.3,
      acousticness: 0.4,
      instrumentalness: 0.2,
      loudness: -9.2,
      key: 4,
      mode: 0,
      timeSignature: 4
    }
  },
  {
    title: 'Imagine',
    artist: 'John Lennon',
    album: 'Imagine',
    coverImage: 'https://picsum.photos/300/300?random=6',
    audioUrl: 'https://example.com/audio/imagine.mp3',
    duration: 183, // 3:03
    releaseYear: 1971,
    genres: ['rock', 'pop'],
    audioFeatures: {
      tempo: 76,
      energy: 0.3,
      danceability: 0.3,
      valence: 0.6,
      acousticness: 0.8,
      instrumentalness: 0.0,
      loudness: -12.5,
      key: 0,
      mode: 1,
      timeSignature: 4
    }
  },
  {
    title: 'Stairway to Heaven',
    artist: 'Led Zeppelin',
    album: 'Led Zeppelin IV',
    coverImage: 'https://picsum.photos/300/300?random=7',
    audioUrl: 'https://example.com/audio/stairway-to-heaven.mp3',
    duration: 482, // 8:02
    releaseYear: 1971,
    genres: ['rock', 'hard rock'],
    audioFeatures: {
      tempo: 63,
      energy: 0.7,
      danceability: 0.2,
      valence: 0.3,
      acousticness: 0.2,
      instrumentalness: 0.3,
      loudness: -8.8,
      key: 9,
      mode: 0,
      timeSignature: 4
    }
  },
  {
    title: 'Wonderwall',
    artist: 'Oasis',
    album: '(What\'s the Story) Morning Glory?',
    coverImage: 'https://picsum.photos/300/300?random=8',
    audioUrl: 'https://example.com/audio/wonderwall.mp3',
    duration: 258, // 4:18
    releaseYear: 1995,
    genres: ['rock', 'britpop'],
    audioFeatures: {
      tempo: 87,
      energy: 0.6,
      danceability: 0.5,
      valence: 0.5,
      acousticness: 0.3,
      instrumentalness: 0.0,
      loudness: -7.2,
      key: 2,
      mode: 1,
      timeSignature: 4
    }
  }
];

const sampleComments = [
  {
    text: 'This song makes me feel so happy and energetic! Perfect for driving at night.',
    detectedMood: 'happy',
    moodConfidence: 0.85,
    sentiment: {
      score: 0.8,
      comparative: 0.2,
      tokens: ['happy', 'energetic', 'perfect', 'driving'],
      positive: ['happy', 'energetic', 'perfect'],
      negative: []
    }
  },
  {
    text: 'I love this song! It always puts me in a good mood and makes me want to dance.',
    detectedMood: 'happy',
    moodConfidence: 0.9,
    sentiment: {
      score: 0.9,
      comparative: 0.25,
      tokens: ['love', 'good', 'mood', 'dance'],
      positive: ['love', 'good', 'mood', 'dance'],
      negative: []
    }
  },
  {
    text: 'This is such a beautiful and romantic song. It makes me feel so calm and peaceful.',
    detectedMood: 'romantic',
    moodConfidence: 0.8,
    sentiment: {
      score: 0.7,
      comparative: 0.18,
      tokens: ['beautiful', 'romantic', 'calm', 'peaceful'],
      positive: ['beautiful', 'romantic', 'calm', 'peaceful'],
      negative: []
    }
  },
  {
    text: 'This song is so sad and melancholic. It brings back so many memories.',
    detectedMood: 'sad',
    moodConfidence: 0.75,
    sentiment: {
      score: -0.3,
      comparative: -0.08,
      tokens: ['sad', 'melancholic', 'memories'],
      positive: ['memories'],
      negative: ['sad', 'melancholic']
    }
  },
  {
    text: 'This track is so energetic and powerful! It pumps me up for workouts.',
    detectedMood: 'energetic',
    moodConfidence: 0.9,
    sentiment: {
      score: 0.6,
      comparative: 0.15,
      tokens: ['energetic', 'powerful', 'pumps', 'workouts'],
      positive: ['energetic', 'powerful', 'pumps', 'workouts'],
      negative: []
    }
  },
  {
    text: 'I feel so calm and relaxed when I listen to this. Perfect for meditation.',
    detectedMood: 'calm',
    moodConfidence: 0.85,
    sentiment: {
      score: 0.5,
      comparative: 0.13,
      tokens: ['calm', 'relaxed', 'perfect', 'meditation'],
      positive: ['calm', 'relaxed', 'perfect', 'meditation'],
      negative: []
    }
  },
  {
    text: 'This song makes me so angry and frustrated. I can\'t stand it.',
    detectedMood: 'angry',
    moodConfidence: 0.8,
    sentiment: {
      score: -0.8,
      comparative: -0.2,
      tokens: ['angry', 'frustrated', 'stand'],
      positive: [],
      negative: ['angry', 'frustrated']
    }
  },
  {
    text: 'This is such an uplifting and inspiring song. It gives me hope.',
    detectedMood: 'uplifting',
    moodConfidence: 0.9,
    sentiment: {
      score: 0.9,
      comparative: 0.23,
      tokens: ['uplifting', 'inspiring', 'hope'],
      positive: ['uplifting', 'inspiring', 'hope'],
      negative: []
    }
  },
  {
    text: 'This is a perfect party song! It gets everyone dancing and having fun.',
    detectedMood: 'party',
    moodConfidence: 0.85,
    sentiment: {
      score: 0.7,
      comparative: 0.18,
      tokens: ['perfect', 'party', 'dancing', 'fun'],
      positive: ['perfect', 'party', 'dancing', 'fun'],
      negative: []
    }
  },
  {
    text: 'This song is so chill and laid-back. Perfect for a lazy Sunday afternoon.',
    detectedMood: 'chill',
    moodConfidence: 0.8,
    sentiment: {
      score: 0.6,
      comparative: 0.15,
      tokens: ['chill', 'laid-back', 'perfect', 'lazy'],
      positive: ['chill', 'laid-back', 'perfect'],
      negative: ['lazy']
    }
  }
];

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/beatbuddy');
    console.log('MongoDB connected for seeding...');
  } catch (error) {
    console.error('Database connection error:', error);
    process.exit(1);
  }
};

// Clear existing data
const clearData = async () => {
  try {
    await User.deleteMany({});
    await Song.deleteMany({});
    await Comment.deleteMany({});
    console.log('Existing data cleared.');
  } catch (error) {
    console.error('Error clearing data:', error);
  }
};

// Seed users
const seedUsers = async () => {
  try {
    const users = [];
    
    for (const userData of sampleUsers) {
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      const user = new User({
        ...userData,
        password: hashedPassword
      });
      users.push(await user.save());
    }
    
    console.log(`${users.length} users seeded successfully.`);
    return users;
  } catch (error) {
    console.error('Error seeding users:', error);
    return [];
  }
};

// Seed songs
const seedSongs = async () => {
  try {
    const songs = [];
    
    for (const songData of sampleSongs) {
      const song = new Song(songData);
      songs.push(await song.save());
    }
    
    console.log(`${songs.length} songs seeded successfully.`);
    return songs;
  } catch (error) {
    console.error('Error seeding songs:', error);
    return [];
  }
};

// Seed comments
const seedComments = async (users, songs) => {
  try {
    const comments = [];
    
    for (let i = 0; i < songs.length; i++) {
      const song = songs[i];
      const user = users[i % users.length];
      const commentData = sampleComments[i % sampleComments.length];
      
      const comment = new Comment({
        songId: song._id,
        userId: user._id,
        text: commentData.text,
        detectedMood: commentData.detectedMood,
        moodConfidence: commentData.moodConfidence,
        finalMood: commentData.detectedMood,
        sentiment: commentData.sentiment,
        moodKeywords: [
          {
            word: commentData.detectedMood,
            mood: commentData.detectedMood,
            confidence: commentData.moodConfidence
          }
        ]
      });
      
      comments.push(await comment.save());
    }
    
    console.log(`${comments.length} comments seeded successfully.`);
    return comments;
  } catch (error) {
    console.error('Error seeding comments:', error);
    return [];
  }
};

// Update song mood distributions
const updateSongMoodDistributions = async (songs, comments) => {
  try {
    for (const song of songs) {
      const songComments = comments.filter(comment => 
        comment.songId.toString() === song._id.toString()
      );
      
      const moodDistribution = {
        happy: 0,
        sad: 0,
        energetic: 0,
        calm: 0,
        romantic: 0,
        angry: 0,
        melancholic: 0,
        uplifting: 0,
        chill: 0,
        party: 0
      };
      
      songComments.forEach(comment => {
        if (moodDistribution[comment.finalMood] !== undefined) {
          moodDistribution[comment.finalMood]++;
        }
      });
      
      // Find primary mood
      let maxVotes = 0;
      let primaryMood = null;
      
      Object.entries(moodDistribution).forEach(([mood, votes]) => {
        if (votes > maxVotes) {
          maxVotes = votes;
          primaryMood = mood;
        }
      });
      
      await Song.findByIdAndUpdate(song._id, {
        moodDistribution,
        primaryMood,
        'stats.totalComments': songComments.length
      });
    }
    
    console.log('Song mood distributions updated successfully.');
  } catch (error) {
    console.error('Error updating song mood distributions:', error);
  }
};

// Main seeding function
const seedData = async () => {
  try {
    console.log('Starting data seeding...');
    
    await connectDB();
    await clearData();
    
    const users = await seedUsers();
    const songs = await seedSongs();
    const comments = await seedComments(users, songs);
    
    await updateSongMoodDistributions(songs, comments);
    
    console.log('Data seeding completed successfully!');
    console.log(`\nSummary:`);
    console.log(`- ${users.length} users created`);
    console.log(`- ${songs.length} songs created`);
    console.log(`- ${comments.length} comments created`);
    
    // Display sample user credentials
    console.log(`\nSample user credentials:`);
    sampleUsers.forEach(user => {
      console.log(`Email: ${user.email}, Password: ${user.password}`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error('Error during seeding:', error);
    process.exit(1);
  }
};

// Run seeding if this file is executed directly
if (require.main === module) {
  seedData();
}

module.exports = { seedData };


