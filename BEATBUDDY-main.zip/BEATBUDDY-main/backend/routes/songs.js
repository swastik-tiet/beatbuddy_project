const express = require("express");
const { body, query, validationResult } = require("express-validator");
const mongoose = require("mongoose");
const Song = require("../models/Song");
const Comment = require("../models/Comment");
const auth = require("../middleware/auth");
const { optionalAuth } = require("../middleware/auth");
const logger = require("../utils/logger");
const {
  importFromSearch,
  importFromPlaylist,
} = require("../services/youtubeService");

const router = express.Router();

// @route   GET /api/songs
// @desc    Get all songs with pagination and filtering
// @access  Public
router.get(
  "/",
  [
    query("page")
      .optional()
      .isInt({ min: 1 })
      .withMessage("Page must be a positive integer"),
    query("limit")
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage("Limit must be between 1 and 100"),
    query("genre").optional().isString().withMessage("Genre must be a string"),
    query("mood").optional().isString().withMessage("Mood must be a string"),
    query("artist")
      .optional()
      .isString()
      .withMessage("Artist must be a string"),
    query("sort")
      .optional()
      .isIn([
        "title",
        "artist",
        "releaseYear",
        "stats.totalPlays",
        "stats.averageRating",
      ])
      .withMessage("Invalid sort field"),
    query("order")
      .optional()
      .isIn(["asc", "desc"])
      .withMessage("Order must be asc or desc"),
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const {
        page = 1,
        limit = 20,
        genre,
        mood,
        artist,
        sort = "stats.totalPlays",
        order = "desc",
      } = req.query;

      // Build query
      const query = { isActive: true };

      if (genre) {
        query.genres = { $in: [genre] };
      }

      if (mood) {
        query.primaryMood = mood;
      }

      if (artist) {
        query.artist = { $regex: artist, $options: "i" };
      }

      // Execute query
      const songs = await Song.find(query)
        .sort({ [sort]: order === "desc" ? -1 : 1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit))
        .populate("comments", "text detectedMood createdAt")
        .lean();

      // Get total count for pagination
      const total = await Song.countDocuments(query);

      // Calculate pagination info
      const totalPages = Math.ceil(total / limit);
      const hasNextPage = page < totalPages;
      const hasPrevPage = page > 1;

      res.json({
        success: true,
        data: {
          songs,
          pagination: {
            currentPage: parseInt(page),
            totalPages,
            totalItems: total,
            hasNextPage,
            hasPrevPage,
            limit: parseInt(limit),
          },
        },
      });
    } catch (error) {
      logger.error("Get songs error:", error);
      res.status(500).json({
        success: false,
        message: "Server error while fetching songs",
      });
    }
  }
);

// @route   POST /api/songs/:id/play
// @desc    Record a play event for a song (increments stats.totalPlays)
// @access  Public
router.post("/:id/play", async (req, res) => {
  try {
    const { id } = req.params;
    const isMongoId = mongoose.Types.ObjectId.isValid(id);

    if (!isMongoId) {
      logger.info(
        `Play recorded for mock song id ${id} (no persistent record updated)`
      );
      return res.json({
        success: true,
        message: "Play recorded (mock data)",
        data: { totalPlays: null },
      });
    }

    const song = await Song.findByIdAndUpdate(
      id,
      { $inc: { "stats.totalPlays": 1 } },
      { new: true }
    ).lean();

    if (!song) {
      logger.warn(`Song not found while recording play: ${id}`);
      return res.json({
        success: true,
        message: "Play recorded (song not yet in database)",
        data: { totalPlays: null },
      });
    }

    logger.info(`Song played: ${song.title} (${song._id})`);

    return res.json({
      success: true,
      message: "Play recorded",
      data: { totalPlays: (song.stats && song.stats.totalPlays) || 0 },
    });
  } catch (error) {
    logger.error("Record play error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error while recording play" });
  }
});

// @route   POST /api/songs/import/youtube/search
// @desc    Import songs from YouTube search results into the database
// @access  Private
router.post(
  "/import/youtube/search",
  [
    auth,
    body("query")
      .isString()
      .trim()
      .isLength({ min: 1 })
      .withMessage("query is required"),
    body("maxResults")
      .optional()
      .isInt({ min: 1, max: 50 })
      .withMessage("maxResults must be between 1 and 50"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      const { query: q, maxResults = 10 } = req.body;
      const docs = await importFromSearch(q, maxResults);
      res.json({ success: true, data: { imported: docs.length, songs: docs } });
    } catch (error) {
      logger.error("YouTube search import error:", error);
      const status =
        error && error.error && error.error.code ? error.error.code : 500;
      res.status(status >= 400 && status < 600 ? status : 500).json({
        success: false,
        message: "Failed to import from YouTube search",
        error,
      });
    }
  }
);

// @route   POST /api/songs/import/youtube/playlist
// @desc    Import songs from a YouTube playlist into the database
// @access  Private
router.post(
  "/import/youtube/playlist",
  [
    auth,
    body("playlistId")
      .isString()
      .trim()
      .isLength({ min: 5 })
      .withMessage("playlistId is required"),
    body("maxResults")
      .optional()
      .isInt({ min: 1, max: 50 })
      .withMessage("maxResults must be between 1 and 50"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      const { playlistId, maxResults = 25 } = req.body;
      const docs = await importFromPlaylist(playlistId, maxResults);
      res.json({ success: true, data: { imported: docs.length, songs: docs } });
    } catch (error) {
      logger.error("YouTube playlist import error:", error);
      const status =
        error && error.error && error.error.code ? error.error.code : 500;
      res.status(status >= 400 && status < 600 ? status : 500).json({
        success: false,
        message: "Failed to import from YouTube playlist",
        error,
      });
    }
  }
);

// MOVED: GET /api/songs/:id to the end of file to avoid conflicts with specific routes

// @route   GET /api/songs/search/:query
// @desc    Search songs by title, artist, or album
// @access  Public
router.get(
  "/search/:query",
  [
    query("page")
      .optional()
      .isInt({ min: 1 })
      .withMessage("Page must be a positive integer"),
    query("limit")
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage("Limit must be between 1 and 100"),
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { query } = req.params;
      const { page = 1, limit = 20 } = req.query;

      const songs = await Song.searchSongs(query, parseInt(limit))
        .populate("comments", "text detectedMood createdAt")
        .lean();

      res.json({
        success: true,
        data: {
          songs,
          query,
          totalResults: songs.length,
        },
      });
    } catch (error) {
      logger.error("Search songs error:", error);
      res.status(500).json({
        success: false,
        message: "Server error while searching songs",
      });
    }
  }
);

// @route   GET /api/songs/mood/:mood
// @desc    Get songs by mood
// @access  Public
router.get(
  "/mood/:mood",
  [
    query("page")
      .optional()
      .isInt({ min: 1 })
      .withMessage("Page must be a positive integer"),
    query("limit")
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage("Limit must be between 1 and 100"),
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { mood } = req.params;
      const { page = 1, limit = 20 } = req.query;

      const songs = await Song.findByMood(mood, parseInt(limit))
        .populate("comments", "text detectedMood createdAt")
        .lean();

      res.json({
        success: true,
        data: {
          songs,
          mood,
          totalResults: songs.length,
        },
      });
    } catch (error) {
      logger.error("Get songs by mood error:", error);
      res.status(500).json({
        success: false,
        message: "Server error while fetching songs by mood",
      });
    }
  }
);

// @route   GET /api/songs/trending
// @desc    Get trending songs
// @access  Public
router.get(
  "/trending",
  [
    query("limit")
      .optional()
      .isInt({ min: 1, max: 50 })
      .withMessage("Limit must be between 1 and 50"),
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { limit = 20 } = req.query;

      const songs = await Song.getTrending(parseInt(limit))
        .populate("comments", "text detectedMood createdAt")
        .lean();

      res.json({
        success: true,
        data: {
          songs,
          totalResults: songs.length,
        },
      });
    } catch (error) {
      logger.error("Get trending songs error:", error);
      res.status(500).json({
        success: false,
        message: "Server error while fetching trending songs",
      });
    }
  }
);

// @route   POST /api/songs/:id/like
// @desc    Like a song
// @access  Private
router.post("/:id/like", auth, async (req, res) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) {
      return res.status(404).json({
        success: false,
        message: "Song not found",
      });
    }

    // Increment like count
    song.stats.totalLikes += 1;
    await song.save();

    // Update user stats
    await req.user.updateOne({
      $inc: { "stats.totalLikes": 1 },
    });

    logger.info(`User ${req.user.email} liked song: ${song.title}`);

    res.json({
      success: true,
      message: "Song liked successfully",
      data: {
        totalLikes: song.stats.totalLikes,
      },
    });
  } catch (error) {
    logger.error("Like song error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while liking song",
    });
  }
});

// @route   POST /api/songs/:id/dislike
// @desc    Dislike a song
// @access  Private
router.post("/:id/dislike", auth, async (req, res) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) {
      return res.status(404).json({
        success: false,
        message: "Song not found",
      });
    }

    // Increment dislike count
    song.stats.totalDislikes += 1;
    await song.save();

    logger.info(`User ${req.user.email} disliked song: ${song.title}`);

    res.json({
      success: true,
      message: "Song disliked successfully",
      data: {
        totalDislikes: song.stats.totalDislikes,
      },
    });
  } catch (error) {
    logger.error("Dislike song error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while disliking song",
    });
  }
});

// @route   GET /api/songs/:id/comments
// @desc    Get comments for a song
// @access  Public
router.get(
  "/:id/comments",
  [
    query("page")
      .optional()
      .isInt({ min: 1 })
      .withMessage("Page must be a positive integer"),
    query("limit")
      .optional()
      .isInt({ min: 1, max: 50 })
      .withMessage("Limit must be between 1 and 50"),
    query("mood").optional().isString().withMessage("Mood must be a string"),
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { page = 1, limit = 20, mood } = req.query;

      // Check if song exists
      const song = await Song.findById(req.params.id);
      if (!song) {
        return res.status(404).json({
          success: false,
          message: "Song not found",
        });
      }

      // Build query
      const query = { songId: req.params.id };
      if (mood) {
        query.finalMood = mood;
      }

      const comments = await Comment.find(query)
        .populate("userId", "fullName avatar")
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit))
        .lean();

      // Get total count
      const total = await Comment.countDocuments(query);

      // Calculate pagination info
      const totalPages = Math.ceil(total / limit);
      const hasNextPage = page < totalPages;
      const hasPrevPage = page > 1;

      res.json({
        success: true,
        data: {
          comments,
          pagination: {
            currentPage: parseInt(page),
            totalPages,
            totalItems: total,
            hasNextPage,
            hasPrevPage,
            limit: parseInt(limit),
          },
        },
      });
    } catch (error) {
      logger.error("Get song comments error:", error);
      res.status(500).json({
        success: false,
        message: "Server error while fetching comments",
      });
    }
  }
);

// @route   GET /api/songs/:id/mood-breakdown
// @desc    Get mood breakdown for a song
// @access  Public
router.get("/:id/mood-breakdown", async (req, res) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) {
      return res.status(404).json({
        success: false,
        message: "Song not found",
      });
    }

    const moodBreakdown = song.getMoodBreakdown();

    res.json({
      success: true,
      data: {
        moodBreakdown,
        totalVotes: song.totalMoodVotes,
        primaryMood: song.primaryMood,
      },
    });
  } catch (error) {
    logger.error("Get mood breakdown error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching mood breakdown",
    });
  }
});

// @route   GET /api/songs/recommendations
// @desc    Get personalized song recommendations
// @access  Private
router.get("/recommendations", auth, async (req, res) => {
  try {
    const { limit = 20 } = req.query;

    // Get user's favorite moods and genres
    const userMoods = req.user.preferences.favoriteMoods || [];
    const userGenres = req.user.preferences.favoriteGenres || [];

    // Build recommendation query
    const query = { isActive: true };

    if (userMoods.length > 0) {
      query.$or = [
        { primaryMood: { $in: userMoods } },
        { genres: { $in: userGenres } },
      ];
    }

    const recommendations = await Song.find(query)
      .sort({ "stats.totalPlays": -1, "stats.averageRating": -1 })
      .limit(parseInt(limit))
      .populate("comments", "text detectedMood createdAt")
      .lean();

    res.json({
      success: true,
      data: {
        recommendations,
        userPreferences: {
          moods: userMoods,
          genres: userGenres,
        },
      },
    });
  } catch (error) {
    logger.error("Get recommendations error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching recommendations",
    });
  }
});

// @route   GET /api/songs/:id
// @desc    Get song by ID
// @access  Public
router.get("/:id", async (req, res) => {
  try {
    const song = await Song.findById(req.params.id)
      .populate({
        path: "comments",
        options: { sort: { createdAt: -1 }, limit: 10 },
        populate: {
          path: "userId",
          select: "fullName avatar",
        },
      })
      .lean();

    if (!song) {
      return res.status(404).json({
        success: false,
        message: "Song not found",
      });
    }

    // Increment play count if user is authenticated
    if (req.user) {
      await Song.findByIdAndUpdate(req.params.id, {
        $inc: { "stats.totalPlays": 1 },
      });
    }

    res.json({
      success: true,
      data: { song },
    });
  } catch (error) {
    logger.error("Get song by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching song",
    });
  }
});

module.exports = router;
