const express = require('express');
const { body, query, validationResult } = require('express-validator');
const Comment = require('../models/Comment');
const Song = require('../models/Song');
const auth = require('../middleware/auth');
const moodDetectionService = require('../services/moodDetectionService');
const logger = require('../utils/logger');

const router = express.Router();

// @route   POST /api/comments
// @desc    Add a new comment to a song
// @access  Private
router.post('/', [
  auth,
  body('songId')
    .isMongoId()
    .withMessage('Valid song ID is required'),
  body('text')
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage('Comment text must be between 1 and 1000 characters'),
  body('userSelectedMood')
    .optional()
    .isIn(['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'])
    .withMessage('Invalid mood selection')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { songId, text, userSelectedMood } = req.body;

    // Check if song exists
    const song = await Song.findById(songId);
    if (!song) {
      return res.status(404).json({
        success: false,
        message: 'Song not found'
      });
    }

    // Detect mood from comment text
    const moodAnalysis = moodDetectionService.detectMood(text);
    const detectedMood = moodAnalysis.detectedMood;
    const confidence = moodAnalysis.confidence;

    // Create comment
    const comment = new Comment({
      songId,
      userId: req.user.id,
      text,
      detectedMood,
      moodConfidence: confidence,
      userSelectedMood,
      finalMood: userSelectedMood || detectedMood,
      sentiment: moodAnalysis.sentiment,
      moodKeywords: moodAnalysis.moodKeywords,
      language: req.user.preferences.language || 'en',
      userAgent: req.get('User-Agent'),
      ipAddress: req.ip
    });

    await comment.save();

    // Update song stats
    await Song.findByIdAndUpdate(songId, {
      $inc: { 'stats.totalComments': 1 }
    });

    // Update user stats
    await req.user.updateOne({
      $inc: { 'stats.totalComments': 1 }
    });

    // Populate user info for response
    await comment.populate('userId', 'fullName avatar');

    logger.info(`New comment added by ${req.user.email} on song: ${song.title}`);

    res.status(201).json({
      success: true,
      message: 'Comment added successfully',
      data: {
        comment: {
          ...comment.toObject(),
          moodAnalysis: {
            detectedMood,
            confidence,
            sentiment: moodAnalysis.sentiment,
            keywords: moodAnalysis.moodKeywords
          }
        }
      }
    });

  } catch (error) {
    logger.error('Add comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while adding comment'
    });
  }
});

// @route   GET /api/comments
// @desc    Get comments with filtering and pagination
// @access  Public
router.get('/', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50'),
  query('mood').optional().isString().withMessage('Mood must be a string'),
  query('songId').optional().isMongoId().withMessage('Valid song ID is required'),
  query('userId').optional().isMongoId().withMessage('Valid user ID is required'),
  query('sort').optional().isIn(['createdAt', 'likes', 'dislikes']).withMessage('Invalid sort field'),
  query('order').optional().isIn(['asc', 'desc']).withMessage('Order must be asc or desc')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const {
      page = 1,
      limit = 20,
      mood,
      songId,
      userId,
      sort = 'createdAt',
      order = 'desc'
    } = req.query;

    // Build query
    const query = { isHidden: false };
    
    if (mood) {
      query.finalMood = mood;
    }
    
    if (songId) {
      query.songId = songId;
    }
    
    if (userId) {
      query.userId = userId;
    }

    const comments = await Comment.find(query)
      .populate('userId', 'fullName avatar')
      .populate('songId', 'title artist coverImage')
      .sort({ [sort]: order === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    // Get total count
    const total = await Comment.countDocuments(query);

    // Calculate pagination info
    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    res.json({
      success: true,
      data: {
        comments,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalItems: total,
          hasNextPage,
          hasPrevPage,
          limit: parseInt(limit)
        }
      }
    });

  } catch (error) {
    logger.error('Get comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching comments'
    });
  }
});

// @route   GET /api/comments/:id
// @desc    Get comment by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id)
      .populate('userId', 'fullName avatar')
      .populate('songId', 'title artist coverImage')
      .lean();

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    if (comment.isHidden) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    res.json({
      success: true,
      data: { comment }
    });

  } catch (error) {
    logger.error('Get comment by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching comment'
    });
  }
});

// @route   PUT /api/comments/:id
// @desc    Update a comment
// @access  Private
router.put('/:id', [
  auth,
  body('text')
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage('Comment text must be between 1 and 1000 characters'),
  body('userSelectedMood')
    .optional()
    .isIn(['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'])
    .withMessage('Invalid mood selection')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { text, userSelectedMood } = req.body;

    // Find comment
    const comment = await Comment.findById(req.params.id);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    // Check if user owns the comment
    if (comment.userId.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this comment'
      });
    }

    // Re-detect mood if text changed
    let detectedMood = comment.detectedMood;
    let confidence = comment.moodConfidence;
    let sentiment = comment.sentiment;
    let moodKeywords = comment.moodKeywords;

    if (text !== comment.text) {
      const moodAnalysis = moodDetectionService.detectMood(text);
      detectedMood = moodAnalysis.detectedMood;
      confidence = moodAnalysis.confidence;
      sentiment = moodAnalysis.sentiment;
      moodKeywords = moodAnalysis.moodKeywords;
    }

    // Update comment
    comment.text = text;
    comment.detectedMood = detectedMood;
    comment.moodConfidence = confidence;
    comment.userSelectedMood = userSelectedMood;
    comment.finalMood = userSelectedMood || detectedMood;
    comment.sentiment = sentiment;
    comment.moodKeywords = moodKeywords;

    await comment.save();

    // Populate user info for response
    await comment.populate('userId', 'fullName avatar');

    logger.info(`Comment updated by ${req.user.email}: ${comment._id}`);

    res.json({
      success: true,
      message: 'Comment updated successfully',
      data: { comment }
    });

  } catch (error) {
    logger.error('Update comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating comment'
    });
  }
});

// @route   DELETE /api/comments/:id
// @desc    Delete a comment
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    // Check if user owns the comment
    if (comment.userId.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this comment'
      });
    }

    // Update song stats
    await Song.findByIdAndUpdate(comment.songId, {
      $inc: { 'stats.totalComments': -1 }
    });

    // Update user stats
    await req.user.updateOne({
      $inc: { 'stats.totalComments': -1 }
    });

    await comment.remove();

    logger.info(`Comment deleted by ${req.user.email}: ${comment._id}`);

    res.json({
      success: true,
      message: 'Comment deleted successfully'
    });

  } catch (error) {
    logger.error('Delete comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting comment'
    });
  }
});

// @route   POST /api/comments/:id/like
// @desc    Like a comment
// @access  Private
router.post('/:id/like', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    if (comment.isHidden) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    // Increment like count
    comment.likes += 1;
    await comment.save();

    logger.info(`User ${req.user.email} liked comment: ${comment._id}`);

    res.json({
      success: true,
      message: 'Comment liked successfully',
      data: {
        likes: comment.likes
      }
    });

  } catch (error) {
    logger.error('Like comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while liking comment'
    });
  }
});

// @route   POST /api/comments/:id/dislike
// @desc    Dislike a comment
// @access  Private
router.post('/:id/dislike', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    if (comment.isHidden) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    // Increment dislike count
    comment.dislikes += 1;
    await comment.save();

    logger.info(`User ${req.user.email} disliked comment: ${comment._id}`);

    res.json({
      success: true,
      message: 'Comment disliked successfully',
      data: {
        dislikes: comment.dislikes
      }
    });

  } catch (error) {
    logger.error('Dislike comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while disliking comment'
    });
  }
});

// @route   POST /api/comments/:id/reply
// @desc    Add a reply to a comment
// @access  Private
router.post('/:id/reply', [
  auth,
  body('text')
    .trim()
    .isLength({ min: 1, max: 500 })
    .withMessage('Reply text must be between 1 and 500 characters')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { text } = req.body;

    const comment = await Comment.findById(req.params.id);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    if (comment.isHidden) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found'
      });
    }

    // Add reply
    await comment.addReply(req.user.id, text);

    // Populate user info for response
    await comment.populate('userId', 'fullName avatar');

    logger.info(`Reply added by ${req.user.email} to comment: ${comment._id}`);

    res.json({
      success: true,
      message: 'Reply added successfully',
      data: { comment }
    });

  } catch (error) {
    logger.error('Add reply error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while adding reply'
    });
  }
});

// @route   GET /api/comments/mood/:mood
// @desc    Get comments by mood
// @access  Public
router.get('/mood/:mood', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { mood } = req.params;
    const { page = 1, limit = 20 } = req.query;

    const comments = await Comment.findByMood(mood, {
      page: parseInt(page),
      limit: parseInt(limit)
    });

    res.json({
      success: true,
      data: {
        comments,
        mood,
        totalResults: comments.length
      }
    });

  } catch (error) {
    logger.error('Get comments by mood error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching comments by mood'
    });
  }
});

// @route   GET /api/comments/recent
// @desc    Get recent comments
// @access  Public
router.get('/recent', [
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { limit = 20 } = req.query;

    const comments = await Comment.findRecent(parseInt(limit));

    res.json({
      success: true,
      data: {
        comments,
        totalResults: comments.length
      }
    });

  } catch (error) {
    logger.error('Get recent comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching recent comments'
    });
  }
});

// @route   GET /api/comments/stats/mood
// @desc    Get mood statistics for comments
// @access  Public
router.get('/stats/mood', async (req, res) => {
  try {
    const moodStats = await Comment.getMoodStats();

    res.json({
      success: true,
      data: {
        moodStats
      }
    });

  } catch (error) {
    logger.error('Get mood stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching mood statistics'
    });
  }
});

module.exports = router;


