const express = require('express');
const { query, validationResult } = require('express-validator');
const Song = require('../models/Song');
const Comment = require('../models/Comment');
const moodDetectionService = require('../services/moodDetectionService');
const logger = require('../utils/logger');

const router = express.Router();

// @route   GET /api/moods
// @desc    Get all available moods with statistics
// @access  Public
router.get('/', async (req, res) => {
  try {
    const moods = [
      'happy', 'sad', 'energetic', 'calm', 'romantic', 
      'angry', 'melancholic', 'uplifting', 'chill', 'party'
    ];

    const moodStats = await Promise.all(
      moods.map(async (mood) => {
        const songCount = await Song.countDocuments({ 
          primaryMood: mood, 
          isActive: true 
        });
        
        const commentCount = await Comment.countDocuments({ 
          finalMood: mood, 
          isHidden: false 
        });

        return {
          mood,
          displayName: moodDetectionService.getMoodDisplayName(mood),
          emoji: moodDetectionService.getMoodEmoji(mood),
          color: moodDetectionService.getMoodColor(mood),
          songCount,
          commentCount
        };
      })
    );

    res.json({
      success: true,
      data: {
        moods: moodStats
      }
    });

  } catch (error) {
    logger.error('Get moods error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching moods'
    });
  }
});

// @route   GET /api/moods/:mood/songs
// @desc    Get songs by specific mood
// @access  Public
router.get('/:mood/songs', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('sort').optional().isIn(['title', 'artist', 'releaseYear', 'stats.totalPlays', 'stats.averageRating']).withMessage('Invalid sort field'),
  query('order').optional().isIn(['asc', 'desc']).withMessage('Order must be asc or desc')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { mood } = req.params;
    const { page = 1, limit = 20, sort = 'stats.totalPlays', order = 'desc' } = req.query;

    // Validate mood
    const validMoods = ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'];
    if (!validMoods.includes(mood)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid mood'
      });
    }

    const songs = await Song.find({ 
      primaryMood: mood, 
      isActive: true 
    })
      .sort({ [sort]: order === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .populate('comments', 'text detectedMood createdAt')
      .lean();

    const total = await Song.countDocuments({ 
      primaryMood: mood, 
      isActive: true 
    });

    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    res.json({
      success: true,
      data: {
        songs,
        mood: {
          name: mood,
          displayName: moodDetectionService.getMoodDisplayName(mood),
          emoji: moodDetectionService.getMoodEmoji(mood),
          color: moodDetectionService.getMoodColor(mood)
        },
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalItems: total,
          hasNextPage,
          hasPrevPage,
          limit: parseInt(limit)
        }
      }
    });

  } catch (error) {
    logger.error('Get songs by mood error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching songs by mood'
    });
  }
});

// @route   GET /api/moods/:mood/comments
// @desc    Get comments by specific mood
// @access  Public
router.get('/:mood/comments', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    const { mood } = req.params;
    const { page = 1, limit = 20 } = req.query;

    // Validate mood
    const validMoods = ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'];
    if (!validMoods.includes(mood)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid mood'
      });
    }

    const comments = await Comment.find({ 
      finalMood: mood, 
      isHidden: false 
    })
      .populate('userId', 'fullName avatar')
      .populate('songId', 'title artist coverImage')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    const total = await Comment.countDocuments({ 
      finalMood: mood, 
      isHidden: false 
    });

    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    res.json({
      success: true,
      data: {
        comments,
        mood: {
          name: mood,
          displayName: moodDetectionService.getMoodDisplayName(mood),
          emoji: moodDetectionService.getMoodEmoji(mood),
          color: moodDetectionService.getMoodColor(mood)
        },
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalItems: total,
          hasNextPage,
          hasPrevPage,
          limit: parseInt(limit)
        }
      }
    });

  } catch (error) {
    logger.error('Get comments by mood error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching comments by mood'
    });
  }
});

// @route   GET /api/moods/stats/overview
// @desc    Get mood statistics overview
// @access  Public
router.get('/stats/overview', async (req, res) => {
  try {
    // Get mood distribution from songs
    const songMoodStats = await Song.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: '$primaryMood',
          songCount: { $sum: 1 },
          totalPlays: { $sum: '$stats.totalPlays' },
          avgRating: { $avg: '$stats.averageRating' }
        }
      },
      { $sort: { songCount: -1 } }
    ]);

    // Get mood distribution from comments
    const commentMoodStats = await Comment.aggregate([
      { $match: { isHidden: false } },
      {
        $group: {
          _id: '$finalMood',
          commentCount: { $sum: 1 },
          avgConfidence: { $avg: '$moodConfidence' },
          avgSentiment: { $avg: '$sentiment.score' }
        }
      },
      { $sort: { commentCount: -1 } }
    ]);

    // Combine stats
    const moods = ['happy', 'sad', 'energetic', 'calm', 'romantic', 'angry', 'melancholic', 'uplifting', 'chill', 'party'];
    const combinedStats = moods.map(mood => {
      const songStats = songMoodStats.find(s => s._id === mood) || {};
      const commentStats = commentMoodStats.find(c => c._id === mood) || {};

      return {
        mood,
        displayName: moodDetectionService.getMoodDisplayName(mood),
        emoji: moodDetectionService.getMoodEmoji(mood),
        color: moodDetectionService.getMoodColor(mood),
        songCount: songStats.songCount || 0,
        commentCount: commentStats.commentCount || 0,
        totalPlays: songStats.totalPlays || 0,
        avgRating: songStats.avgRating || 0,
        avgConfidence: commentStats.avgConfidence || 0,
        avgSentiment: commentStats.avgSentiment || 0
      };
    });

    res.json({
      success: true,
      data: {
        moodStats: combinedStats,
        summary: {
          totalSongs: songMoodStats.reduce((sum, stat) => sum + stat.songCount, 0),
          totalComments: commentMoodStats.reduce((sum, stat) => sum + stat.commentCount, 0),
          totalPlays: songMoodStats.reduce((sum, stat) => sum + stat.totalPlays, 0)
        }
      }
    });

  } catch (error) {
    logger.error('Get mood stats overview error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching mood statistics'
    });
  }
});

// @route   POST /api/moods/detect
// @desc    Detect mood from text (for testing/development)
// @access  Public
router.post('/detect', async (req, res) => {
  try {
    const { text } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Text is required'
      });
    }

    const moodAnalysis = moodDetectionService.detectMood(text);

    res.json({
      success: true,
      data: {
        text,
        moodAnalysis: {
          detectedMood: moodAnalysis.detectedMood,
          confidence: moodAnalysis.confidence,
          moodScores: moodAnalysis.moodScores,
          sentiment: moodAnalysis.sentiment,
          keywords: moodAnalysis.moodKeywords
        },
        moodInfo: {
          displayName: moodDetectionService.getMoodDisplayName(moodAnalysis.detectedMood),
          emoji: moodDetectionService.getMoodEmoji(moodAnalysis.detectedMood),
          color: moodDetectionService.getMoodColor(moodAnalysis.detectedMood)
        }
      }
    });

  } catch (error) {
    logger.error('Mood detection error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while detecting mood'
    });
  }
});

module.exports = router;


