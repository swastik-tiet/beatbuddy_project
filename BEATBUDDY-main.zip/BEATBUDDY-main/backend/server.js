const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

// Import routes
const authRoutes = require("./routes/auth");
const songRoutes = require("./routes/songs");
const commentRoutes = require("./routes/comments");
const moodRoutes = require("./routes/moods");
const userRoutes = require("./routes/users");

// Import middleware
const errorHandler = require("./middleware/errorHandler");
const logger = require("./utils/logger");

const app = express();

// Security middleware
app.use(helmet());
app.use(compression());

// Trust proxy for accurate client IPs behind proxies/load balancers (fixes express-rate-limit X-Forwarded-For validation)
app.set("trust proxy", 1);

// CORS configuration (supports comma-separated origins)
const normalizeOrigin = (origin = "") =>
  origin.trim().replace(/\/$/, "").toLowerCase();

const defaultOrigins = [
  "http://localhost:3000",
  "http://localhost:3001",
  "http://127.0.0.1:3000",
  "http://127.0.0.1:3001",
];

const allowedOrigins = new Set(
  [process.env.CORS_ORIGIN, ...defaultOrigins]
    .filter(Boolean)
    .flatMap((list) => list.split(",").map(normalizeOrigin))
    .filter(Boolean)
);

app.use(
  cors()
);

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limit each IP to 100 requests per windowMs
  message: {
    error: "Too many requests from this IP, please try again later.",
  },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use("/api/", limiter);

// Body parsing middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Logging middleware
app.use(
  morgan("combined", {
    stream: { write: (message) => logger.info(message.trim()) },
  })
);

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "OK",
    message: "BeatBuddy API is running",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
  });
});

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/songs", songRoutes);
app.use("/api/comments", commentRoutes);
app.use("/api/moods", moodRoutes);
app.use("/api/users", userRoutes);

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Route not found",
    message: `Cannot ${req.method} ${req.originalUrl}`,
  });
});

// Error handling middleware
app.use(errorHandler);

// Database connection with fallbacks
const connectDB = async () => {
  const uriCandidates = [];
  // Prefer explicit env URIs
  if (process.env.MONGODB_URI) uriCandidates.push(process.env.MONGODB_URI);
  if (process.env.MONGODB_URI_PROD)
    uriCandidates.push(process.env.MONGODB_URI_PROD);
  // Always include local fallback
  uriCandidates.push("mongodb://127.0.0.1:27017/beatbuddy");

  for (const uri of [...new Set(uriCandidates)]) {
    try {
      const conn = await mongoose.connect(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });
      logger.info(`MongoDB Connected: ${conn.connection.host}`);
      return;
    } catch (error) {
      logger.error(`Database connection attempt failed for URI ${uri}:`, error);
    }
  }
  // Try in-memory MongoDB in development if enabled or default allowed
  const shouldUseMemory =
    process.env.USE_IN_MEMORY_DB === "true" ||
    process.env.NODE_ENV !== "production";
  if (shouldUseMemory) {
    try {
      // Dynamically require to avoid dependency in production if not installed
      // eslint-disable-next-line global-require
      const { MongoMemoryServer } = require("mongodb-memory-server");
      const mongod = await MongoMemoryServer.create();
      const memUri = mongod.getUri("beatbuddy");
      const conn = await mongoose.connect(memUri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });
      logger.info("Started in-memory MongoDB for development.");
      logger.info(`MongoDB Connected (memory): ${conn.connection.host}`);
      return;
    } catch (memErr) {
      logger.error("Failed to start in-memory MongoDB:", memErr);
    }
  }
  logger.error("All MongoDB connection attempts failed.");
  process.exit(1);
};

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();

    app.listen(PORT, () => {
      logger.info(
        `Server running on port ${PORT} in ${process.env.NODE_ENV} mode`
      );
      logger.info(`Health check: http://localhost:${PORT}/health`);
      logger.info(`API Documentation: http://localhost:${PORT}/api/docs`);
    });
  } catch (error) {
    logger.error("Server startup error:", error);
    process.exit(1);
  }
};

// Handle unhandled promise rejections
process.on("unhandledRejection", (err, promise) => {
  logger.error("Unhandled Rejection at:", promise, "reason:", err);
  process.exit(1);
});

// Handle uncaught exceptions
process.on("uncaughtException", (err) => {
  logger.error("Uncaught Exception:", err);
  process.exit(1);
});

startServer();

module.exports = app;
